package com.nets.sg.npx.core.dao.impl;

import java.util.List;

import org.hibernate.FetchMode;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.AcquirerMerchantMappingDao;
import com.nets.sg.npx.core.persistence.entity.AcquirerMerchantMappingEntity;

@Repository
public class AcquirerMerchantMappingDaoImpl extends GenericDaoImpl<AcquirerMerchantMappingEntity, Long> implements AcquirerMerchantMappingDao {

    @Override
    public AcquirerMerchantMappingEntity getByAcqMerchant(Long merchantId, Long acquirerId, String... paths) {
        DetachedCriteria criteria = DetachedCriteria.forClass(AcquirerMerchantMappingEntity.class, "acqmerchmap");
        //criteria.createAlias("acqmerchmap.merchant", "merchant");
        //criteria.add(Restrictions.eq("merchant.oid", merchantId));
        criteria.add(Restrictions.eq("merchantId", merchantId.intValue()));

        criteria.createAlias("acqmerchmap.acquirer", "acquirer");
        criteria.add(Restrictions.eq("acquirer.oid", acquirerId));
        
        for (String eagetPath : paths) {
            criteria.setFetchMode(eagetPath, FetchMode.JOIN);
        }

        List<AcquirerMerchantMappingEntity> acqmerchmaps = findByCriteria(criteria);
        AcquirerMerchantMappingEntity record = null;

        if (acqmerchmaps.size() > 0) {
            record = acqmerchmaps.get(0);
        }
        return record;
    }

    @Override
    public AcquirerMerchantMappingEntity getByAcqMerchantWithInstallments(Long merchantId, Long acquirerId) {
        AcquirerMerchantMappingEntity record = getByAcqMerchant(merchantId, acquirerId);
        getHibernateTemplate().initialize(record.getAcqMerInstallments());        
        return record;
    }

}
