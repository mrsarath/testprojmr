package com.nets.sg.npx.core.dao.mss.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.nets.sg.npx.core.dao.impl.GenericDaoImpl;
import com.nets.sg.npx.core.dao.mss.TerminalStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.TerminalStageEntity;

@Repository
public class TerminalStageDaoImpl extends GenericDaoImpl<TerminalStageEntity, Long> implements TerminalStageDao {

    @Override
    public List<TerminalStageEntity> getRecords(String batchNo, String retailId, byte status) {

        DetachedCriteria criteria = DetachedCriteria.forClass(TerminalStageEntity.class);
        criteria.add(Restrictions.eq("batchNo", batchNo));
        criteria.add(Restrictions.eq("retId", retailId));
        criteria.add(Restrictions.eq("recordStatus", status));

        List<TerminalStageEntity> records = findByCriteria(criteria);

        return records;

    }

    @Override
    public List<TerminalStageEntity> getRecords(String date, String batchNo, String status) {

        DetachedCriteria criteria = DetachedCriteria.forClass(TerminalStageEntity.class);
        criteria.add(Restrictions.eq("recordCreateDate", date));
        if (!StringUtils.isEmpty(batchNo))
            criteria.add(Restrictions.eq("batchNo", batchNo));
        
        criteria.add(Restrictions.eq("recordStatus", status));
        return findByCriteria(criteria);

    }

}
