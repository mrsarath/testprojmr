package com.nets.sg.npx.core.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nets.sg.npx.core.dao.MerchantFundingDao;
import com.nets.sg.npx.core.persistence.entity.MerchantFundingEntity;
import com.nets.sg.npx.core.service.MerchantFundingService;

@Service("merchantFundingService")
public class MerchantFundingServiceImpl implements MerchantFundingService {

    @Autowired
    private MerchantFundingDao merchantFundingDao;

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public MerchantFundingEntity save(MerchantFundingEntity funding) {
        return merchantFundingDao.save(funding);
    }

    @Override
    public MerchantFundingEntity getMerchantFundingByBatchNo(String batchNo) {
        return merchantFundingDao.getMerchantFundingByBatchNo(batchNo);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public MerchantFundingEntity update(MerchantFundingEntity funding) {
        return merchantFundingDao.saveOrUpdate(funding);
    }

    @Override
    @Transactional
    public List<MerchantFundingEntity> getUnPostedSuccessRecords(String svcType) {
        return merchantFundingDao.getUnPostedSuccessRecords(svcType);
    }

    @Override
    public MerchantFundingEntity getSubmittedByFileName(String fileName) {
        
        return merchantFundingDao.getSubmittedByFileName(fileName);
    }

}
