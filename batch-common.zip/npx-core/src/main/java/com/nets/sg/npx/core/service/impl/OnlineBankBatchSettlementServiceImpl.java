package com.nets.sg.npx.core.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nets.sg.npx.core.dao.OnlineBankBatchSettlementDao;
import com.nets.sg.npx.core.persistence.entity.OnlineBankBatchEntity;
import com.nets.sg.npx.core.service.OnlineBankBatchSettlementService;

@Service
public class OnlineBankBatchSettlementServiceImpl implements OnlineBankBatchSettlementService {

    @Autowired
    private OnlineBankBatchSettlementDao onlineBankBatchSettlementDao;

    @Override
    public List<OnlineBankBatchEntity> getSettlement(Date begin, Date end, String... status) {
        return onlineBankBatchSettlementDao.getSettlement(begin, end, status);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public List<OnlineBankBatchEntity> saveAll(List<OnlineBankBatchEntity> settlements) {
        return onlineBankBatchSettlementDao.saveOrUpdateAll(settlements);
    }

}
