package com.nets.sg.npx.core.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.CountryDao;
import com.nets.sg.npx.core.persistence.entity.CountryEntity;

@Repository
public class CountryDaoImpl extends GenericDaoImpl<CountryEntity, Long> implements CountryDao {

    @Override
    public CountryEntity getCountryByName(String name) {
        DetachedCriteria criteria = DetachedCriteria.forClass(CountryEntity.class);
        criteria.add(Restrictions.eq("countryName", name));
        List<CountryEntity> countries = findByCriteria(criteria);

        CountryEntity country = null;

        if (countries.size() > 0)
            country = countries.get(0);
        return country;
    }

}
