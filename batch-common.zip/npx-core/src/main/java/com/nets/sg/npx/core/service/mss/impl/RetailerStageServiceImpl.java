package com.nets.sg.npx.core.service.mss.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.mss.RetailerStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.RetailerStageEntity;
import com.nets.sg.npx.core.service.mss.RetailerStageService;

@Service
public class RetailerStageServiceImpl implements RetailerStageService {

    @Autowired
    private RetailerStageDao syncRetailerDao;

    @Override
    public RetailerStageEntity save(RetailerStageEntity record) {

        return syncRetailerDao.save(record);
    }

    @Override
    public List<RetailerStageEntity> getRecords(String batchNo, String groupId, byte status) {
        return syncRetailerDao.getRecordsByStatus(batchNo, groupId, status);
    }

    @Override
    public RetailerStageEntity update(RetailerStageEntity retailer) {
        return syncRetailerDao.saveOrUpdate(retailer);
    }

    @Override
    public List<RetailerStageEntity> getRecords(String createDate, String batchNo, String status) {
        return syncRetailerDao.getRecordsByStatus(createDate, batchNo, status);
    }
}
