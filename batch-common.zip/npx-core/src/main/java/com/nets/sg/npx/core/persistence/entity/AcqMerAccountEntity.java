package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "ta02_acq_mer_account")
public class AcqMerAccountEntity implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ACQ_MER_ACCOUNT_ID")
    private Long oid;

    @Column(name = "EC_MID", nullable = false, length = 20)
    private String ecMid;

    @Column(name = "TID", nullable = false, length = 20)
    private String tid;

       
    // ////////////
    
    /* @Column(name = "ACQUIRER_ID", nullable = false, length = 20)
    private String acquirerId;
    
    @Column(name = "MERCHANT_ID", nullable = false, length = 20)
    private String merchantId;*/
    
    @Column(name="CREATED_BY")
    private int createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="CREATION_DATE")
    private Date creationDate;
    
    @ManyToOne(optional=false)
    @JoinColumn(name = "MERCHANT_ID", nullable=false)
    private MerchantEntity merchant;

    
    /*@ManyToOne(optional=false)
    @JoinColumn(name = "ACQUIRER_ID", nullable=false)
    private AcquirerEntity acquirer;*/
    
    @Column(name = "ACQUIRER_ID", nullable=false)
    private int acquirerId;

   /* @ManyToOne(optional=false)
    @JoinColumn(name="DEFAULT_ACQ_MAPPING_ID", nullable=false)
    private AcquirerMerchantMappingEntity defaultAcqMerchantMapping;*/
    
    @Column(name="DEFAULT_ACQ_MAPPING_ID", nullable=false)
    private int defAcqMappingId;
    
    /*@ManyToOne(optional=false)
    @JoinColumn(name="MER_MAPPING_ID", nullable=false)
    private AcquirerMerchantMappingEntity acquirerMerchantMapping;*/
    
    @Column(name="MER_MAPPING_ID", nullable=false)
    private int merchantMappingId;
    
    @Column(name="IS_SUPPORTED")
    private String isSupported;

    @Column(name="ISO_CURRENCY")
    private String isoCurrency;

    @Column(name="LAST_UPDATED_BY")
    private int lastUpdatedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="LAST_UPDATED_DATE")
    private Date lastUpdatedDate;
    
    @Column(name="MERCHANT_PROFILE_ID")
    private String merchantProfileId;

    @Column(name="POS_ID", nullable=false)
    private int pos;
    
    /* @ManyToOne
    @JoinColumn(name="POS_ID", nullable=false)
    PhysicalPosEntity pos;
    */
    
    @Column(name="SOURCE_CURRENCY")
    private String sourceCurrency;


    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getEcMid() {
        return ecMid;
    }

    public void setEcMid(String ecMid) {
        this.ecMid = ecMid;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }
    
    public MerchantEntity getMerchant() {
        return merchant;
    }

    public void setMerchant(MerchantEntity merchant) {
        this.merchant = merchant;
    }

   /* public AcquirerEntity getAcquirer() {
        return acquirer;
    }

    public void setAcquirer(AcquirerEntity acquirer) {
        this.acquirer = acquirer;
    }*/
    
    //  ////////////////////////
    
    /*public String getAcquirerId() {
        return acquirerId;
    }

    public void setAcquirerId(String acquirerId) {
        this.acquirerId = acquirerId;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }*/

    public int getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

   /* public int getDefaultAcqMappingId() {
        return this.defaultAcqMappingId;
    }

    public void setDefaultAcqMappingId(int defaultAcqMappingId) {
        this.defaultAcqMappingId = defaultAcqMappingId;
    }
*/
    
    /*public AcquirerMerchantMappingEntity getDefaultAcqMerchantMapping() {
        return defaultAcqMerchantMapping;
    }

    public void setDefaultAcqMerchantMapping(AcquirerMerchantMappingEntity defaultAcqMerchantMapping) {
        this.defaultAcqMerchantMapping = defaultAcqMerchantMapping;
    }*/
      

    public int getDefAcqMappingId() {
        return defAcqMappingId;
    }

    public void setDefAcqMappingId(int defAcqMappingId) {
        this.defAcqMappingId = defAcqMappingId;
    }
    
    public String getIsSupported() {
        return this.isSupported;
    }

    public void setIsSupported(String isSupported) {
        this.isSupported = isSupported;
    }

    public String getIsoCurrency() {
        return this.isoCurrency;
    }

    public void setIsoCurrency(String isoCurrency) {
        this.isoCurrency = isoCurrency;
    }

    public int getLastUpdatedBy() {
        return this.lastUpdatedBy;
    }

    public void setLastUpdatedBy(int lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return this.lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
  
    public String getMerchantProfileId() {
        return this.merchantProfileId;
    }

    public void setMerchantProfileId(String merchantProfileId) {
        this.merchantProfileId = merchantProfileId;
    }

    /*public PhysicalPosEntity getPos() {
        return this.pos;
    }

    public void setPos(PhysicalPosEntity pos) {
        this.pos = pos;
    }*/
    
    

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public String getSourceCurrency() {
        return this.sourceCurrency;
    }

    public void setSourceCurrency(String sourceCurrency) {
        this.sourceCurrency = sourceCurrency;
    }

    public int getMerchantMappingId() {
        return merchantMappingId;
    }

    public void setMerchantMappingId(int merchantMappingId) {
        this.merchantMappingId = merchantMappingId;
    }

    public int getAcquirerId() {
        return acquirerId;
    }

    public void setAcquirerId(int acquirerId) {
        this.acquirerId = acquirerId;
    }  

    
    /*public AcquirerMerchantMappingEntity getAcquirerMerchantMapping() {
        return this.acquirerMerchantMapping;
    }

    public void setAcquirerMerchantMapping(AcquirerMerchantMappingEntity acquirerMerchantMapping) {
        this.acquirerMerchantMapping = acquirerMerchantMapping;
    }*/
    
    

}
