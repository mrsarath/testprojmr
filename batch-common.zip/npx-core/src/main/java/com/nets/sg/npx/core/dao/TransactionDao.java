package com.nets.sg.npx.core.dao;

import java.util.Date;
import java.util.List;

import com.nets.sg.npx.core.persistence.entity.TransactionEntity;

public interface TransactionDao extends GenericDao<TransactionEntity, Long> {

    List<TransactionEntity> getTransactionForMerchantSettlement(Date from, Date to, List<Long> acquirers, String merchantType, String... state);

    List<TransactionEntity> getByState(String... state);

    /**
     * - used in Monthly Txn Fee Report Data load program (batch-bo) - used in
     * npx-batch-mcon
     */
    List<TransactionEntity> getBySettledDateAndStateAndMType(Date from, Date to, String merchantType, String... state);

    /**
     * @param from
     * @param to
     * @param state
     * @param merchantType
     * @return - used in batch-sap while create journal entry for fund of sales
     *         in the daily interface file
     */
    List<TransactionEntity> getTransactionsForGLUpload(Date from, Date to, String merchantType, String... state);

    /**
     * @param from
     * @param to
     * @param payStatus
     * @param merchantType
     * @return - used for batch-sap monthly gl files (billing, collection)
     */
    List<TransactionEntity> getBySettledDateAndPayStatus(Date from, Date to, String payStatus, String merchantType);

    List<TransactionEntity> getTransactionByCardTypeAndState(Date from, Date to, String cardType, String... state);

}
