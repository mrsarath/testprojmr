package com.nets.sg.npx.core.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

public interface GenericDao<T, OID extends Serializable> {

    T save(T entity);

    T saveOrUpdate(T entity);

    List<T> saveOrUpdateAll(List<T> entities);

    T merge(T entity);
    
    void delete(T entity);

    List<T> findAll();

    T findByOid(OID oid);

    List<T> findByCriteria(DetachedCriteria criteria);
    
    List<T> findByNamedParam(String query, String[] params, String[] values);

}
