package com.nets.sg.npx.core.service;

import com.nets.sg.npx.core.persistence.entity.SettledTransactionMonthlyEntity;

public interface SettledTransactionMonthlyService {

    SettledTransactionMonthlyEntity getRecordByMerchantAcquirerAndMonth(Long merchantId, Long acquirerId, String year, String month);

    SettledTransactionMonthlyEntity saveOrUpdate(SettledTransactionMonthlyEntity funding);    

}
