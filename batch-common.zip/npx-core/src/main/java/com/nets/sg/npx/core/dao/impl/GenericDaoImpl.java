package com.nets.sg.npx.core.dao.impl;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.nets.sg.npx.core.dao.GenericDao;

public class GenericDaoImpl<T, OID extends Serializable> extends HibernateDaoSupport implements GenericDao<T, OID> {

    @Autowired
    public void setSessionfactory(SessionFactory sessionFactory) {
        super.setSessionFactory(sessionFactory);
    }

    protected Class<T> persistentClass;

    @SuppressWarnings("unchecked")
    public GenericDaoImpl() {
        persistentClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    @Override
    public T save(T entity) {
        getHibernateTemplate().save(entity);
        return entity;
    }

    @Override
    public T saveOrUpdate(T entity) {
        getHibernateTemplate().saveOrUpdate(entity);
        return entity;
    }

    @Override
    public T merge(T entity) {
        getHibernateTemplate().merge(entity);
        return entity;
    }
    
    @Override
    public void delete(T entity) {        
        getHibernateTemplate().delete(entity);    
    }

    @Override
    public List<T> findAll() {
        return getHibernateTemplate().loadAll(persistentClass);
    }

    @Override
    public T findByOid(OID oid) throws DataAccessException {
        return getHibernateTemplate().get(persistentClass, oid);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByCriteria(DetachedCriteria criteria) {
        return (List<T>) getHibernateTemplate().findByCriteria(criteria);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByNamedParam(String query, String[] params, String[] values) {
        return (List<T>) getHibernateTemplate().findByNamedParam(query, params, values);
    }

    @Override
    public List<T> saveOrUpdateAll(List<T> entities) {
        getHibernateTemplate().saveOrUpdateAll(entities);     
        return entities;
    }    
}
