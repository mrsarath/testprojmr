package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ta06_bank")
public class BankEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BANK_ID")
    private Long oid;

    @Column(name = "BANK_NAME", nullable = false, length = 30)
    private String name;

    @OneToMany(mappedBy = "bank")
    private Set<BankCfgAttrEntity> bankCfgAttr;

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<BankCfgAttrEntity> getBankCfgAttr() {
        return bankCfgAttr;
    }

    public void setBankCfgAttr(Set<BankCfgAttrEntity> bankCfgAttr) {
        this.bankCfgAttr = bankCfgAttr;
    }

}
