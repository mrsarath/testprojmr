package com.nets.sg.npx.core.dao.mss;

import java.util.List;

import com.nets.sg.npx.core.dao.GenericDao;
import com.nets.sg.npx.core.persistence.entity.mss.RidingInfoStageEntity;

public interface RidingInfoStageDao extends GenericDao<RidingInfoStageEntity, Long> {

    List<RidingInfoStageEntity> getRidingInfo(String batchNo, String createDate, String status, String rid, String tid, String featId, String subFeatId);

}