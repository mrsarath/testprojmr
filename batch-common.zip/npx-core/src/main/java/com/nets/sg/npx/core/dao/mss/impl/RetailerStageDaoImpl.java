package com.nets.sg.npx.core.dao.mss.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.nets.sg.npx.core.dao.impl.GenericDaoImpl;
import com.nets.sg.npx.core.dao.mss.RetailerStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.RetailerStageEntity;

@Repository
public class RetailerStageDaoImpl extends GenericDaoImpl<RetailerStageEntity, Long> implements RetailerStageDao {

    @Override
    public List<RetailerStageEntity> getRecordsByStatus(String batchNo, String groupId, byte status) {

        DetachedCriteria criteria = DetachedCriteria.forClass(RetailerStageEntity.class);
        criteria.add(Restrictions.eq("batchNo", batchNo));
        criteria.add(Restrictions.eq("grpId", groupId));
        criteria.add(Restrictions.eq("recordStatus", status));
        List<RetailerStageEntity> records = findByCriteria(criteria);
        return records;

    }

    @Override
    public List<RetailerStageEntity> getRecordsByStatus(String createDate, String batchNo, String status) {
        DetachedCriteria criteria = DetachedCriteria.forClass(RetailerStageEntity.class);
                
        criteria.add(Restrictions.eq("recordCreateDate", createDate));
        if (!StringUtils.isEmpty(batchNo))
            criteria.add(Restrictions.eq("batchNo", batchNo));
        
        criteria.add(Restrictions.eq("recordStatus", status));
        List<RetailerStageEntity> records = findByCriteria(criteria);
        return records;
    }

}
