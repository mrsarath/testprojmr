package com.nets.sg.npx.core.persistence.entity.mss;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ttr14_mss_stage_retailer")
public class RetailerStageEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RETAILER_ID")
    private Long retailerId;

    @Column(name = "RECORD_STATUS")
    private String recordStatus; // status of this staging record

    @Column(name = "RECORD_DATE", nullable = false)
    private Date recordDate; // last updated date of this staging record status

    @Column(name = "RECORD_CREATED_DATE", nullable = false)
    private String recordCreateDate;

    @Column(name = "BATCH_NO", nullable = false)
    private String batchNo;

    @Column(name = "RET_ID")
    private String retId;

    @Column(name = "MERCHANT_ID")
    private String merchantId;

    @Column(name = "GRP_ID")
    private String grpId;

    @Column(name = "TERM_TEMP_IND")
    private String termTempInd;

    @Column(name = "DUMMY_REC_IND")
    private String dummyRecInd;

    @Column(name = "CONTACT_TITLE")
    private String contactTitle;

    @Column(name = "CONTACT_NAME")
    private String contactName;

    @Column(name = "RET_COB_IND")
    private String retCobInd;

    @Column(name = "TEL1_NO")
    private String tel1No;

    @Column(name = "TEL1_EXT")
    private String tel1Ext;

    @Column(name = "TEL2_NO")
    private String tel2No;

    @Column(name = "TEL2_EXT")
    private String tel2Ext;

    @Column(name = "FAX_NO")
    private String faxNo;

    @Column(name = "OUTLET_ADDR1")
    private String outletAddr1;

    @Column(name = "OUTLET_ADDR2")
    private String outletAddr2;

    @Column(name = "OUTLET_ADDR3")
    private String outletAddr3;

    @Column(name = "OUTLET_POSTCODE")
    private String outletPostcode;

    @Column(name = "TRADING_NAME")
    private String tradingName;

    @Column(name = "ABB_NAME")
    private String abbName;

    @Column(name = "INV_PRT_NAME")
    private String invPrtName;

    @Column(name = "RCP_CO_NAME")
    private String rcpCoName;

    @Column(name = "RCP_OUTLET_LOC")
    private String rcpOutletLoc;

    @Column(name = "RCP_CO_SLOGAN")
    private String rcpCoSlogan;

    @Column(name = "ACCT_NO")
    private String acctNo;

    @Column(name = "CREDIT_ACCT_NAME")
    private String creditAcctName;

    @Column(name = "CREDIT_APPROVED_DATE")
    private String creditApprovedDate;

    @Column(name = "CREDIT_REJ_DATE")
    private String creditRejDate;

    @Column(name = "CREDIT_REJ_REASON")
    private String creditRejReason;

    @Column(name = "FIID")
    private String fiid;

    @Column(name = "SSIC")
    private String ssic;

    @Column(name = "SSIC_CAT_DESC")
    private char ssicCatDesc;

    @Column(name = "SSIC2000")
    private String ssic2000;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "STATUS_EFF_DATE")
    private String statusEffDate;

    // dd/MM/yyyy 20/01/2014:09:47:19
    @Column(name = "CREATED_DATE")
    private String createdDate;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "OWNER")
    private String owner;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private String updatedDate;

    @Column(name = "EFF_DATE")
    private String effDate;

    @Column(name = "FUNCTION_ID")
    private String functionId;

    @Column(name = "CUP_MID")
    private String cupMid;

    @Column(name = "CUP_SSIC")
    private String cupSsic;

    @Column(name = "SCHOOL_PROJECT_IND")
    private String schoolProjectInd;

    @Column(name = "MCYS_CODE")
    private String mcysCode;

    @Column(name = "MERCHANT_TYPE")
    private String merchantType;

    public Long getRetailerId() {
        return retailerId;
    }

    public void setRetailerId(Long retailerId) {
        this.retailerId = retailerId;
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getRetId() {
        return retId;
    }

    public void setRetId(String retId) {
        this.retId = retId;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getGrpId() {
        return grpId;
    }

    public void setGrpId(String grpId) {
        this.grpId = grpId;
    }

    public String getTermTempInd() {
        return termTempInd;
    }

    public void setTermTempInd(String termTempInd) {
        this.termTempInd = termTempInd;
    }

    public String getDummyRecInd() {
        return dummyRecInd;
    }

    public void setDummyRecInd(String dummyRecInd) {
        this.dummyRecInd = dummyRecInd;
    }

    public String getContactTitle() {
        return contactTitle;
    }

    public void setContactTitle(String contactTitle) {
        this.contactTitle = contactTitle;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getRetCobInd() {
        return retCobInd;
    }

    public void setRetCobInd(String retCobInd) {
        this.retCobInd = retCobInd;
    }

    public String getTel1No() {
        return tel1No;
    }

    public void setTel1No(String tel1No) {
        this.tel1No = tel1No;
    }

    public String getTel1Ext() {
        return tel1Ext;
    }

    public void setTel1Ext(String tel1Ext) {
        this.tel1Ext = tel1Ext;
    }

    public String getTel2No() {
        return tel2No;
    }

    public void setTel2No(String tel2No) {
        this.tel2No = tel2No;
    }

    public String getTel2Ext() {
        return tel2Ext;
    }

    public void setTel2Ext(String tel2Ext) {
        this.tel2Ext = tel2Ext;
    }

    public String getFaxNo() {
        return faxNo;
    }

    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    public String getOutletAddr1() {
        return outletAddr1;
    }

    public void setOutletAddr1(String outletAddr1) {
        this.outletAddr1 = outletAddr1;
    }

    public String getOutletAddr2() {
        return outletAddr2;
    }

    public void setOutletAddr2(String outletAddr2) {
        this.outletAddr2 = outletAddr2;
    }

    public String getOutletAddr3() {
        return outletAddr3;
    }

    public void setOutletAddr3(String outletAddr3) {
        this.outletAddr3 = outletAddr3;
    }

    public String getOutletPostcode() {
        return outletPostcode;
    }

    public void setOutletPostcode(String outletPostcode) {
        this.outletPostcode = outletPostcode;
    }

    public String getTradingName() {
        return tradingName;
    }

    public void setTradingName(String tradingName) {
        this.tradingName = tradingName;
    }

    public String getAbbName() {
        return abbName;
    }

    public void setAbbName(String abbName) {
        this.abbName = abbName;
    }

    public String getInvPrtName() {
        return invPrtName;
    }

    public void setInvPrtName(String invPrtName) {
        this.invPrtName = invPrtName;
    }

    public String getRcpCoName() {
        return rcpCoName;
    }

    public void setRcpCoName(String rcpCoName) {
        this.rcpCoName = rcpCoName;
    }

    public String getRcpOutletLoc() {
        return rcpOutletLoc;
    }

    public void setRcpOutletLoc(String rcpOutletLoc) {
        this.rcpOutletLoc = rcpOutletLoc;
    }

    public String getRcpCoSlogan() {
        return rcpCoSlogan;
    }

    public void setRcpCoSlogan(String rcpCoSlogan) {
        this.rcpCoSlogan = rcpCoSlogan;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getCreditAcctName() {
        return creditAcctName;
    }

    public void setCreditAcctName(String creditAcctName) {
        this.creditAcctName = creditAcctName;
    }

    public String getCreditApprovedDate() {
        return creditApprovedDate;
    }

    public void setCreditApprovedDate(String creditApprovedDate) {
        this.creditApprovedDate = creditApprovedDate;
    }

    public String getCreditRejDate() {
        return creditRejDate;
    }

    public void setCreditRejDate(String creditRejDate) {
        this.creditRejDate = creditRejDate;
    }

    public String getCreditRejReason() {
        return creditRejReason;
    }

    public void setCreditRejReason(String creditRejReason) {
        this.creditRejReason = creditRejReason;
    }

    public String getFiid() {
        return fiid;
    }

    public void setFiid(String fiid) {
        this.fiid = fiid;
    }

    public String getSsic() {
        return ssic;
    }

    public void setSsic(String ssic) {
        this.ssic = ssic;
    }

    public char getSsicCatDesc() {
        return ssicCatDesc;
    }

    public void setSsicCatDesc(char ssicCatDesc) {
        this.ssicCatDesc = ssicCatDesc;
    }

    public String getSsic2000() {
        return ssic2000;
    }

    public void setSsic2000(String ssic2000) {
        this.ssic2000 = ssic2000;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusEffDate() {
        return statusEffDate;
    }

    public void setStatusEffDate(String statusEffDate) {
        this.statusEffDate = statusEffDate;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getEffDate() {
        return effDate;
    }

    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public String getCupMid() {
        return cupMid;
    }

    public void setCupMid(String cupMid) {
        this.cupMid = cupMid;
    }

    public String getCupSsic() {
        return cupSsic;
    }

    public void setCupSsic(String cupSsic) {
        this.cupSsic = cupSsic;
    }

    public String getSchoolProjectInd() {
        return schoolProjectInd;
    }

    public void setSchoolProjectInd(String schoolProjectInd) {
        this.schoolProjectInd = schoolProjectInd;
    }

    public String getMcysCode() {
        return mcysCode;
    }

    public void setMcysCode(String mcysCode) {
        this.mcysCode = mcysCode;
    }

    public String getMerchantType() {
        return merchantType;
    }

    public void setMerchantType(String merchantType) {
        this.merchantType = merchantType;
    }

    public String getRecordCreateDate() {
        return recordCreateDate;
    }

    public void setRecordCreateDate(String recordCreateDate) {
        this.recordCreateDate = recordCreateDate;
    }
}
