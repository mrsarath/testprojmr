package com.nets.sg.npx.core.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.CountryDao;
import com.nets.sg.npx.core.persistence.entity.CountryEntity;
import com.nets.sg.npx.core.service.LocaleService;

@Service
public class LocaleServiceImpl implements LocaleService {

    @Autowired
    private CountryDao countryDao;

    @Override
    public CountryEntity getCountryByName(String name) {

        return countryDao.getCountryByName(name);
    }

}
