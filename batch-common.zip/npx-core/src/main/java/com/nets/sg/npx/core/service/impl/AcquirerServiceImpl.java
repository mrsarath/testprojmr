package com.nets.sg.npx.core.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.AcquirerDao;
import com.nets.sg.npx.core.persistence.entity.AcquirerEntity;
import com.nets.sg.npx.core.service.AcquirerService;

@Service("acquirerService")
public class AcquirerServiceImpl implements AcquirerService {

    private static final Logger logger = Logger.getLogger(AcquirerServiceImpl.class);

    @Autowired
    private AcquirerDao acquirerDao;
    
    @Override
    public AcquirerEntity getAcquirerByName(String name) {
        return acquirerDao.getAcquirerByName(name);
    }

 

}
