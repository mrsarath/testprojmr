package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;

import javax.persistence.*;

import java.util.Date;

/**
 * The persistent class for the tp02_physical_pos_cfg database table.
 * 
 */
@Entity
@Table(name = "tp02_physical_pos_cfg")
public class PhysicalPosCfgEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "POS_ID")
    private Long posId;

    @Column(name = "AUTO_POS_TRANSMIT")
    private String autoPosTransmit;

    @Column(name = "CASH_ENABLE")
    private String cashEnable;

    @Column(name = "CHEQUE_ENABLE")
    private String chequeEnable;

    @Column(name = "CREATED_BY")
    private int createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATION_DATE")
    private Date creationDate;

    @Column(name = "CVV_INPUT")
    private String cvvInput;

    @Column(name = "DECRYPTION_SERVICE_ENABLE")
    private int decryptionServiceEnable;

    @Column(name = "DECRYPTION_SERVICE_TYPE")
    private int decryptionServiceType;

    @Column(name = "ENCRYPTION_KEY")
    private String encryptionKey;

    @Column(name = "ERM_GENERATE_RECEIPT")
    private int ermGenerateReceipt;

    @Column(name = "ERM_SERVICE_ENABLE")
    private int ermServiceEnable;

    @Column(name = "INCLUDE_TIP")
    private String includeTip;

    @Column(name = "LAST_UPDATED_BY")
    private int lastUpdatedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATED_DATE")
    private Date lastUpdatedDate;

    @Column(name = "MANUAL_ENTRY_ENABLE")
    private String manualEntryEnable;

    @Column(name = "OFF_LINE_ENABLE")
    private String offLineEnable;

    @Column(name = "PLC_CARD_ENABLE")
    private String plcCardEnable;

    @Column(name = "PRE_AUTH_ENABLE")
    private String preAuthEnable;

    @Column(name = "REFUND_ENABLE")
    private String refundEnable;

    @Column(name = "USER_DATA_INPUT")
    private String userDataInput;
    
    @OneToOne
    @JoinColumn(name = "POS_ID")
    @MapsId
    private PhysicalPosEntity physicalPos;

    public PhysicalPosCfgEntity() {
    }

    public Long getPosId() {
        return this.posId;
    }

    public void setPosId(Long posId) {
        this.posId = posId;
    }

    public String getAutoPosTransmit() {
        return this.autoPosTransmit;
    }

    public void setAutoPosTransmit(String autoPosTransmit) {
        this.autoPosTransmit = autoPosTransmit;
    }

    public String getCashEnable() {
        return this.cashEnable;
    }

    public void setCashEnable(String cashEnable) {
        this.cashEnable = cashEnable;
    }

    public String getChequeEnable() {
        return this.chequeEnable;
    }

    public void setChequeEnable(String chequeEnable) {
        this.chequeEnable = chequeEnable;
    }

    public int getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getCvvInput() {
        return this.cvvInput;
    }

    public void setCvvInput(String cvvInput) {
        this.cvvInput = cvvInput;
    }

    public int getDecryptionServiceEnable() {
        return this.decryptionServiceEnable;
    }

    public void setDecryptionServiceEnable(int decryptionServiceEnable) {
        this.decryptionServiceEnable = decryptionServiceEnable;
    }

    public int getDecryptionServiceType() {
        return this.decryptionServiceType;
    }

    public void setDecryptionServiceType(int decryptionServiceType) {
        this.decryptionServiceType = decryptionServiceType;
    }

    public String getEncryptionKey() {
        return this.encryptionKey;
    }

    public void setEncryptionKey(String encryptionKey) {
        this.encryptionKey = encryptionKey;
    }

    public int getErmGenerateReceipt() {
        return this.ermGenerateReceipt;
    }

    public void setErmGenerateReceipt(int ermGenerateReceipt) {
        this.ermGenerateReceipt = ermGenerateReceipt;
    }

    public int getErmServiceEnable() {
        return this.ermServiceEnable;
    }

    public void setErmServiceEnable(int ermServiceEnable) {
        this.ermServiceEnable = ermServiceEnable;
    }

    public String getIncludeTip() {
        return this.includeTip;
    }

    public void setIncludeTip(String includeTip) {
        this.includeTip = includeTip;
    }

    public int getLastUpdatedBy() {
        return this.lastUpdatedBy;
    }

    public void setLastUpdatedBy(int lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return this.lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getManualEntryEnable() {
        return this.manualEntryEnable;
    }

    public void setManualEntryEnable(String manualEntryEnable) {
        this.manualEntryEnable = manualEntryEnable;
    }

    public String getOffLineEnable() {
        return this.offLineEnable;
    }

    public void setOffLineEnable(String offLineEnable) {
        this.offLineEnable = offLineEnable;
    }

    public String getPlcCardEnable() {
        return this.plcCardEnable;
    }

    public void setPlcCardEnable(String plcCardEnable) {
        this.plcCardEnable = plcCardEnable;
    }

    public String getPreAuthEnable() {
        return this.preAuthEnable;
    }

    public void setPreAuthEnable(String preAuthEnable) {
        this.preAuthEnable = preAuthEnable;
    }

    public String getRefundEnable() {
        return this.refundEnable;
    }

    public void setRefundEnable(String refundEnable) {
        this.refundEnable = refundEnable;
    }

    public String getUserDataInput() {
        return this.userDataInput;
    }

    public void setUserDataInput(String userDataInput) {
        this.userDataInput = userDataInput;
    }

    public PhysicalPosEntity getPhysicalPos() {
        return physicalPos;
    }

    public void setPhysicalPos(PhysicalPosEntity physicalPos) {
        this.physicalPos = physicalPos;
    }

}