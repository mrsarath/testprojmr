package com.nets.sg.npx.core.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.BankDao;
import com.nets.sg.npx.core.persistence.entity.BankEntity;
import com.nets.sg.npx.core.service.BankService;

@Service("bankService")
public class BankServiceImpl implements BankService {

    private static final Logger logger = Logger.getLogger(BankServiceImpl.class);

    @Autowired
    private BankDao bankDao;

    @Override
    public BankEntity getBankEntityByName(String name) {
        return bankDao.getBankEntityByName(name);
    }
}
