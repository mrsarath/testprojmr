package com.nets.sg.npx.core.persistence.entity.mss;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * The persistent class for the ttr16_dwh_sync_term database table.
 * 
 */
@Entity
@Table(name = "ttr15_mss_stage_terminal")
public class TerminalStageEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TERM_RECORD_ID")
    private Long termRecordId;

    @Column(name = "RECORD_STATUS")
    private String recordStatus;

    @Column(name = "RECORD_DATE", nullable = false)
    private Date recordDate;

    @Column(name = "RECORD_CREATED_DATE", nullable = false)
    private String recordCreateDate;

    @Column(name = "BATCH_NO", nullable = false)
    private String batchNo;

    @Column(name = "TERM_ID")
    private String termId;

    @Column(name = "RET_ID")
    private String retId;

    @Column(name = "ACTUAL_START_DATE")
    private String actualStartDate;

    @Column(name = "ACTUAL_STOP_DATE")
    private String actualStopDate;

    @Column(name = "ALLOWED_TRANS")
    private String allowedTrans;

    @Column(name = "CANCEL_IND")
    private String cancelInd;

    @Column(name = "CASHBACK_MAX")
    private String cashbackMax;

    @Column(name = "CASHBACK_MIN")
    private String cashbackMin;

    @Column(name = "CASHBACK_PREDENOM")
    private String cashbackPredenom;

    @Column(name = "CASHIER_SIGN_ON")
    private String cashierSignOn;

    @Column(name = "CIPS_CERTIFIED")
    private String cipsCertified;

    @Column(name = "CLERK_ID")
    private String clerkId;

    @Column(name = "COMBI_IND")
    private String combiInd;

    @Column(name = "CONTEXT_HLD_TIME")
    private String contextHldTime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private String createdDate;

    private String deactivate;

    @Column(name = "DEVICE_DATA")
    private String deviceData;

    @Column(name = "DIAL_OUT_NO")
    private String dialOutNo;

    @Column(name = "DUMMY_REC_IND")
    private String dummyRecInd;

    @Column(name = "EFF_DATE")
    private String effDate;

    @Column(name = "FIID")
    private String fiid;

    @Column(name = "FUNCTION_ID")
    private String functionId;

    @Column(name = "INSTALLATION_DATE")
    private String installationDate;

    @Column(name = "LOGON_DATE")
    private String logonDate;

    @Column(name = "MSG_VER_NO")
    private String msgVerNo;

    @Column(name = "OWNER")
    private String owner;

    @Column(name = "PABX")
    private String pabx;

    @Column(name = "PP_SN")
    private String ppSn;

    @Column(name = "PRIMARY_NO")
    private String primaryNo;

    @Column(name = "PRT_MODEL")
    private String prtModel;

    @Column(name = "PRT_SN")
    private String prtSn;

    @Column(name = "RCP_CO_NAME")
    private String rcpCoName;

    @Column(name = "RCP_CO_SLOGAN")
    private String rcpCoSlogan;

    @Column(name = "RCP_LOC")
    private String rcpLoc;

    @Column(name = "REF_NUM_REQ")
    private String refNumReq;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "RETRIEVAL_DATE")
    private String retrievalDate;

    @Column(name = "RTTN")
    private String rttn;

    @Column(name = "SECONDARY_NO")
    private String secondaryNo;

    @Column(name = "SERVICED_BY")
    private String servicedBy;

    @Column(name = "SOFTWARE_VER")
    private String softwareVer;

    @Column(name = "SR_INPUT_DATE")
    private String srInputDate;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "STATUS_EFF_DATE")
    private String statusEffDate;

    @Column(name = "TECH_CODE")
    private String techCode;

    @Column(name = "TEMP_RETR_IND")
    private String tempRetrInd;

    @Column(name = "TERM_ID_TYP")
    private String termIdTyp;

    @Column(name = "TERM_LINK_ID")
    private String termLinkId;

    @Column(name = "TERM_LOCATION")
    private String termLocation;

    @Column(name = "TERM_MODEL")
    private String termModel;

    @Column(name = "TERM_SCHD_DATE")
    private String termSchdDate;

    @Column(name = "TERM_SCHD_RETR_DATE")
    private String termSchdRetrDate;

    @Column(name = "TERM_TEMP_IND")
    private String termTempInd;

    @Column(name = "TERM_WRITE_OFF_DATE")
    private String termWriteOffDate;

    @Column(name = "TML_SN")
    private String tmlSn;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private String updatedDate;

    // bi-directional many-to-one association to DwhSyncRetailerEntity
    /*
     * @ManyToOne
     * 
     * @JoinColumn(name = "RET_ID", referencedColumnName = "RET_ID") private
     * SyncRetailerEntity ttr14DwhSyncRetailer;
     */

    @Column(name = "MODEL_NO")
    private String modelNo;

    @Column(name = "LAST_UPDATE_DATE")
    private String lastupdateDate;

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public TerminalStageEntity() {
    }

    public String getActualStartDate() {
        return this.actualStartDate;
    }

    public void setActualStartDate(String actualStartDate) {
        this.actualStartDate = actualStartDate;
    }

    public String getActualStopDate() {
        return this.actualStopDate;
    }

    public void setActualStopDate(String actualStopDate) {
        this.actualStopDate = actualStopDate;
    }

    public String getAllowedTrans() {
        return this.allowedTrans;
    }

    public void setAllowedTrans(String allowedTrans) {
        this.allowedTrans = allowedTrans;
    }

    public String getCancelInd() {
        return this.cancelInd;
    }

    public void setCancelInd(String cancelInd) {
        this.cancelInd = cancelInd;
    }

    public String getCashbackMax() {
        return this.cashbackMax;
    }

    public void setCashbackMax(String cashbackMax) {
        this.cashbackMax = cashbackMax;
    }

    public String getCashbackMin() {
        return this.cashbackMin;
    }

    public void setCashbackMin(String cashbackMin) {
        this.cashbackMin = cashbackMin;
    }

    public String getCashbackPredenom() {
        return this.cashbackPredenom;
    }

    public void setCashbackPredenom(String cashbackPredenom) {
        this.cashbackPredenom = cashbackPredenom;
    }

    public String getCashierSignOn() {
        return this.cashierSignOn;
    }

    public void setCashierSignOn(String cashierSignOn) {
        this.cashierSignOn = cashierSignOn;
    }

    public String getCipsCertified() {
        return this.cipsCertified;
    }

    public void setCipsCertified(String cipsCertified) {
        this.cipsCertified = cipsCertified;
    }

    public String getClerkId() {
        return this.clerkId;
    }

    public void setClerkId(String clerkId) {
        this.clerkId = clerkId;
    }

    public String getCombiInd() {
        return this.combiInd;
    }

    public void setCombiInd(String combiInd) {
        this.combiInd = combiInd;
    }

    public String getContextHldTime() {
        return this.contextHldTime;
    }

    public void setContextHldTime(String contextHldTime) {
        this.contextHldTime = contextHldTime;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getDeactivate() {
        return this.deactivate;
    }

    public void setDeactivate(String deactivate) {
        this.deactivate = deactivate;
    }

    public String getDeviceData() {
        return this.deviceData;
    }

    public void setDeviceData(String deviceData) {
        this.deviceData = deviceData;
    }

    public String getDialOutNo() {
        return this.dialOutNo;
    }

    public void setDialOutNo(String dialOutNo) {
        this.dialOutNo = dialOutNo;
    }

    public String getDummyRecInd() {
        return this.dummyRecInd;
    }

    public void setDummyRecInd(String dummyRecInd) {
        this.dummyRecInd = dummyRecInd;
    }

    public String getEffDate() {
        return this.effDate;
    }

    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }

    public String getFiid() {
        return this.fiid;
    }

    public void setFiid(String fiid) {
        this.fiid = fiid;
    }

    public String getFunctionId() {
        return this.functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public String getInstallationDate() {
        return this.installationDate;
    }

    public void setInstallationDate(String installationDate) {
        this.installationDate = installationDate;
    }

    public String getLogonDate() {
        return this.logonDate;
    }

    public void setLogonDate(String logonDate) {
        this.logonDate = logonDate;
    }

    public String getMsgVerNo() {
        return this.msgVerNo;
    }

    public void setMsgVerNo(String msgVerNo) {
        this.msgVerNo = msgVerNo;
    }

    public String getOwner() {
        return this.owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getPabx() {
        return this.pabx;
    }

    public void setPabx(String pabx) {
        this.pabx = pabx;
    }

    public String getPpSn() {
        return this.ppSn;
    }

    public void setPpSn(String ppSn) {
        this.ppSn = ppSn;
    }

    public String getPrimaryNo() {
        return this.primaryNo;
    }

    public void setPrimaryNo(String primaryNo) {
        this.primaryNo = primaryNo;
    }

    public String getPrtModel() {
        return this.prtModel;
    }

    public void setPrtModel(String prtModel) {
        this.prtModel = prtModel;
    }

    public String getPrtSn() {
        return this.prtSn;
    }

    public void setPrtSn(String prtSn) {
        this.prtSn = prtSn;
    }

    public String getRcpCoName() {
        return this.rcpCoName;
    }

    public void setRcpCoName(String rcpCoName) {
        this.rcpCoName = rcpCoName;
    }

    public String getRcpCoSlogan() {
        return this.rcpCoSlogan;
    }

    public void setRcpCoSlogan(String rcpCoSlogan) {
        this.rcpCoSlogan = rcpCoSlogan;
    }

    public String getRcpLoc() {
        return this.rcpLoc;
    }

    public void setRcpLoc(String rcpLoc) {
        this.rcpLoc = rcpLoc;
    }

    public String getRefNumReq() {
        return this.refNumReq;
    }

    public void setRefNumReq(String refNumReq) {
        this.refNumReq = refNumReq;
    }

    public String getRemarks() {
        return this.remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRetrievalDate() {
        return this.retrievalDate;
    }

    public void setRetrievalDate(String retrievalDate) {
        this.retrievalDate = retrievalDate;
    }

    public String getRttn() {
        return this.rttn;
    }

    public void setRttn(String rttn) {
        this.rttn = rttn;
    }

    public String getSecondaryNo() {
        return this.secondaryNo;
    }

    public void setSecondaryNo(String secondaryNo) {
        this.secondaryNo = secondaryNo;
    }

    public String getServicedBy() {
        return this.servicedBy;
    }

    public void setServicedBy(String servicedBy) {
        this.servicedBy = servicedBy;
    }

    public String getSoftwareVer() {
        return this.softwareVer;
    }

    public void setSoftwareVer(String softwareVer) {
        this.softwareVer = softwareVer;
    }

    public String getSrInputDate() {
        return this.srInputDate;
    }

    public void setSrInputDate(String srInputDate) {
        this.srInputDate = srInputDate;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusEffDate() {
        return this.statusEffDate;
    }

    public void setStatusEffDate(String statusEffDate) {
        this.statusEffDate = statusEffDate;
    }

    public String getTechCode() {
        return this.techCode;
    }

    public void setTechCode(String techCode) {
        this.techCode = techCode;
    }

    public String getTempRetrInd() {
        return this.tempRetrInd;
    }

    public void setTempRetrInd(String tempRetrInd) {
        this.tempRetrInd = tempRetrInd;
    }

    public String getTermId() {
        return this.termId;
    }

    public void setTermId(String termId) {
        this.termId = termId;
    }

    public String getTermIdTyp() {
        return this.termIdTyp;
    }

    public void setTermIdTyp(String termIdTyp) {
        this.termIdTyp = termIdTyp;
    }

    public String getTermLinkId() {
        return this.termLinkId;
    }

    public void setTermLinkId(String termLinkId) {
        this.termLinkId = termLinkId;
    }

    public String getTermLocation() {
        return this.termLocation;
    }

    public void setTermLocation(String termLocation) {
        this.termLocation = termLocation;
    }

    public String getTermModel() {
        return this.termModel;
    }

    public void setTermModel(String termModel) {
        this.termModel = termModel;
    }

    public String getTermSchdDate() {
        return this.termSchdDate;
    }

    public void setTermSchdDate(String termSchdDate) {
        this.termSchdDate = termSchdDate;
    }

    public String getTermSchdRetrDate() {
        return this.termSchdRetrDate;
    }

    public void setTermSchdRetrDate(String termSchdRetrDate) {
        this.termSchdRetrDate = termSchdRetrDate;
    }

    public String getTermTempInd() {
        return this.termTempInd;
    }

    public void setTermTempInd(String termTempInd) {
        this.termTempInd = termTempInd;
    }

    public String getTermWriteOffDate() {
        return this.termWriteOffDate;
    }

    public void setTermWriteOffDate(String termWriteOffDate) {
        this.termWriteOffDate = termWriteOffDate;
    }

    public String getTmlSn() {
        return this.tmlSn;
    }

    public void setTmlSn(String tmlSn) {
        this.tmlSn = tmlSn;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getRetId() {
        return retId;
    }

    public void setRetId(String retId) {
        this.retId = retId;
    }

    public String getModelNo() {
        return modelNo;
    }

    public void setModelNo(String modelNo) {
        this.modelNo = modelNo;
    }

    public String getLastupdateDate() {
        return lastupdateDate;
    }

    public void setLastupdateDate(String lastupdateDate) {
        this.lastupdateDate = lastupdateDate;
    }

    public String getRecordCreateDate() {
        return recordCreateDate;
    }

    public void setRecordCreateDate(String recordCreateDate) {
        this.recordCreateDate = recordCreateDate;
    }

    public Long getTermRecordId() {
        return termRecordId;
    }

    public void setTermRecordId(Long termRecordId) {
        this.termRecordId = termRecordId;
    }

    /*
     * public SyncRetailerEntity getTtr14DwhSyncRetailer() { return
     * this.ttr14DwhSyncRetailer; }
     * 
     * public void setTtr14DwhSyncRetailer(SyncRetailerEntity
     * ttr14DwhSyncRetailer) { this.ttr14DwhSyncRetailer = ttr14DwhSyncRetailer;
     * }
     */

}