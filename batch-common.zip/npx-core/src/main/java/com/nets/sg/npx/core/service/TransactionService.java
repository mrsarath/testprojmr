package com.nets.sg.npx.core.service;

import java.util.Date;
import java.util.List;

import com.nets.sg.npx.core.persistence.entity.TransactionEntity;


public interface TransactionService {

    List<TransactionEntity> getTransactionForMerchantSettlement(Date from, Date to, List<Long> acquirers, String merchantType);

    List<TransactionEntity> getByState(String... state);
    
    /**
     * @param from  - settlement from date
     * @param to    - settlement to date
     * @param state - settlement status
     * @return List of TransactionEntity  
     */
    List<TransactionEntity> getSettledTxnsByDate(Date from, Date to, String... state);

    List<TransactionEntity> getTransactionByCardTypeAndState(Date from, Date to, String cardType, String... state);

    List<TransactionEntity> getTxnsForMonthlyReportDataBuild(Date from, Date to, String merchantType);

    
    /**
     * - using for sap monthly gl (biling, collection) files
     * 
     */
    List<TransactionEntity> getPaidTxnsByDate(Date from, Date to, String payStatus, String merchantType);
    
    /**
     * @param from - settlement from date
     * @param to   - settlement to date
     * @return List of TransactionEntity
     * 
     * Get Settled Transactions by filtering on setttled date and merchant type
     */
    List<TransactionEntity> getTransactionsForGLUpload(Date from, Date to, String merchantType);
    
    List<TransactionEntity> saveAll(List<TransactionEntity> trans);

    List<TransactionEntity> getTxnsForMonthlyGLFile(Date from, Date to, String merchantType);

}
