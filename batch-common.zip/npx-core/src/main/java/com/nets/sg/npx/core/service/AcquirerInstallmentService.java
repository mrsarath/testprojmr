package com.nets.sg.npx.core.service;

import com.nets.sg.npx.core.persistence.entity.AcquirerInstallmentEntity;

public interface AcquirerInstallmentService {
    
    AcquirerInstallmentEntity getByAcquirerAndTerm(int acquirerId, int payTerm);

}
