package com.nets.sg.npx.core.dao.impl;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.SapDataMappingConfigDao;
import com.nets.sg.npx.core.persistence.entity.SapDataMappingConfigEntity;

@Repository
public class SapDataMappingConfigDaoImpl extends GenericDaoImpl<SapDataMappingConfigEntity, Long> implements SapDataMappingConfigDao {

    @Override
    public SapDataMappingConfigEntity getByDocTypeAndMapping(String docType, String mapping) {
        DetachedCriteria criteria = DetachedCriteria.forClass(SapDataMappingConfigEntity.class, "sap");
        criteria.add(Restrictions.eq("header", docType));
        criteria.add(Restrictions.eq("mapping", mapping));
        return DataAccessUtils.uniqueResult(this.findByCriteria(criteria));

    }

    @Override
    public SapDataMappingConfigEntity getByDocTypeMappingAndType(String docType, String mapping, String type) {
        DetachedCriteria criteria = DetachedCriteria.forClass(SapDataMappingConfigEntity.class, "sap");
        criteria.add(Restrictions.eq("header", docType));
        criteria.add(Restrictions.eq("mapping", mapping));
        criteria.add(Restrictions.eq("debitCreditType", type));
        return DataAccessUtils.uniqueResult(this.findByCriteria(criteria));
    }

}
