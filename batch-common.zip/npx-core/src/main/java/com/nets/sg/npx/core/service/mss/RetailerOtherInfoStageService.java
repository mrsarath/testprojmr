package com.nets.sg.npx.core.service.mss;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.mss.RetailerOtherInfoStageEntity;

public interface RetailerOtherInfoStageService {

    RetailerOtherInfoStageEntity save(RetailerOtherInfoStageEntity record);

    List<RetailerOtherInfoStageEntity> getRecords(String retId, String createDate, String batchNo, byte status);

    RetailerOtherInfoStageEntity update(RetailerOtherInfoStageEntity retailer);

}
