package com.nets.sg.npx.core.service.impl;

import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nets.sg.npx.core.dao.AcquirerMerchantMappingDao;
import com.nets.sg.npx.core.persistence.entity.AcqMerchantInstallmentEntity;
import com.nets.sg.npx.core.persistence.entity.AcquirerMerchantMappingEntity;
import com.nets.sg.npx.core.service.AcquirerMerchantMappingService;

@Service("acquirerMerchantMappingService")
public class AcquirerMerchantMappingServiceImpl implements AcquirerMerchantMappingService {

    private static final Logger logger = Logger.getLogger(AcquirerMerchantMappingServiceImpl.class);

    @Autowired
    private AcquirerMerchantMappingDao acquirerMerchantMappingDao;

    /* Get Record using Merchant, Acquirer */
    @Override
    public AcquirerMerchantMappingEntity getByAcqMerchant(Long merchantId, Long acquirerId, String... paths) {
        return acquirerMerchantMappingDao.getByAcqMerchant(merchantId, acquirerId, paths);
    }
    
    @Override
    public AcquirerMerchantMappingEntity getByAcqMerchantWithInstallments(Long merchantId, Long acquirerId) {
        
        return acquirerMerchantMappingDao.getByAcqMerchantWithInstallments(merchantId, acquirerId);
    }
    
    

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public AcquirerMerchantMappingEntity save(AcquirerMerchantMappingEntity entity) {

        return acquirerMerchantMappingDao.save(entity);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public AcquirerMerchantMappingEntity update(AcquirerMerchantMappingEntity entity) {
        return acquirerMerchantMappingDao.saveOrUpdate(entity);
    }

}
