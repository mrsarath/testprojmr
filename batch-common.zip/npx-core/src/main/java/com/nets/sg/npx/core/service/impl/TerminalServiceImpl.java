package com.nets.sg.npx.core.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nets.sg.npx.core.dao.TerminalDao;
import com.nets.sg.npx.core.persistence.entity.PhysicalPosEntity;
import com.nets.sg.npx.core.service.TerminalService;

@Service("terminalService")
public class TerminalServiceImpl implements TerminalService {

    private static final Logger logger = Logger.getLogger(TerminalServiceImpl.class);

    @Autowired
    private TerminalDao terminalDao;

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public PhysicalPosEntity save(PhysicalPosEntity terminal) {
        return terminalDao.save(terminal);
    }
    
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public PhysicalPosEntity update(PhysicalPosEntity terminal) {
        return terminalDao.saveOrUpdate(terminal);
    }

    @Override
    public PhysicalPosEntity getTerminalByName(String name) {
        return terminalDao.getTerminalByName(name);
    }

}
