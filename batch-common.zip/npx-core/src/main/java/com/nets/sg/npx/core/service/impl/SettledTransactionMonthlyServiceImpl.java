package com.nets.sg.npx.core.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nets.sg.npx.core.persistence.entity.SettledTransactionMonthlyEntity;
import com.nets.sg.npx.core.service.SettledTransactionMonthlyService;
import com.nets.sg.npx.core.dao.SettledTransactionMonthlyDao;

@Service("settledTransactionMonthlyService")
public class SettledTransactionMonthlyServiceImpl implements SettledTransactionMonthlyService {

    @Autowired
    SettledTransactionMonthlyDao settledTransactionMonthlyDao;

    @Override
    public SettledTransactionMonthlyEntity getRecordByMerchantAcquirerAndMonth(Long merchantId, Long acquirerId, String year, String month) {
        
        return settledTransactionMonthlyDao.getRecordByMerchatAcquirerAndMonth(merchantId, acquirerId, year, month);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public SettledTransactionMonthlyEntity saveOrUpdate(SettledTransactionMonthlyEntity monthly) {

        return settledTransactionMonthlyDao.saveOrUpdate(monthly);
    }

}
