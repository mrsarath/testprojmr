package com.nets.sg.npx.core.dao;

import com.nets.sg.npx.core.persistence.entity.AcquirerInstallmentEntity;

public interface AcquirerInstallmentDao extends GenericDao<AcquirerInstallmentEntity, Long> {
    
    AcquirerInstallmentEntity getByAcquirerAndTerm(int acquirerId, int payTerm);

}
