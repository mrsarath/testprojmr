package com.nets.sg.npx.core.dao;

import com.nets.sg.npx.core.persistence.entity.BankEntity;


public interface BankDao extends GenericDao<BankEntity, Long> {

    BankEntity getBankEntityByName(String name);

}
