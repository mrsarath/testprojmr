package com.nets.sg.npx.core.dao.mss;

import java.util.List;

import com.nets.sg.npx.core.dao.GenericDao;
import com.nets.sg.npx.core.persistence.entity.mss.RetailerOtherInfoStageEntity;

public interface RetailerOtherInfoStageDao extends GenericDao<RetailerOtherInfoStageEntity, Long> {    

    List<RetailerOtherInfoStageEntity> getRecordsByStatus(String retId, String createDate, String batchNo, byte status);
    

}
