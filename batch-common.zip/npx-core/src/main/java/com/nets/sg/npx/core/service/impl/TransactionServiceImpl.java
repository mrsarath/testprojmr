package com.nets.sg.npx.core.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nets.sg.npx.core.dao.TransactionDao;
import com.nets.sg.npx.core.persistence.entity.TransactionEntity;
import com.nets.sg.npx.core.service.TransactionService;
import com.nets.sg.npx.core.util.CommonConsts;

@Service("transactionService")
public class TransactionServiceImpl implements TransactionService {

    private static final Logger logger = Logger.getLogger(TransactionServiceImpl.class);

    @Autowired
    private TransactionDao transactionDao;

    /**
     * This method is added for NPX batch to UOB
     * 
     * @param from
     *            : transaction start date ,previous (or last process) date 11
     *            p.m.<YYYYMMDDHHMMSS>
     * @param to
     *            : transaction end date , today's date 11 p.m. <YYYYMMDDHHMMSS>
     * @param acquirers
     *            : OID of acquiring bank <UOB>
     * @param merchantType
     *            : master merchant <MM>
     * @return
     */
    @Transactional
    public List<TransactionEntity> getTransactionForMerchantSettlement(Date from, Date to, List<Long> acquirers, String merchantType) {
        return transactionDao.getTransactionForMerchantSettlement(from, to, acquirers, merchantType, CommonConsts.TRAN_STATE_SETTLED, CommonConsts.TRAN_STATE_RECONCILLED);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public List<TransactionEntity> saveAll(List<TransactionEntity> trans) {
        return transactionDao.saveOrUpdateAll(trans);
    }

    @Override
    @Transactional
    public List<TransactionEntity> getByState(String... state) {
        return transactionDao.getByState(state);
    }

    @Override
    public List<TransactionEntity> getSettledTxnsByDate(Date from, Date to, String... state) {
        return transactionDao.getBySettledDateAndStateAndMType(from, to, "", state);
    }

    @Override
    public List<TransactionEntity> getTxnsForMonthlyReportDataBuild(Date from, Date to, String merchantType) {
        return transactionDao.getBySettledDateAndStateAndMType(from, to, merchantType, CommonConsts.TRAN_STATE_SETTLED, CommonConsts.TRAN_STATE_RECONCILLED);
    }

    @Override
    public List<TransactionEntity> getTransactionsForGLUpload(Date from, Date to, String merchantType) {
        return transactionDao.getTransactionsForGLUpload(from, to, merchantType, CommonConsts.TRAN_STATE_SETTLED, CommonConsts.TRAN_STATE_RECONCILLED);

    }

    /* consider remove it if not using anywhere */
    @Override
    public List<TransactionEntity> getPaidTxnsByDate(Date from, Date to, String payStatus, String merchantType) {

        return transactionDao.getBySettledDateAndPayStatus(from, to, payStatus, merchantType);
    }

    @Override
    public List<TransactionEntity> getTxnsForMonthlyGLFile(Date from, Date to, String merchantType) {

        return transactionDao.getBySettledDateAndStateAndMType(from, to, merchantType, CommonConsts.TRAN_STATE_SETTLED, CommonConsts.TRAN_STATE_RECONCILLED);

    }

    @Override
    public List<TransactionEntity> getTransactionByCardTypeAndState(Date from, Date to, String cardType, String... state) {
        // TODO Auto-generated method stub
        return transactionDao.getTransactionByCardTypeAndState(from, to, cardType, state);
    }
}
