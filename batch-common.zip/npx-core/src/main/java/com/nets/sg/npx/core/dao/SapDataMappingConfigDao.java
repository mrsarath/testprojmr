package com.nets.sg.npx.core.dao;

import com.nets.sg.npx.core.persistence.entity.SapDataMappingConfigEntity;


public interface SapDataMappingConfigDao extends GenericDao<SapDataMappingConfigEntity, Long> {

    SapDataMappingConfigEntity getByDocTypeAndMapping(String docType , String mapping);

    SapDataMappingConfigEntity getByDocTypeMappingAndType(String docType, String mapping, String type);
}
