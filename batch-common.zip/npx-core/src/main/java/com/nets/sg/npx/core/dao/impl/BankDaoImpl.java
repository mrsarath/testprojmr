package com.nets.sg.npx.core.dao.impl;

import org.hibernate.FetchMode;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.BankDao;
import com.nets.sg.npx.core.persistence.entity.BankEntity;

@Repository
public class BankDaoImpl extends GenericDaoImpl<BankEntity, Long> implements BankDao {

    @Override
    public BankEntity getBankEntityByName(String name) {
        DetachedCriteria criteria = DetachedCriteria.forClass(BankEntity.class, "bank");
        criteria.setFetchMode("bankCfgAttr", FetchMode.JOIN);
        criteria.add(Restrictions.eq("name", name));
        return DataAccessUtils.uniqueResult(this.findByCriteria(criteria));
    }

}
