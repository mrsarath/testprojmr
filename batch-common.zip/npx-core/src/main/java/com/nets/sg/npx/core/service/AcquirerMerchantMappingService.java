package com.nets.sg.npx.core.service;

import com.nets.sg.npx.core.persistence.entity.AcquirerMerchantMappingEntity;

public interface AcquirerMerchantMappingService {

    AcquirerMerchantMappingEntity getByAcqMerchant(Long merchantId, Long acquierId, String... paths);
    
    AcquirerMerchantMappingEntity save(AcquirerMerchantMappingEntity entity);    

    AcquirerMerchantMappingEntity update(AcquirerMerchantMappingEntity entity);

    /* */
    AcquirerMerchantMappingEntity getByAcqMerchantWithInstallments(Long merchantId, Long acquirerId);
}
