package com.nets.sg.npx.core.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections.keyvalue.DefaultKeyValue;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import com.nets.sg.npx.core.exception.SystemException;



/**
 * Update Spring managed properties
 */

public class PropertyUtil extends PropertyPlaceholderConfigurer {

    private static final Logger logger = Logger.getLogger(PropertyUtil.class);

    private static Map<String, String> propertiesMap = new HashMap<String, String>();

    @Override
    protected void loadProperties(final Properties props) throws IOException {
        super.loadProperties(props);
        for (final Object key : props.keySet()) {
            propertiesMap.put((String) key, props.getProperty((String) key));
        }
    }

    /**
     * Return a property loaded by the place holder.
     * 
     * @param name
     *            the property name.
     * @return the property value.
     */
    public static String getProperty(final String name) {
        return propertiesMap.get(name);
    }

    /**
     * Update managed properties with new value
     */
    public void updateProperties(DefaultKeyValue pair) throws SystemException {

        try {
            PropertiesConfiguration properties = new PropertiesConfiguration(propertiesMap.get("batch.local.configuration"));
            properties.setProperty(pair.getKey().toString(), pair.getValue().toString());
            properties.save();
        } catch (Exception e) {
            logger.error(e);
            throw new SystemException(e.getMessage());
        }
    }

}
