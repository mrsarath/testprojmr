package com.nets.sg.npx.core.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.nets.sg.npx.core.dao.CodesDao;
import com.nets.sg.npx.core.persistence.entity.CodesEntity;
import com.nets.sg.npx.core.service.CodesService;

@Service("codesService")
public class CodesServiceImpl implements CodesService {

    private static final Logger logger = Logger.getLogger(CodesServiceImpl.class);

    @Autowired
    private CodesDao codesDao;

    @Override
    public Map<Integer, String> getCodesByName(String name) {
        Map<Integer, String> values = new HashMap<>();
        List<CodesEntity> codes = codesDao.getCodesByType(name);
        if (CollectionUtils.isEmpty(codes)) {
            logger.error("no codes found for name[" + name + "].");
        } else {
            for (CodesEntity code : codes) {
                logger.debug("loading [" + code + "].");
                values.put(code.getValue(), code.getCode());
            }
        }
        return values;
    }
    
    @Override
    public List<CodesEntity> getCodeEntitiesByName(String name) {
        return codesDao.getCodesByType(name);
    }

}
