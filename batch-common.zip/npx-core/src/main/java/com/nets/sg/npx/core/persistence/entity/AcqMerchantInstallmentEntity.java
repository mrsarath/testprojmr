package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

/**
 * The persistent class for the ta15_acq_mer_installment database table.
 * 
 */
@Entity
@Table(name = "ta15_acq_mer_installment")
public class AcqMerchantInstallmentEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ACQ_MER_INST_ID")
    private int acqMerInstId;

    @Column(name = "CREATED_BY")
    private int createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "CUSTOM_MID")
    private String customMid;

    @Column(name = "CUSTOM_TID")
    private String customTid;

    @Column(name = "LAST_UPDATED_BY")
    private int lastUpdatedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATED_DATE")
    private Date lastUpdatedDate;

    @Column(name = "POS_ID", nullable = false)
    private int posId;

    @Column(name = "SOURCE_CURRENCY")
    private String sourceCurrency;

    @Column(name = "TARGET_CURRENCY")
    private String targetCurrency;

    @Column(name = "ACQ_MER_MAPPING_ID", nullable = false)
    private int acqMerMappingId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ACQ_INST_ID", nullable = false)
    private AcquirerInstallmentEntity acqInstallment;

    public AcqMerchantInstallmentEntity() {
    }

    public int getAcqMerInstId() {
        return this.acqMerInstId;
    }

    public void setAcqMerInstId(int acqMerInstId) {
        this.acqMerInstId = acqMerInstId;
    }

    public int getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCustomMid() {
        return this.customMid;
    }

    public void setCustomMid(String customMid) {
        this.customMid = customMid;
    }

    public String getCustomTid() {
        return this.customTid;
    }

    public void setCustomTid(String customTid) {
        this.customTid = customTid;
    }

    public int getLastUpdatedBy() {
        return this.lastUpdatedBy;
    }

    public void setLastUpdatedBy(int lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return this.lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public int getPosId() {
        return this.posId;
    }

    public void setPosId(int posId) {
        this.posId = posId;
    }

    public String getSourceCurrency() {
        return this.sourceCurrency;
    }

    public void setSourceCurrency(String sourceCurrency) {
        this.sourceCurrency = sourceCurrency;
    }

    public String getTargetCurrency() {
        return this.targetCurrency;
    }

    public void setTargetCurrency(String targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    public int getAcqMerMappingId() {
        return acqMerMappingId;
    }

    public void setAcqMerMappingId(int acqMerMappingId) {
        this.acqMerMappingId = acqMerMappingId;
    }

    public AcquirerInstallmentEntity getAcqInstallment() {
        return this.acqInstallment;
    }

    public void setAcqInstallment(AcquirerInstallmentEntity acqInstallment) {
        this.acqInstallment = acqInstallment;
    }

}