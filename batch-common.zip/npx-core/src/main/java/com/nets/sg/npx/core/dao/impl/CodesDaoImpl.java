package com.nets.sg.npx.core.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.CodesDao;
import com.nets.sg.npx.core.persistence.entity.CodesEntity;

@Repository
public class CodesDaoImpl extends GenericDaoImpl<CodesEntity, Long> implements CodesDao {

    @Override
    public List<CodesEntity> getCodesByType(String name) {
        DetachedCriteria criteria = DetachedCriteria.forClass(CodesEntity.class, "codes");
        criteria.add(Restrictions.eq("name", name));
        return findByCriteria(criteria);
    }

}
