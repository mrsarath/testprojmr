package com.nets.sg.npx.core.service;

import java.util.List;
import java.util.Map;

import com.nets.sg.npx.core.model.email.EmailAttachment;

public interface EmailService {

    public boolean sendMail(String from, String to, String subject, String template, Map<String, Object> model);

    public boolean sendMailWithAttachement(String from, String to, String subject, String template, Map<String, Object> model, List<EmailAttachment> attachments);

}
