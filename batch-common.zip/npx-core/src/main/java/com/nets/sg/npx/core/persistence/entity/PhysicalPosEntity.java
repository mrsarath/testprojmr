package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "tp01_physical_pos")
public class PhysicalPosEntity implements Serializable {
    
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "POS_ID")
    private Long oid;

    @Column(name = "RID", nullable = false, length = 50)
    private String retailerId;

    @Column(name = "NAME", nullable = false, length = 50)
    private String name;

    @Column(name = "MERCHANT_ID", nullable = false)
    private Integer merchantId;

    @Column(name = "DBA_NAME", nullable = false)
    private String dbaName;

    @Column(name = "TYPE", nullable = false)
    private String type;

    @Column(name = "STATUS", nullable = false)
    private String status;

    @Column(name = "NOTE", nullable = false)
    private String note;

    @Column(name = "LAST_UPDATED_BY", nullable = false)
    private Integer updatedBy;

    @Column(name = "LAST_UPDATED_DATE", nullable = false)
    private Date updatedDate;

    @Column(name = "CREATED_BY", nullable = false)
    private Integer createdBy;

    @Column(name = "CREATION_DATE", nullable = false)
    private Date createdDate;

    @Column(name = "ACQUIRER_ID", nullable = false)
    private String aquirer;

    @Column(name = "MERCHANT_SALE_ID", nullable = false)
    private Integer merchantSaleId;

    @Column(name = "POS_PERMISSION", nullable = false)
    private String posPermission;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name = "POS_ID", nullable=false)
    private PhysicalPosCfgEntity physicalPosCfg;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="POS_ID", nullable=false)
    private SlipDetailEntity slipDetail;
    
    //@OneToMany(mappedBy = "pos", cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name="POS_ID")
    private Set<AcqMerAccountEntity>  acqMerchantAccounts = new HashSet<>();
    

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getRetailerId() {
        return retailerId;
    }

    public void setRetailerId(String retailerId) {
        this.retailerId = retailerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }

    public String getDbaName() {
        return dbaName;
    }

    public void setDbaName(String dbaName) {
        this.dbaName = dbaName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Integer getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Integer updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getAquirer() {
        return aquirer;
    }

    public void setAquirer(String aquirer) {
        this.aquirer = aquirer;
    }

    public Integer getMerchantSaleId() {
        return merchantSaleId;
    }

    public void setMerchantSaleId(Integer merchantSaleId) {
        this.merchantSaleId = merchantSaleId;
    }

    public String getPosPermission() {
        return posPermission;
    }

    public void setPosPermission(String posPermission) {
        this.posPermission = posPermission;
    }

    public PhysicalPosCfgEntity getPhysicalPosCfg() {
        return physicalPosCfg;
    }

    public void setPhysicalPosCfg(PhysicalPosCfgEntity physicalPosCfg) {
        if (physicalPosCfg != null && oid != null) {
            physicalPosCfg.setPosId(oid.intValue());
            //physicalPosCfg.setPhysicalPos(this);
        }
        this.physicalPosCfg = physicalPosCfg;
    }

    public SlipDetailEntity getSlipDetail() {
        return slipDetail;
    }

    public void setSlipDetail(SlipDetailEntity slipDetail) {        
        if (slipDetail != null && oid != null) {
            slipDetail.setPosId(oid);
            //slipDetail.setTp01PhysicalPo(this);
        }        
        this.slipDetail = slipDetail;
    }
      
    
    public Set<AcqMerAccountEntity> getAcqMerchantAccounts() {
        return acqMerchantAccounts;
    }

    public void setAcqMerchantAccounts(Set<AcqMerAccountEntity> acqMerchantAccounts) {
        this.acqMerchantAccounts = acqMerchantAccounts;
    }

    public AcqMerAccountEntity addAcqMerchantMappings(AcqMerAccountEntity acqMerAccount) {
        getAcqMerchantAccounts().add(acqMerAccount);
        //acqMerAccount.setPos(this);
        if (getOid() != null)
            acqMerAccount.setPos(getOid().intValue());
        
        return acqMerAccount;
    }
    
}
