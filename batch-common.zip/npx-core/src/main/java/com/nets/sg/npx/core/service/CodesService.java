package com.nets.sg.npx.core.service;

import java.util.List;
import java.util.Map;

import com.nets.sg.npx.core.persistence.entity.CodesEntity;

public interface CodesService {

    Map<Integer, String> getCodesByName(String name);

    List<CodesEntity> getCodeEntitiesByName(String name);

}
