package com.nets.sg.npx.core.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.SettledTransactionMonthlyDao;
import com.nets.sg.npx.core.persistence.entity.SettledTransactionMonthlyEntity;

@Repository
public class SettledTransactionMonthlyDaoImpl extends GenericDaoImpl<SettledTransactionMonthlyEntity, Long> implements SettledTransactionMonthlyDao {

    @Override
    public SettledTransactionMonthlyEntity getRecordByMerchatAcquirerAndMonth(Long merchantId, Long acquirerId, String year, String month) {

        DetachedCriteria criteria = DetachedCriteria.forClass(SettledTransactionMonthlyEntity.class);
        criteria.add(Restrictions.eq("merchantId", merchantId));
        criteria.add(Restrictions.eq("acquirerId", acquirerId));
        criteria.add(Restrictions.eq("txnYear", year));
        criteria.add(Restrictions.eq("txnMonth", month));
        
        List<SettledTransactionMonthlyEntity> recList = findByCriteria(criteria);

        SettledTransactionMonthlyEntity record = null;

        if (recList.size() > 0)
            record = recList.get(0);

        return record;

    }

}
