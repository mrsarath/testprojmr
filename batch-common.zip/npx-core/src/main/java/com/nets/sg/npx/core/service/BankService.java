package com.nets.sg.npx.core.service;

import com.nets.sg.npx.core.persistence.entity.BankEntity;

public interface BankService {

    BankEntity getBankEntityByName(String name);

}
