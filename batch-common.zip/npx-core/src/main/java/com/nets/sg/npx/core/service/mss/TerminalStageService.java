package com.nets.sg.npx.core.service.mss;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.mss.TerminalStageEntity;

public interface TerminalStageService {

    List<TerminalStageEntity> getRecords(String batchNo, String retailId, byte status);

    List<TerminalStageEntity> getRecords(String date, String batchNo, String status);

    TerminalStageEntity save(TerminalStageEntity record);

    TerminalStageEntity update(TerminalStageEntity record);

}
