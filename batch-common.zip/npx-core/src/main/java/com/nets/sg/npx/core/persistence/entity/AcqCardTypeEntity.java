package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ta11_acq_card_types")
public class AcqCardTypeEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ACQ_CARD_TYPE_ID")
    private Long oid;

    @ManyToOne
    @JoinColumn(name = "ACQUIRER_ID")
    private AcquirerEntity acquirer;

    @OneToOne
    @JoinColumn(name = "CARD_TYPE_ID")
    private CardTypeEntity cardType;

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public AcquirerEntity getAcquirer() {
        return acquirer;
    }

    public void setAcquirer(AcquirerEntity acquirer) {
        this.acquirer = acquirer;
    }

    public CardTypeEntity getCardType() {
        return cardType;
    }

    public void setCardType(CardTypeEntity cardType) {
        this.cardType = cardType;
    }

}
