package com.nets.sg.npx.core.dao.mss;

import java.util.List;

import com.nets.sg.npx.core.dao.GenericDao;
import com.nets.sg.npx.core.persistence.entity.mss.SyncHqEntity;

public interface SyncHqDao extends GenericDao<SyncHqEntity, Long> {

    List<SyncHqEntity> getRecordsByStatus(byte status);

}
