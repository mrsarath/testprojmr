package com.nets.sg.npx.core.dao;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.MerchantFundingEntity;

public interface MerchantFundingDao extends GenericDao<MerchantFundingEntity, Long> {

    MerchantFundingEntity getMerchantFundingByBatchNo(String batchNo);

    MerchantFundingEntity getSubmittedByFileName(String fileName);

    List<MerchantFundingEntity> getUnPostedSuccessRecords(String svcType);


}
