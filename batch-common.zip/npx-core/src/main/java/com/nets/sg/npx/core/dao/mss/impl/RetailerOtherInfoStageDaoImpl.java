package com.nets.sg.npx.core.dao.mss.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.impl.GenericDaoImpl;
import com.nets.sg.npx.core.dao.mss.RetailerOtherInfoStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.RetailerOtherInfoStageEntity;

@Repository
public class RetailerOtherInfoStageDaoImpl extends GenericDaoImpl<RetailerOtherInfoStageEntity, Long> implements RetailerOtherInfoStageDao {

    @Override
    public List<RetailerOtherInfoStageEntity> getRecordsByStatus(String retailerId, String createDate, String batchNo, byte status) {

        DetachedCriteria criteria = DetachedCriteria.forClass(RetailerOtherInfoStageEntity.class);
        if (!StringUtils.isBlank(retailerId)) {
           criteria.add(Restrictions.eq("retId", retailerId));
        }
        criteria.add(Restrictions.eq("recordCreateDate", createDate));        
        if (!StringUtils.isEmpty(batchNo))
            criteria.add(Restrictions.eq("batchNo", batchNo));
        
        criteria.add(Restrictions.eq("recordStatus", status));

        List<RetailerOtherInfoStageEntity> records = findByCriteria(criteria);

        return records;

    }   

}
