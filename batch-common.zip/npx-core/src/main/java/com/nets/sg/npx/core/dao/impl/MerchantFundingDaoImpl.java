package com.nets.sg.npx.core.dao.impl;

import java.util.List;

import org.springframework.dao.support.DataAccessUtils;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.MerchantFundingDao;
import com.nets.sg.npx.core.persistence.entity.MerchantFundingEntity;
import com.nets.sg.npx.core.util.CommonConsts;

@Repository
public class MerchantFundingDaoImpl extends GenericDaoImpl<MerchantFundingEntity, Long> implements MerchantFundingDao {

    @Override
    public MerchantFundingEntity getMerchantFundingByBatchNo(String batchNo) {

        String query = " select funds from MerchantFundingEntity as funds where funds.batchNum = :batchNo ";
        String[] paramNames = new String[] { "batchNo" };
        String[] values = new String[] { batchNo };

        return DataAccessUtils.uniqueResult(findByNamedParam(query, paramNames, values));
    }

    @Override
    public MerchantFundingEntity getSubmittedByFileName(String fileName) {

        String query = " select funds from MerchantFundingEntity as funds " //
                + " where funds.fileName = :fileName and funds.status = :status ";
        String[] paramNames = new String[] { "fileName", "status" };
        String[] values = new String[] { fileName, CommonConsts.BATCH_STATUS_SUBMITTED };
        return DataAccessUtils.uniqueResult(findByNamedParam(query, paramNames, values));

    }

    @Override
    public List<MerchantFundingEntity> getUnPostedSuccessRecords(String svcType) {

        String query = " select distinct funds from MerchantFundingEntity as funds " //
                + " inner join funds.records as records " //
                + " left outer join records.merchant as merchant "//
                + " left outer join merchant.config " //
                + " where funds.serviceType = :serviceType "//
                + " and records.status = :status " //
                + " and records.posted = :posted";

        String[] paramNames = new String[] { "serviceType", "status", "posted" };
        String[] values = new String[] { svcType, CommonConsts.BATCH_STATUS_SUCCESS, CommonConsts.MERCHANT_FUNDING_RECORD_GLNOTPOSTED };
        return findByNamedParam(query, paramNames, values);
    }

}
