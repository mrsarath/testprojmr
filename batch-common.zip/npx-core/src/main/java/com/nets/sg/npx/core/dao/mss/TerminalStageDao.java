package com.nets.sg.npx.core.dao.mss;

import java.util.List;

import com.nets.sg.npx.core.dao.GenericDao;
import com.nets.sg.npx.core.persistence.entity.mss.TerminalStageEntity;

public interface TerminalStageDao extends GenericDao<TerminalStageEntity, Long> {

    List<TerminalStageEntity> getRecords(String batchNo, String retailId, byte status);

    List<TerminalStageEntity> getRecords(String date, String batchNo, String status);

}
