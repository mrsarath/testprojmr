package com.nets.sg.npx.core.dao.impl;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.AcquirerInstallmentDao;
import com.nets.sg.npx.core.persistence.entity.AcquirerInstallmentEntity;

@Repository
public class AcquirerInstallmentDaoImpl extends GenericDaoImpl<AcquirerInstallmentEntity, Long> implements AcquirerInstallmentDao {

    @Override
    public AcquirerInstallmentEntity getByAcquirerAndTerm(int acquirerId, int payTerm) {
        DetachedCriteria criteria = DetachedCriteria.forClass(AcquirerInstallmentEntity.class);
        criteria.add(Restrictions.eq("acqId", acquirerId));
        criteria.add(Restrictions.eq("paymentTerm", payTerm));

        return DataAccessUtils.uniqueResult(findByCriteria(criteria));

    }

}
