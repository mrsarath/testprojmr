package com.nets.sg.npx.core.dao;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.CodesEntity;

public interface CodesDao extends GenericDao<CodesEntity, Long> {

    List<CodesEntity> getCodesByType(String name);

}
