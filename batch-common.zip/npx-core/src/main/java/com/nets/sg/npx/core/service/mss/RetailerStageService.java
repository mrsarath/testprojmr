package com.nets.sg.npx.core.service.mss;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.mss.RetailerStageEntity;

public interface RetailerStageService {

    RetailerStageEntity save(RetailerStageEntity record);

    List<RetailerStageEntity> getRecords(String batchNo, String groupId, byte status);
    
    List<RetailerStageEntity> getRecords(String createDate, String batchNo, String status);

    RetailerStageEntity update(RetailerStageEntity retailer);

}
