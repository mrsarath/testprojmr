package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tn01_sap_data_mapping_config")
public class SapDataMappingConfigEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DATA_MAPPING_ID")
    private Long oid;

    @Column(name = "DOC_HEADER", length = 40)
    private String header;

    @Column(name = "GL_ACCOUNT_NO", length = 30)
    private String glAccountNo;

    @Column(name = "MAPPING_DESC", length = 40)
    private String mapping;

    @Column(name = "ACCOUNT_NAME")
    private String accountName;

    @Column(name = "POSTING_KEY", length = 2)
    private String postingKey;
    
    @Column(name = "REVERSE_POSTING_KEY", length = 2)
    private String reversePostingKey;

    @Column(name = "DEBIT_CREDIT", length = 1)
    private String debitCreditType;
    
    @Column(name = "COST_CENTRE", length = 40)
    private String costCentre;
    
    @Column(name = "TAX_CODE" , length = 255)
    private String taxCode;

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getGlAccountNo() {
        return glAccountNo;
    }

    public void setGlAccountNo(String glAccountNo) {
        this.glAccountNo = glAccountNo;
    }

    public String getMapping() {
        return mapping;
    }

    public void setMapping(String mapping) {
        this.mapping = mapping;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getPostingKey() {
        return postingKey;
    }

    public void setPostingKey(String postingKey) {
        this.postingKey = postingKey;
    }

    public String getReversePostingKey() {
        return reversePostingKey;
    }

    public void setReversePostingKey(String reversePostingKey) {
        this.reversePostingKey = reversePostingKey;
    }

    public String getDebitCreditType() {
        return debitCreditType;
    }

    public void setDebitCreditType(String debitCreditType) {
        this.debitCreditType = debitCreditType;
    }

    public String getCostCentre() {
        return costCentre;
    }

    public void setCostCentre(String costCentre) {
        this.costCentre = costCentre;
    }

    public String getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode;
    }
      
    

}
