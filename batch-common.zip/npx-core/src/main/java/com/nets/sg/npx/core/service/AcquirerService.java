package com.nets.sg.npx.core.service;

import com.nets.sg.npx.core.persistence.entity.AcquirerEntity;

public interface AcquirerService {

    AcquirerEntity getAcquirerByName(String name);

}
