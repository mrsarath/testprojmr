package com.nets.sg.npx.core.service.impl;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.nets.sg.npx.core.model.email.EmailAttachment;
import com.nets.sg.npx.core.service.EmailService;

@Service("emailService")
public class EmailServiceImpl implements EmailService {

    private static final Logger logger = Logger.getLogger(EmailServiceImpl.class);

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private VelocityEngine velocityEngine;

    /**
     * This method will send compose and send the message
     * */
    public boolean sendMail(final String from, final String to, final String subject, final String template, final Map<String, Object> model) {
        boolean sent = true;
        try {
            MimeMessagePreparator preparator = new MimeMessagePreparator() {
                public void prepare(MimeMessage mimeMessage) throws Exception {
                    MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
                    message.setFrom(from);
                    message.setTo(to.split(","));
                    message.setSubject(subject);
                    String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, template, StandardCharsets.UTF_8.name(), model);
                    message.setText(text, true);

                }
            };
            mailSender.send(preparator);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            sent = false;
        }
        return sent;
    }

    /**
     * This method will send compose and send the message
     * */
    public boolean sendMailWithAttachement(final String from, final String to, final String subject, final String template, final Map<String, Object> model,
            final List<EmailAttachment> attachements) {
        boolean sent = true;
        try {
            MimeMessagePreparator preparator = new MimeMessagePreparator() {
                public void prepare(MimeMessage mimeMessage) throws Exception {
                    MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);
                    message.setFrom(from);
                    message.setTo(to.split(","));
                    message.setSubject(subject);
                    String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, template, StandardCharsets.UTF_8.name(), model);
                    message.setText(text, true);
                    for (EmailAttachment attachement : attachements) {
                        message.addAttachment(attachement.getFileName(), attachement.getFile());
                    }

                }
            };
            mailSender.send(preparator);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            sent = false;
        }
        return sent;
    }

}
