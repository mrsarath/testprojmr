package com.nets.sg.npx.core.service.mss.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.mss.RidingInfoStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.RidingInfoStageEntity;
import com.nets.sg.npx.core.service.mss.RidingInfoStageService;

@Service
public class RidingInfoStageServiceImpl implements RidingInfoStageService {

    @Autowired
    private RidingInfoStageDao syncRidingInfoDao;

    @Override
    public RidingInfoStageEntity save(RidingInfoStageEntity record) {

        return syncRidingInfoDao.save(record);

    }

    @Override
    public List<RidingInfoStageEntity> getRidingInfo(String batchNo, String createDate, String status, String rid, String tid, String featId, String subFeatId) {

        return syncRidingInfoDao.getRidingInfo(batchNo, createDate, status, rid, tid, featId, subFeatId);

    }

    @Override
    public RidingInfoStageEntity update(RidingInfoStageEntity riding) {
        return syncRidingInfoDao.saveOrUpdate(riding);
    }
}
