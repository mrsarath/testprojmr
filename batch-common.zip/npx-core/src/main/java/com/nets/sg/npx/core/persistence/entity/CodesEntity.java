package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tc03_codes")
public class CodesEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CODE_ID")
    private Long oid;

    @Column(name = "CODE_NAME", nullable = false, length = 20)
    private String name;

    @Column(name = "INTEG_REF_VALUE", nullable = false, length = 5)
    private Integer value;

    @Column(name = "CODE_VALUE", nullable = false, length = 255)
    private String code;

    @Column(name = "DESCRIPTION", nullable = false, length = 255)
    private String desp;
    
    @Column(name = "MODULE", nullable = true, length = 50)
    private String module;
    
    @Column(name = "EC_SYSTEM", nullable = true, length = 50)
    private String system;

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesp() {
        return desp;
    }

    public void setDesp(String desp) {
        this.desp = desp;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }
    
    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    @Override
    public String toString() {
        return "CodesEntity [name=" + name + ", value=" + value + ", code=" + code + ", desp=" + desp + ", module=" + module + ", system=" + system + "]";
    }

}