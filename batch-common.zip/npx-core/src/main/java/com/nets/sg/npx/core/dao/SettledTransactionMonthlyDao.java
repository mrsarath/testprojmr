package com.nets.sg.npx.core.dao;

import com.nets.sg.npx.core.persistence.entity.SettledTransactionMonthlyEntity;

public interface SettledTransactionMonthlyDao extends GenericDao<SettledTransactionMonthlyEntity, Long> {

    SettledTransactionMonthlyEntity getRecordByMerchatAcquirerAndMonth(Long merchantId, Long acquirerId, String year, String month);

}
