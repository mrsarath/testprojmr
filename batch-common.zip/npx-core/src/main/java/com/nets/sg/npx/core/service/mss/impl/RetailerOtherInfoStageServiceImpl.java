package com.nets.sg.npx.core.service.mss.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.mss.RetailerOtherInfoStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.RetailerOtherInfoStageEntity;
import com.nets.sg.npx.core.service.mss.RetailerOtherInfoStageService;

@Service
public class RetailerOtherInfoStageServiceImpl implements RetailerOtherInfoStageService {

    @Autowired
    private RetailerOtherInfoStageDao retOtherInfoDao;

    @Override
    public RetailerOtherInfoStageEntity save(RetailerOtherInfoStageEntity record) {

        return retOtherInfoDao.save(record);
    }

    @Override
    public List<RetailerOtherInfoStageEntity> getRecords(String retId, String createDate, String batchNo, byte status) {
        return retOtherInfoDao.getRecordsByStatus(retId, createDate, batchNo, status);
    }

    @Override
    public RetailerOtherInfoStageEntity update(RetailerOtherInfoStageEntity retailer) {
        return retOtherInfoDao.saveOrUpdate(retailer);
    }
}
