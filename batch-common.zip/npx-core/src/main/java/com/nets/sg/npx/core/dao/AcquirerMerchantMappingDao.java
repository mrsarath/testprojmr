package com.nets.sg.npx.core.dao;

import com.nets.sg.npx.core.persistence.entity.AcquirerMerchantMappingEntity;

public interface AcquirerMerchantMappingDao extends GenericDao<AcquirerMerchantMappingEntity, Long> {

    AcquirerMerchantMappingEntity getByAcqMerchant(Long merchantId, Long acquierId, String... paths);

    AcquirerMerchantMappingEntity getByAcqMerchantWithInstallments(Long merchantId, Long acquirerId);

}