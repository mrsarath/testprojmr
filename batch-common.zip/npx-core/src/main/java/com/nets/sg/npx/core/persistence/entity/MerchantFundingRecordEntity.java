package com.nets.sg.npx.core.persistence.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ttr11_batch_merchant_funding_details")
public class MerchantFundingRecordEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MERCHANT_FUNDING_DETAILS_ID")
    private Long oid;

    @Column(name = "AMOUNT", length = 20)
    private String amount;

    @Column(name = "STATUS", length = 2)
    private String status;

    @Column(name = "TRACE", length = 20)
    private String trace;

    @Column(name = "REJ_CODE", length = 20)
    private String rejectionCode;

    @Column(name = "GL_POSTED", length = 1)
    private String posted = "1";

    @Column(name = "GL_FILENAME", length = 20)
    private String postedFileName;

    @ManyToOne
    @JoinColumn(name = "MERCHANT_FUNDING_ID")
    private MerchantFundingEntity funding;

    @OneToOne
    @JoinColumn(name = "MERCHANT_ID")
    private MerchantEntity merchant;

    @OneToMany(mappedBy = "record", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<MerchantFundingTransactionMappingEntity> mappings = new HashSet<>();

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public MerchantFundingEntity getFunding() {
        return funding;
    }

    public void setFunding(MerchantFundingEntity funding) {
        this.funding = funding;
    }

    public boolean addTransactionMapping(MerchantFundingTransactionMappingEntity mapping) {
        return mappings.add(mapping);
    }

    public MerchantEntity getMerchant() {
        return merchant;
    }

    public void setMerchant(MerchantEntity merchant) {
        this.merchant = merchant;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTrace() {
        return trace;
    }

    public void setTrace(String trace) {
        this.trace = trace;
    }

    public String getRejectionCode() {
        return rejectionCode;
    }

    public void setRejectionCode(String rejectionCode) {
        this.rejectionCode = rejectionCode;
    }

    public String getPosted() {
        return posted;
    }

    public void setPosted(String posted) {
        this.posted = posted;
    }

    public String getPostedFileName() {
        return postedFileName;
    }

    public void setPostedFileName(String postedFileName) {
        this.postedFileName = postedFileName;
    }

    public Set<MerchantFundingTransactionMappingEntity> getMappings() {
        return mappings;
    }

    public void setMappings(Set<MerchantFundingTransactionMappingEntity> mappings) {
        this.mappings = mappings;
    }

}
