package com.nets.sg.npx.core.dao.mss.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.impl.GenericDaoImpl;
import com.nets.sg.npx.core.dao.mss.RidingInfoStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.RidingInfoStageEntity;

@Repository
public class RidingInfoStageDaoImpl extends GenericDaoImpl<RidingInfoStageEntity, Long> implements RidingInfoStageDao {

  
    @Override
    public List<RidingInfoStageEntity> getRidingInfo(String batchNo, String createDate, String status, String rid, String tid, String featId, String subFeatId) {
        
        DetachedCriteria criteria = DetachedCriteria.forClass(RidingInfoStageEntity.class);
        
        criteria.add(Restrictions.eq("retId", rid));
        criteria.add(Restrictions.eq("termId", tid));        
        
        criteria.add(Restrictions.eq("recordCreateDate", createDate));        
        if (!StringUtils.isEmpty(batchNo))
            criteria.add(Restrictions.eq("batchNo", batchNo));
        
        criteria.add(Restrictions.eq("recordStatus", status));

        List<RidingInfoStageEntity> records = findByCriteria(criteria);

        return records;
    }

}
