package com.nets.sg.npx.core.service.mss;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.mss.RidingInfoStageEntity;

public interface RidingInfoStageService {

    RidingInfoStageEntity save(RidingInfoStageEntity record);

    List<RidingInfoStageEntity> getRidingInfo(String batchNo, String createDate, String status, String rid, String tid, String featId, String subFeatId);

    RidingInfoStageEntity update(RidingInfoStageEntity riding);    

}
