package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ttr13_settled_transaction_monthly")
public class SettledTransactionMonthlyEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RECORD_ID")
    Long oid;

    @Column(name = "MERCHANT_ID", nullable = false)
    Long merchantId;

    @Column(name = "NETS_CUST_CODE", nullable = true, length = 255)
    private String merchantCode;

    @Column(name = "MERCHANT_NAME", nullable = false, length = 40)
    private String merchantName;

    @Column(name = "ACQUIRER_ID", nullable = false)
    Long acquirerId;

    @Column(name = "TXN_CURRENCY", nullable = false, length = 6)
    private String txnCurrency;

    @Column(name = "TOTTXNFEE_INCL_GST", nullable = true)
    private BigDecimal totTxnFeeInclGst;

    @Column(name = "TOTTXNFEE_EXCL_GST", nullable = true)
    private BigDecimal totTxnFeeExclGst;

    @Column(name = "GST", nullable = true)
    private BigDecimal gst;

    @Column(name = "TXN_YEAR", nullable = false, length = 5)
    private String txnYear;

    @Column(name = "TXN_MONTH", nullable = false, length = 2)
    private String txnMonth;

    @Column(name = "TXN_DAY1_FEE", nullable = true)
    private BigDecimal txnDay1Fee;

    @Column(name = "TXN_DAY2_FEE", nullable = true)
    private BigDecimal txnDay2Fee;

    @Column(name = "TXN_DAY3_FEE", nullable = true)
    private BigDecimal txnDay3Fee;

    @Column(name = "TXN_DAY4_FEE", nullable = true)
    private BigDecimal txnDay4Fee;

    @Column(name = "TXN_DAY5_FEE", nullable = true)
    private BigDecimal txnDay5Fee;

    @Column(name = "TXN_DAY6_FEE", nullable = true)
    private BigDecimal txnDay6Fee;

    @Column(name = "TXN_DAY7_FEE", nullable = true)
    private BigDecimal txnDay7Fee;

    @Column(name = "TXN_DAY8_FEE", nullable = true)
    private BigDecimal txnDay8Fee;

    @Column(name = "TXN_DAY9_FEE", nullable = true)
    private BigDecimal txnDay9Fee;

    @Column(name = "TXN_DAY10_FEE", nullable = true)
    private BigDecimal txnDay10Fee;

    @Column(name = "TXN_DAY11_FEE", nullable = true)
    private BigDecimal txnDay11Fee;

    @Column(name = "TXN_DAY12_FEE", nullable = true)
    private BigDecimal txnDay12Fee;

    @Column(name = "TXN_DAY13_FEE", nullable = true)
    private BigDecimal txnDay13Fee;

    @Column(name = "TXN_DAY14_FEE", nullable = true)
    private BigDecimal txnDay14Fee;

    @Column(name = "TXN_DAY15_FEE", nullable = true)
    private BigDecimal txnDay15Fee;

    @Column(name = "TXN_DAY16_FEE", nullable = true)
    private BigDecimal txnDay16Fee;

    @Column(name = "TXN_DAY17_FEE", nullable = true)
    private BigDecimal txnDay17Fee;

    @Column(name = "TXN_DAY18_FEE", nullable = true)
    private BigDecimal txnDay18Fee;

    @Column(name = "TXN_DAY19_FEE", nullable = true)
    private BigDecimal txnDay19Fee;

    @Column(name = "TXN_DAY20_FEE", nullable = true)
    private BigDecimal txnDay20Fee;

    @Column(name = "TXN_DAY21_FEE", nullable = true)
    private BigDecimal txnDay21Fee;

    @Column(name = "TXN_DAY22_FEE", nullable = true)
    private BigDecimal txnDay22Fee;

    @Column(name = "TXN_DAY23_FEE", nullable = true)
    private BigDecimal txnDay23Fee;

    @Column(name = "TXN_DAY24_FEE", nullable = true)
    private BigDecimal txnDay24Fee;

    @Column(name = "TXN_DAY25_FEE", nullable = true)
    private BigDecimal txnDay25Fee;

    @Column(name = "TXN_DAY26_FEE", nullable = true)
    private BigDecimal txnDay26Fee;

    @Column(name = "TXN_DAY27_FEE", nullable = true)
    private BigDecimal txnDay27Fee;

    @Column(name = "TXN_DAY28_FEE", nullable = true)
    private BigDecimal txnDay28Fee;

    @Column(name = "TXN_DAY29_FEE", nullable = true)
    private BigDecimal txnDay29Fee;

    @Column(name = "TXN_DAY30_FEE", nullable = true)
    private BigDecimal txnDay30Fee;

    @Column(name = "TXN_DAY31_FEE", nullable = true)
    private BigDecimal txnDay31Fee;

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public Long getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String merchantCode) {
        this.merchantCode = merchantCode;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public Long getAcquirerId() {
        return acquirerId;
    }

    public void setAcquirerId(Long acquirerId) {
        this.acquirerId = acquirerId;
    }

    public String getTxnCurrency() {
        return txnCurrency;
    }

    public void setTxnCurrency(String txnCurrency) {
        this.txnCurrency = txnCurrency;
    }

    public BigDecimal getTotTxnFeeInclGst() {
        return totTxnFeeInclGst;
    }

    public void setTotTxnFeeInclGst(BigDecimal totTxnFeeInclGst) {
        this.totTxnFeeInclGst = totTxnFeeInclGst;
    }

    public BigDecimal getTotTxnFeeExclGst() {
        return totTxnFeeExclGst;
    }

    public void setTotTxnFeeExclGst(BigDecimal totTxnFeeExclGst) {
        this.totTxnFeeExclGst = totTxnFeeExclGst;
    }

    public BigDecimal getGst() {
        return gst;
    }

    public void setGst(BigDecimal gst) {
        this.gst = gst;
    }

    public String getTxnYear() {
        return txnYear;
    }

    public void setTxnYear(String txnYear) {
        this.txnYear = txnYear;
    }

    public String getTxnMonth() {
        return txnMonth;
    }

    public void setTxnMonth(String txnMonth) {
        this.txnMonth = txnMonth;
    }

    public BigDecimal getTxnDay1Fee() {
        return txnDay1Fee;
    }

    public void setTxnDay1Fee(BigDecimal txnDay1Fee) {
        this.txnDay1Fee = txnDay1Fee;
    }

    public BigDecimal getTxnDay2Fee() {
        return txnDay2Fee;
    }

    public void setTxnDay2Fee(BigDecimal txnDay2Fee) {
        this.txnDay2Fee = txnDay2Fee;
    }

    public BigDecimal getTxnDay3Fee() {
        return txnDay3Fee;
    }

    public void setTxnDay3Fee(BigDecimal txnDay3Fee) {
        this.txnDay3Fee = txnDay3Fee;
    }

    public BigDecimal getTxnDay4Fee() {
        return txnDay4Fee;
    }

    public void setTxnDay4Fee(BigDecimal txnDay4Fee) {
        this.txnDay4Fee = txnDay4Fee;
    }

    public BigDecimal getTxnDay5Fee() {
        return txnDay5Fee;
    }

    public void setTxnDay5Fee(BigDecimal txnDay5Fee) {
        this.txnDay5Fee = txnDay5Fee;
    }

    public BigDecimal getTxnDay6Fee() {
        return txnDay6Fee;
    }

    public void setTxnDay6Fee(BigDecimal txnDay6Fee) {
        this.txnDay6Fee = txnDay6Fee;
    }

    public BigDecimal getTxnDay7Fee() {
        return txnDay7Fee;
    }

    public void setTxnDay7Fee(BigDecimal txnDay7Fee) {
        this.txnDay7Fee = txnDay7Fee;
    }

    public BigDecimal getTxnDay8Fee() {
        return txnDay8Fee;
    }

    public void setTxnDay8Fee(BigDecimal txnDay8Fee) {
        this.txnDay8Fee = txnDay8Fee;
    }

    public BigDecimal getTxnDay9Fee() {
        return txnDay9Fee;
    }

    public void setTxnDay9Fee(BigDecimal txnDay9Fee) {
        this.txnDay9Fee = txnDay9Fee;
    }

    public BigDecimal getTxnDay10Fee() {
        return txnDay10Fee;
    }

    public void setTxnDay10Fee(BigDecimal txnDay10Fee) {
        this.txnDay10Fee = txnDay10Fee;
    }

    public BigDecimal getTxnDay11Fee() {
        return txnDay11Fee;
    }

    public void setTxnDay11Fee(BigDecimal txnDay11Fee) {
        this.txnDay11Fee = txnDay11Fee;
    }

    public BigDecimal getTxnDay12Fee() {
        return txnDay12Fee;
    }

    public void setTxnDay12Fee(BigDecimal txnDay12Fee) {
        this.txnDay12Fee = txnDay12Fee;
    }

    public BigDecimal getTxnDay13Fee() {
        return txnDay13Fee;
    }

    public void setTxnDay13Fee(BigDecimal txnDay13Fee) {
        this.txnDay13Fee = txnDay13Fee;
    }

    public BigDecimal getTxnDay14Fee() {
        return txnDay14Fee;
    }

    public void setTxnDay14Fee(BigDecimal txnDay14Fee) {
        this.txnDay14Fee = txnDay14Fee;
    }

    public BigDecimal getTxnDay15Fee() {
        return txnDay15Fee;
    }

    public void setTxnDay15Fee(BigDecimal txnDay15Fee) {
        this.txnDay15Fee = txnDay15Fee;
    }

    public BigDecimal getTxnDay16Fee() {
        return txnDay16Fee;
    }

    public void setTxnDay16Fee(BigDecimal txnDay16Fee) {
        this.txnDay16Fee = txnDay16Fee;
    }

    public BigDecimal getTxnDay17Fee() {
        return txnDay17Fee;
    }

    public void setTxnDay17Fee(BigDecimal txnDay17Fee) {
        this.txnDay17Fee = txnDay17Fee;
    }

    public BigDecimal getTxnDay18Fee() {
        return txnDay18Fee;
    }

    public void setTxnDay18Fee(BigDecimal txnDay18Fee) {
        this.txnDay18Fee = txnDay18Fee;
    }

    public BigDecimal getTxnDay19Fee() {
        return txnDay19Fee;
    }

    public void setTxnDay19Fee(BigDecimal txnDay19Fee) {
        this.txnDay19Fee = txnDay19Fee;
    }

    public BigDecimal getTxnDay20Fee() {
        return txnDay20Fee;
    }

    public void setTxnDay20Fee(BigDecimal txnDay20Fee) {
        this.txnDay20Fee = txnDay20Fee;
    }

    public BigDecimal getTxnDay21Fee() {
        return txnDay21Fee;
    }

    public void setTxnDay21Fee(BigDecimal txnDay21Fee) {
        this.txnDay21Fee = txnDay21Fee;
    }

    public BigDecimal getTxnDay22Fee() {
        return txnDay22Fee;
    }

    public void setTxnDay22Fee(BigDecimal txnDay22Fee) {
        this.txnDay22Fee = txnDay22Fee;
    }

    public BigDecimal getTxnDay23Fee() {
        return txnDay23Fee;
    }

    public void setTxnDay23Fee(BigDecimal txnDay23Fee) {
        this.txnDay23Fee = txnDay23Fee;
    }

    public BigDecimal getTxnDay24Fee() {
        return txnDay24Fee;
    }

    public void setTxnDay24Fee(BigDecimal txnDay24Fee) {
        this.txnDay24Fee = txnDay24Fee;
    }

    public BigDecimal getTxnDay25Fee() {
        return txnDay25Fee;
    }

    public void setTxnDay25Fee(BigDecimal txnDay25Fee) {
        this.txnDay25Fee = txnDay25Fee;
    }

    public BigDecimal getTxnDay26Fee() {
        return txnDay26Fee;
    }

    public void setTxnDay26Fee(BigDecimal txnDay26Fee) {
        this.txnDay26Fee = txnDay26Fee;
    }

    public BigDecimal getTxnDay27Fee() {
        return txnDay27Fee;
    }

    public void setTxnDay27Fee(BigDecimal txnDay27Fee) {
        this.txnDay27Fee = txnDay27Fee;
    }

    public BigDecimal getTxnDay28Fee() {
        return txnDay28Fee;
    }

    public void setTxnDay28Fee(BigDecimal txnDay28Fee) {
        this.txnDay28Fee = txnDay28Fee;
    }

    public BigDecimal getTxnDay29Fee() {
        return txnDay29Fee;
    }

    public void setTxnDay29Fee(BigDecimal txnDay29Fee) {
        this.txnDay29Fee = txnDay29Fee;
    }

    public BigDecimal getTxnDay30Fee() {
        return txnDay30Fee;
    }

    public void setTxnDay30Fee(BigDecimal txnDay30Fee) {
        this.txnDay30Fee = txnDay30Fee;
    }

    public BigDecimal getTxnDay31Fee() {
        return txnDay31Fee;
    }

    public void setTxnDay31Fee(BigDecimal txnDay31Fee) {
        this.txnDay31Fee = txnDay31Fee;
    }

}
