package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ta13_bank_cfg_attr")
public class BankCfgAttrEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cfgAttrId")
    private Long oid;

    @Column(name = "cfgAttrName", nullable = false, length = 100)
    private String cfgAttrName;

    @Column(name = "cfgAttrValue", nullable = false, length = 100)
    private String cfgAttrValue;

    @Column(name = "cfgAttrType", nullable = false, length = 5)
    private Integer cfgAttrType;

    @Column(name = "CREATED_BY", nullable = false, length = 6)
    private Integer createdBy;

    @Column(name = "CREATION_TIME", nullable = false, length = 19)
    private Timestamp creationTime;

    @Column(name = "LAST_UPDATED_BY", length = 6)
    private Integer lastUpdatedBy;

    @Column(name = "LAST_UPDATED_TIME", length = 19)
    private Timestamp lastUpdatedTime;

    @ManyToOne
    @JoinColumn(name = "BANK_ID")
    private BankEntity bank;

    public String getCfgAttrName() {
        return cfgAttrName;
    }

    public void setCfgAttrName(String cfgAttrName) {
        this.cfgAttrName = cfgAttrName;
    }

    public String getCfgAttrValue() {
        return cfgAttrValue;
    }

    public void setCfgAttrValue(String cfgAttrValue) {
        this.cfgAttrValue = cfgAttrValue;
    }

    public Integer getCfgAttrType() {
        return cfgAttrType;
    }

    public void setCfgAttrType(Integer cfgAttrType) {
        this.cfgAttrType = cfgAttrType;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(Timestamp creationTime) {
        this.creationTime = creationTime;
    }

    public Integer getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(Integer lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Timestamp getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(Timestamp lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

}
