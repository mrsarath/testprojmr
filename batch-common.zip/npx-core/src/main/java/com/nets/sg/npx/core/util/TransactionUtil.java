package com.nets.sg.npx.core.util;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import com.nets.sg.npx.core.persistence.entity.TransactionEntity;

@Component
public class TransactionUtil {

    private static final Integer DEFAULT_SCALE = 3;

    private static final Integer DEFAULT_ROUNDING = BigDecimal.ROUND_HALF_UP;

    private static final BigDecimal HUNDRED = new BigDecimal(100);

    private static final BigDecimal ZERO = new BigDecimal(0);

    public BigDecimal getBankInterchange(TransactionEntity tran, BigDecimal birPercent) {
        return tran.getAmount().multiply(birPercent).divide(HUNDRED).setScale(DEFAULT_SCALE, DEFAULT_ROUNDING);
    }

    public BigDecimal getNetReceiptFromBank(TransactionEntity tran, BigDecimal birAmount) {
        return tran.getAmount().subtract(birAmount).setScale(DEFAULT_SCALE, DEFAULT_ROUNDING);
    }

    public BigDecimal getMDR(TransactionEntity tran) {
        BigDecimal mdr = tran.getMdrPercent() == null ? ZERO : tran.getMdrPercent().divide(HUNDRED);
        return tran.getAmount().multiply(mdr).setScale(DEFAULT_SCALE, DEFAULT_ROUNDING);
    }

    public BigDecimal getGST(TransactionEntity tran, BigDecimal mdrAmount) {
        BigDecimal gst = tran.getAcquirerMerchantMapping().getAcquirer().getGst();
        return mdrAmount.multiply(gst == null ? ZERO : gst.divide(HUNDRED)).setScale(DEFAULT_SCALE, DEFAULT_ROUNDING);
    }

    public BigDecimal getMerchantPayable(TransactionEntity tran, BigDecimal mdr, BigDecimal gst) {
        return tran.getAmount().subtract(mdr).subtract(gst).setScale(DEFAULT_SCALE, DEFAULT_ROUNDING);
    }

}
