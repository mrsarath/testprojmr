package com.nets.sg.npx.core.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ttr12_batch_merchant_funding_transaction_mapping")
public class MerchantFundingTransactionMappingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MAPPING_ID")
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "MERCHANT_FUNDING_DETAILS_ID")
    private MerchantFundingRecordEntity record;

    @ManyToOne(optional = false)
    @JoinColumn(name = "TRAN_ID")
    private TransactionEntity transaction;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public MerchantFundingRecordEntity getRecord() {
        return record;
    }

    public void setRecord(MerchantFundingRecordEntity record) {
        this.record = record;
    }

    public TransactionEntity getTransaction() {
        return transaction;
    }

    public void setTransaction(TransactionEntity transaction) {
        this.transaction = transaction;
    }

}
