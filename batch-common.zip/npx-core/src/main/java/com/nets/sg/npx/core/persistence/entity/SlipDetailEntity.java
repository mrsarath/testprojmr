package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

/**
 * The persistent class for the tp06_slip_detail database table.
 * 
 */
@Entity
@Table(name = "tp06_slip_detail")
public class SlipDetailEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "POS_ID")
    private Long posId;

    @Column(name = "CREATED_BY")
    private int createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE")
    private Date createdDate;

    private String header0;

    private String header1;

    private String header2;

    private String header3;

    @Column(name = "LAST_UPDATED_BY")
    private int lastUpdatedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATED_DATE")
    private Date lastUpdatedDate;

    // bi-directional one-to-one association to PhysicalPosEntity
    @OneToOne
    @JoinColumn(name = "POS_ID", nullable=false)
    @MapsId
    private PhysicalPosEntity physicalPos;

    public SlipDetailEntity() {
    }

    public Long getPosId() {
        return this.posId;
    }

    public void setPosId(Long posId) {
        this.posId = posId;
    }

    public int getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getHeader0() {
        return this.header0;
    }

    public void setHeader0(String header0) {
        this.header0 = header0;
    }

    public String getHeader1() {
        return this.header1;
    }

    public void setHeader1(String header1) {
        this.header1 = header1;
    }

    public String getHeader2() {
        return this.header2;
    }

    public void setHeader2(String header2) {
        this.header2 = header2;
    }

    public String getHeader3() {
        return this.header3;
    }

    public void setHeader3(String header3) {
        this.header3 = header3;
    }

    public int getLastUpdatedBy() {
        return this.lastUpdatedBy;
    }

    public void setLastUpdatedBy(int lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return this.lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public PhysicalPosEntity getTp01PhysicalPo() {
        return this.physicalPos;
    }

    public void setTp01PhysicalPo(PhysicalPosEntity physicalPos) {
        this.physicalPos = physicalPos;
                
        if (physicalPos != null)
            this.posId = physicalPos.getOid();
        
    }

}