package com.nets.sg.npx.core.service;

import com.nets.sg.npx.core.persistence.entity.SapDataMappingConfigEntity;

public interface SapDataMappingConfigService {

    SapDataMappingConfigEntity getByDocTypeAndMapping(String docType, String mapping);

    SapDataMappingConfigEntity getByDocTypeMappingAndType(String docType, String mapping, String type);

}
