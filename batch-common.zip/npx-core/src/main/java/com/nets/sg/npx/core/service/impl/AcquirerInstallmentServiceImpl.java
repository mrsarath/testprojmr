package com.nets.sg.npx.core.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.AcquirerInstallmentDao;
import com.nets.sg.npx.core.persistence.entity.AcquirerInstallmentEntity;
import com.nets.sg.npx.core.service.AcquirerInstallmentService;

@Service
public class AcquirerInstallmentServiceImpl implements AcquirerInstallmentService {

    @Autowired
    AcquirerInstallmentDao acquirerInstallmentDao;

    @Override
    public AcquirerInstallmentEntity getByAcquirerAndTerm(int acquirerId, int payTerm) {
        return acquirerInstallmentDao.getByAcquirerAndTerm(acquirerId, payTerm);
    }

}
