package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

/**
 * The persistent class for the tm05_merchant_currency database table.
 * 
 */
@Entity
@Table(name = "tm05_merchant_currency")
public class MerchantCurrencyEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MER_CURR_ID")
    private Integer merCurrId;

    @Column(name = "CREATED_BY")
    private Integer createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATION_DATE")
    private Date creationDate;

    @Column(name = "CURR_DISPLAY_POSITION")
    private Integer currDisplayPosition;

    @Column(name = "IS_SOURCE_SUPPORTED")
    private Character isSourceSupported;

    @Column(name = "IS_TARGET_SUPPORTED")
    private Character isTargetSupported;

    @Column(name = "ISO_CURRENCY")
    private String isoCurrency;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATE_DATE")
    private Date lastUpdateDate;

    @Column(name = "LAST_UPDATED_BY")
    private Integer lastUpdatedBy;   
    
    /* 
    @OneToOne
    @JoinColumn(name = "MERCHANT_ID")    
    private MerchantEntity merchant;
    */
    
    @Column(name = "MERCHANT_ID")
    private int merchantId;
    
    public MerchantCurrencyEntity() {
    }

    public int getMerCurrId() {
        return this.merCurrId;
    }

    public void setMerCurrId(int merCurrId) {
        this.merCurrId = merCurrId;
    }

    public int getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public int getCurrDisplayPosition() {
        return this.currDisplayPosition;
    }

    public void setCurrDisplayPosition(int currDisplayPosition) {
        this.currDisplayPosition = currDisplayPosition;
    }

    public Character getIsSourceSupported() {
        return this.isSourceSupported;
    }

    public void setIsSourceSupported(Character isSourceSupported) {
        this.isSourceSupported = isSourceSupported;
    }

    public Character getIsTargetSupported() {
        return this.isTargetSupported;
    }

    public void setIsTargetSupported(Character isTargetSupported) {
        this.isTargetSupported = isTargetSupported;
    }

    public String getIsoCurrency() {
        return this.isoCurrency;
    }

    public void setIsoCurrency(String isoCurrency) {
        this.isoCurrency = isoCurrency;
    }

    public Date getLastUpdateDate() {
        return this.lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public int getLastUpdatedBy() {
        return this.lastUpdatedBy;
    }

    public void setLastUpdatedBy(int lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public int getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(int merchantId) {
        this.merchantId = merchantId;
    }

    public void setMerCurrId(Integer merCurrId) {
        this.merCurrId = merCurrId;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public void setCurrDisplayPosition(Integer currDisplayPosition) {
        this.currDisplayPosition = currDisplayPosition;
    }

    public void setLastUpdatedBy(Integer lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }    

   /* public MerchantEntity getMerchant() {
        return this.merchant;
    }

    public void setMerchant(MerchantEntity merchant) {
        this.merchant = merchant;
    }*/
    
    
}