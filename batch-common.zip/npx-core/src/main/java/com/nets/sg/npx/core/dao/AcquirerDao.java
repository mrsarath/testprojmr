package com.nets.sg.npx.core.dao;

import com.nets.sg.npx.core.persistence.entity.AcquirerEntity;

public interface AcquirerDao extends GenericDao<AcquirerEntity, Long> {

   
    AcquirerEntity getAcquirerByName(String name);

}
