package com.nets.sg.npx.core.dao;

import java.util.Date;
import java.util.List;

import com.nets.sg.npx.core.persistence.entity.OnlineBankBatchEntity;

public interface OnlineBankBatchSettlementDao extends GenericDao<OnlineBankBatchEntity, Long> {

    List<OnlineBankBatchEntity> getSettlement(Date begin, Date end, String... status);

}
