package com.nets.sg.npx.core.service;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.MerchantFundingEntity;

public interface MerchantFundingService {

    MerchantFundingEntity save(MerchantFundingEntity funding);

    MerchantFundingEntity getMerchantFundingByBatchNo(String batchNo);
    
    MerchantFundingEntity getSubmittedByFileName(String fileName);

    List<MerchantFundingEntity> getUnPostedSuccessRecords(String svcType);

    MerchantFundingEntity update(MerchantFundingEntity funding);

}

