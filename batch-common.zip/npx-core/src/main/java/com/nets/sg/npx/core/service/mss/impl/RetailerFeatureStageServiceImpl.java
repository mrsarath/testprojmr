package com.nets.sg.npx.core.service.mss.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.mss.RetailerFeatureStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.RetailerFeatureStageEntity;
import com.nets.sg.npx.core.service.mss.RetailerFeatureStageService;

@Service
public class RetailerFeatureStageServiceImpl implements RetailerFeatureStageService {

    @Autowired
    private RetailerFeatureStageDao retailerFeatureDao;

    @Override
    public RetailerFeatureStageEntity save(RetailerFeatureStageEntity record) {

        return retailerFeatureDao.save(record);
    }

    @Override
    public List<RetailerFeatureStageEntity> getRecords(String batchNo, String retId, String termId, byte recordStatus) {
        return retailerFeatureDao.getRecordsByStatus(batchNo, retId, termId, recordStatus);
    }

    @Override
    public RetailerFeatureStageEntity update(RetailerFeatureStageEntity retailer) {
        return retailerFeatureDao.saveOrUpdate(retailer);
    }

    @Override
    public List<RetailerFeatureStageEntity> getRecords(String createDate, String batchNo, String status) {
   
        return retailerFeatureDao.getRecordsByStatus(createDate, batchNo, status);
    }
}
