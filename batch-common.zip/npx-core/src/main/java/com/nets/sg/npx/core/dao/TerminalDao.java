package com.nets.sg.npx.core.dao;

import com.nets.sg.npx.core.persistence.entity.PhysicalPosEntity;

public interface TerminalDao extends GenericDao<PhysicalPosEntity, Long> {

    PhysicalPosEntity getTerminalByName(String name);

}
