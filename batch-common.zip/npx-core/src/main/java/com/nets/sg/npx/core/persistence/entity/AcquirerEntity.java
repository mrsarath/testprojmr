package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ta01_acquirer")
public class AcquirerEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ACQUIRER_ID")
    private Long oid;
    
    @Column(name = "NAME")
    private String name;

    @Basic
    @Column(name = "GST", precision = 3, scale = 2)
    private BigDecimal gst;

    @OneToMany(mappedBy = "acquirer")
    private Set<AcqCardTypeEntity> cardTypes;

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getGst() {
        return gst;
    }

    public void setGst(BigDecimal gst) {
        this.gst = gst;
    }

    public Set<AcqCardTypeEntity> getCardTypes() {
        return cardTypes;
    }

    public void setCardTypes(Set<AcqCardTypeEntity> cardTypes) {
        this.cardTypes = cardTypes;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((oid == null) ? 0 : oid.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AcquirerEntity other = (AcquirerEntity) obj;
        if (oid == null) {
            if (other.oid != null)
                return false;
        } else if (!oid.equals(other.oid))
            return false;
        return true;
    }

}
