package com.nets.sg.npx.core.persistence.entity.mss;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;


/**
 * The persistent class for the ttr18_ccms_sync_riding_info database table.
 * 
 */
@Entity
@Table(name="ttr18_mss_stage_riding_info")
public class RidingInfoStageEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="RIDING_ID")
	private int ridingId;

	@Column(name="RECORD_STATUS")
    private String recordStatus = "0";

    @Column(name="RECORD_DATE", nullable = false)
    private Date recordDate;
    
    @Column(name = "RECORD_CREATED_DATE", nullable = false)
    private String recordCreateDate;
    
    @Column(name="BATCH_NO", nullable = false)
    private String batchNo;
    
	@Column(name="FEATURE_ID")
	private String featureId;

	@Column(name="RET_ID")
	private String retId;

	@Column(name="RIDING_MID")
	private String ridingMid;

	//@Column(name="RIDING_ORG")
	//private String ridingOrg;

	@Column(name="RIDING_TID")
	private String ridingTid;

	@Column(name="SUB_FEATURE_ID")
	private String subFeatureId;

	@Column(name="TERM_ID")
	private String termId;

	public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }

    public String getRecordCreateDate() {
        return recordCreateDate;
    }

    public void setRecordCreateDate(String recordCreateDate) {
        this.recordCreateDate = recordCreateDate;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public RidingInfoStageEntity() {
	}

	public int getRidingId() {
		return this.ridingId;
	}

	public void setRidingId(int ridingId) {
		this.ridingId = ridingId;
	}

	public String getFeatureId() {
		return this.featureId;
	}

	public void setFeatureId(String featureId) {
		this.featureId = featureId;
	}

	public String getRetId() {
		return this.retId;
	}

	public void setRetId(String retId) {
		this.retId = retId;
	}

	public String getRidingMid() {
		return this.ridingMid;
	}

	public void setRidingMid(String ridingMid) {
		this.ridingMid = ridingMid;
	}

	/*public String getRidingOrg() {
		return this.ridingOrg;
	}

	public void setRidingOrg(String ridingOrg) {
		this.ridingOrg = ridingOrg;
	}*/

	public String getRidingTid() {
		return this.ridingTid;
	}

	public void setRidingTid(String ridingTid) {
		this.ridingTid = ridingTid;
	}

	public String getSubFeatureId() {
		return this.subFeatureId;
	}

	public void setSubFeatureId(String subFeatureId) {
		this.subFeatureId = subFeatureId;
	}

	public String getTermId() {
		return this.termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}

}