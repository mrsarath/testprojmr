package com.nets.sg.npx.core.persistence.entity.mss;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the ttr15_dwh_sync_hq database table.
 * 
 */
@Entity
@Table(name = "ttr14_dwh_sync_hq")
public class SyncHqEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "HQ_ID")
    private int hqId;

    @Column(name = "GRP_ID")
    private String grpId;
    
    @Column(name="RECORD_STATUS")
    private byte recordStatus = 0;

    @Column(name="RECORD_DATE", nullable = false)
    private Date recordDate;
    
    @Column(name="BATCH_NO", nullable = false)
    private String batchNo;
    
    @Column(name = "APPLICANT_NAME")
    private String applicantName;

    @Column(name = "APPLICANT_TITLE")
    private String applicantTitle;

    @Column(name = "BIZ_CODE")
    private String bizCode;

    @Column(name = "CHQ_AMOUNT")
    private BigDecimal chqAmount;

    @Column(name = "CHQ_BANK")
    private String chqBank;

    @Column(name = "CHQ_NO")
    private String chqNo;

    @Column(name = "CHQ_RECEIVED_DATE")
    private String chqReceivedDate;

    @Column(name = "CO_NAME")
    private String coName;

    @Column(name = "CO_REG_NO")
    private String coRegNo;

    @Column(name = "CONTACT_NAME")
    private String contactName;

    @Column(name = "CONTACT_TITLE")
    private String contactTitle;

    @Column(name = "CORP_ID")
    private String corpId;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private String createdDate;

    @Column(name = "FAX_NO")
    private String faxNo;

    @Column(name = "FEE_AMOUNT")
    private BigDecimal feeAmount;

    @Column(name = "FEE_BANK")
    private String feeBank;

    @Column(name = "FEE_NO")
    private String feeNo;

    @Column(name = "FEE_RECEIVED_DATE")
    private String feeReceivedDate;

    @Column(name = "FUNCTION_ID")
    private String functionId;

    @Column(name = "HQ_ADDR1")
    private String hqAddr1;

    @Column(name = "HQ_ADDR2")
    private String hqAddr2;

    @Column(name = "HQ_ADDR3")
    private String hqAddr3;

    @Column(name = "HQ_POSTCODE")
    private String hqPostcode;

    @Column(name = "INC_DATE")
    private String incDate;

    @Column(name = "INC_NETS_DATE")
    private String incNetsDate;

    @Column(name = "INC_PLACE")
    private String incPlace;

    @Column(name = "OWNER")
    private String owner;

    @Column(name = "SELF_SERVICE_IND")
    private String selfServiceInd;

    @Column(name = "SSIC")
    private String ssic;

    @Column(name = "SSIC_CAT_DESC")
    private String ssicCatDesc;

    @Column(name = "SSIC2000")
    private String ssic2000;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "STATUS_EFF_DATE")
    private String statusEffDate;

    @Column(name = "TEL1_EXT")
    private String tel1Ext;

    @Column(name = "TEL1_NO")
    private String tel1No;

    @Column(name = "TEL2_EXT")
    private String tel2Ext;

    @Column(name = "TEL2_NO")
    private String tel2No;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private String updatedDate;

    // bi-directional many-to-one association to DwhSyncRetailerEntity
    // @OneToMany(mappedBy="ttr15DwhSyncHq")
    // private List<SyncRetailerEntity> ttr14DwhSyncRetailers;

    public SyncHqEntity() {
    }

    public int getHqId() {
        return this.hqId;
    }

    public void setHqId(int hqId) {
        this.hqId = hqId;
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }

    public byte getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(byte recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getGrpId() {
        return grpId;
    }

    public void setGrpId(String grpId) {
        this.grpId = grpId;
    }

    public String getApplicantName() {
        return this.applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public String getApplicantTitle() {
        return this.applicantTitle;
    }

    public void setApplicantTitle(String applicantTitle) {
        this.applicantTitle = applicantTitle;
    }

    public String getBizCode() {
        return this.bizCode;
    }

    public void setBizCode(String bizCode) {
        this.bizCode = bizCode;
    }

    public BigDecimal getChqAmount() {
        return this.chqAmount;
    }

    public void setChqAmount(BigDecimal chqAmount) {
        this.chqAmount = chqAmount;
    }

    public String getChqBank() {
        return this.chqBank;
    }

    public void setChqBank(String chqBank) {
        this.chqBank = chqBank;
    }

    public String getChqNo() {
        return this.chqNo;
    }

    public void setChqNo(String chqNo) {
        this.chqNo = chqNo;
    }

    public String getChqReceivedDate() {
        return this.chqReceivedDate;
    }

    public void setChqReceivedDate(String chqReceivedDate) {
        this.chqReceivedDate = chqReceivedDate;
    }

    public String getCoName() {
        return this.coName;
    }

    public void setCoName(String coName) {
        this.coName = coName;
    }

    public String getCoRegNo() {
        return this.coRegNo;
    }

    public void setCoRegNo(String coRegNo) {
        this.coRegNo = coRegNo;
    }

    public String getContactName() {
        return this.contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactTitle() {
        return this.contactTitle;
    }

    public void setContactTitle(String contactTitle) {
        this.contactTitle = contactTitle;
    }

    public String getCorpId() {
        return this.corpId;
    }

    public void setCorpId(String corpId) {
        this.corpId = corpId;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getFaxNo() {
        return this.faxNo;
    }

    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    public BigDecimal getFeeAmount() {
        return this.feeAmount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public String getFeeBank() {
        return this.feeBank;
    }

    public void setFeeBank(String feeBank) {
        this.feeBank = feeBank;
    }

    public String getFeeNo() {
        return this.feeNo;
    }

    public void setFeeNo(String feeNo) {
        this.feeNo = feeNo;
    }

    public String getFeeReceivedDate() {
        return this.feeReceivedDate;
    }

    public void setFeeReceivedDate(String feeReceivedDate) {
        this.feeReceivedDate = feeReceivedDate;
    }

    public String getFunctionId() {
        return this.functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public String getHqAddr1() {
        return this.hqAddr1;
    }

    public void setHqAddr1(String hqAddr1) {
        this.hqAddr1 = hqAddr1;
    }

    public String getHqAddr2() {
        return this.hqAddr2;
    }

    public void setHqAddr2(String hqAddr2) {
        this.hqAddr2 = hqAddr2;
    }

    public String getHqAddr3() {
        return this.hqAddr3;
    }

    public void setHqAddr3(String hqAddr3) {
        this.hqAddr3 = hqAddr3;
    }

    public String getHqPostcode() {
        return this.hqPostcode;
    }

    public void setHqPostcode(String hqPostcode) {
        this.hqPostcode = hqPostcode;
    }

    public String getIncDate() {
        return this.incDate;
    }

    public void setIncDate(String incDate) {
        this.incDate = incDate;
    }

    public String getIncNetsDate() {
        return this.incNetsDate;
    }

    public void setIncNetsDate(String incNetsDate) {
        this.incNetsDate = incNetsDate;
    }

    public String getIncPlace() {
        return this.incPlace;
    }

    public void setIncPlace(String incPlace) {
        this.incPlace = incPlace;
    }

    public String getOwner() {
        return this.owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getSelfServiceInd() {
        return this.selfServiceInd;
    }

    public void setSelfServiceInd(String selfServiceInd) {
        this.selfServiceInd = selfServiceInd;
    }

    public String getSsic() {
        return this.ssic;
    }

    public void setSsic(String ssic) {
        this.ssic = ssic;
    }

    public String getSsicCatDesc() {
        return this.ssicCatDesc;
    }

    public void setSsicCatDesc(String ssicCatDesc) {
        this.ssicCatDesc = ssicCatDesc;
    }

    public String getSsic2000() {
        return this.ssic2000;
    }

    public void setSsic2000(String ssic2000) {
        this.ssic2000 = ssic2000;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusEffDate() {
        return this.statusEffDate;
    }

    public void setStatusEffDate(String statusEffDate) {
        this.statusEffDate = statusEffDate;
    }

    public String getTel1Ext() {
        return this.tel1Ext;
    }

    public void setTel1Ext(String tel1Ext) {
        this.tel1Ext = tel1Ext;
    }

    public String getTel1No() {
        return this.tel1No;
    }

    public void setTel1No(String tel1No) {
        this.tel1No = tel1No;
    }

    public String getTel2Ext() {
        return this.tel2Ext;
    }

    public void setTel2Ext(String tel2Ext) {
        this.tel2Ext = tel2Ext;
    }

    public String getTel2No() {
        return this.tel2No;
    }

    public void setTel2No(String tel2No) {
        this.tel2No = tel2No;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

}