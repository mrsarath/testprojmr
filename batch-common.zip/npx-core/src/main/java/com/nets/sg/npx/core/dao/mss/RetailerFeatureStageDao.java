package com.nets.sg.npx.core.dao.mss;

import java.util.List;

import com.nets.sg.npx.core.dao.GenericDao;
import com.nets.sg.npx.core.persistence.entity.mss.RetailerFeatureStageEntity;

public interface RetailerFeatureStageDao extends GenericDao<RetailerFeatureStageEntity, Long> {

    List<RetailerFeatureStageEntity> getRecordsByStatus(String batchNo, String retId, String termId, byte status);

    List<RetailerFeatureStageEntity> getRecordsByStatus(String createDate, String batchNo, String status);

}
