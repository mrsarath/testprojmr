package com.nets.sg.npx.core.persistence.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ttr10_batch_merchant_funding")
public class MerchantFundingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MERCHANT_FUNDING_ID")
    private Long oid;

    @Column(name = "BATCH_NO", length = 14)
    private String batchNum;

    @Column(name = "FILE_NAME", length = 20)
    private String fileName;

    @Column(name = "TOTAL_CREDIT_AMOUNT", length = 12, nullable = false)
    private String totalCreditAmount;

    @Column(name = "SEL_CREDIT_COUNT", nullable = false)
    private String settledCreditCount;

    @Column(name = "SEL_CREDIT_AMOUNT", length = 12)
    private String settledCreditAmount;

    @Column(name = "TOTAL_CREDIT_COUNT")
    private String totalCreditCount;

    @Column(name = "TOTAL_DEBIT_AMOUNT", length = 12)
    private String totalDebitAmount;

    @Column(name = "TOTAL_DEBIT_COUNT")
    private String totalDebitCount;

    @Column(name = "STATUS", length = 2)
    private String status;

    @Column(name = "MESSAGE", length = 50)
    private String message;

    @Column(name = "SUB_DATE", length = 8)
    private String submitDate;

    @Column(name = "RES_DATE", length = 8)
    private String responseDate;

    @Column(name = "VAL_DATE", length = 8)
    private String valueDate;

    @Column(name = "SVC_TYPE", length = 8)
    private String serviceType;

    @OneToMany(mappedBy = "funding", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Set<MerchantFundingRecordEntity> records = new HashSet<>();

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getBatchNum() {
        return batchNum;
    }

    public void setBatchNum(String batchNum) {
        this.batchNum = batchNum;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getTotalCreditAmount() {
        return totalCreditAmount;
    }

    public void setTotalCreditAmount(String totalCreditAmount) {
        this.totalCreditAmount = totalCreditAmount;
    }

    public String getTotalDebitAmount() {
        return totalDebitAmount;
    }

    public void setTotalDebitAmount(String totalDebitAmount) {
        this.totalDebitAmount = totalDebitAmount;
    }

    public String getTotalCreditCount() {
        return totalCreditCount;
    }

    public void setTotalCreditCount(String totalCreditCount) {
        this.totalCreditCount = totalCreditCount;
    }

    public String getTotalDebitCount() {
        return totalDebitCount;
    }

    public void setTotalDebitCount(String totalDebitCount) {
        this.totalDebitCount = totalDebitCount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(String submitDate) {
        this.submitDate = submitDate;
    }

    public String getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(String responseDate) {
        this.responseDate = responseDate;
    }

    public boolean addRecord(MerchantFundingRecordEntity record) {
        record.setFunding(this);
        return records.add(record);
    }

    public Set<MerchantFundingRecordEntity> getRecords() {
        return records;
    }

    public void setRecords(Set<MerchantFundingRecordEntity> records) {
        this.records = records;
    }

    public String getValueDate() {
        return valueDate;
    }

    public void setValueDate(String valueDate) {
        this.valueDate = valueDate;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getSettledCreditCount() {
        return settledCreditCount;
    }

    public void setSettledCreditCount(String settledCreditCount) {
        this.settledCreditCount = settledCreditCount;
    }

    public String getSettledCreditAmount() {
        return settledCreditAmount;
    }

    public void setSettledCreditAmount(String settledCreditAmount) {
        this.settledCreditAmount = settledCreditAmount;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        
        result = prime * result + ((oid == null) ? 0 : oid.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MerchantFundingEntity other = (MerchantFundingEntity) obj;
        if (oid == null) {
            if (other.oid != null)
                return false;
        } else if (!oid.equals(other.oid))
            return false;
        return true;
    }
    
    

}
