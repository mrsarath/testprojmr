package com.nets.sg.npx.core.persistence.entity.mss;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the ttr18_mss_stage_ret_otherinfo database table.
 * 
 */
@Entity
@Table(name="ttr17_mss_stage_ret_otherinfo")
public class RetailerOtherInfoStageEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="OTHERINFO_ID")
    private int otherinfoId;
    
    @Column(name="RECORD_STATUS")
    private byte recordStatus = 0;

    @Column(name="RECORD_DATE", nullable = false)
    private Date recordDate;
    
    @Column(name = "RECORD_CREATED_DATE", nullable = false)
    private String recordCreateDate;
    
    @Column(name="BATCH_NO", nullable = false)
    private String batchNo;

    @Column(name="CREATED_BY")
    private String createdBy;

    @Column(name="CREATED_DATE")
    private String createdDate;

    @Column(name="CREDIT_ACCT_NAME")
    private String creditAcctName;

    @Column(name="CREDIT_ACCT_NO")
    private String creditAcctNo;

    @Column(name="CREDIT_BANK_CODE")
    private String creditBankCode;

    @Column(name="CREDIT_BANK_NO")
    private String creditBankNo;

    @Column(name="CREDIT_BRANCH_NO")
    private String creditBranchNo;

    @Column(name="EMAIL_ADDR")
    private String emailAddr;
    
    @Column(name="STATUS")
    private String status;

    @Column(name="RET_ID")
    private String retId;

    @Column(name="UPDATED_BY")
    private String updatedBy;

    @Column(name="UPDATED_DATE")
    private String updatedDate;

    public RetailerOtherInfoStageEntity() {
    }

    public int getOtherinfoId() {
        return this.otherinfoId;
    }

    public void setOtherinfoId(int otherinfoId) {
        this.otherinfoId = otherinfoId;
    }

    public byte getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(byte recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }

    public String getRecordCreateDate() {
        return recordCreateDate;
    }

    public void setRecordCreateDate(String recordCreateDate) {
        this.recordCreateDate = recordCreateDate;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreditAcctName() {
        return this.creditAcctName;
    }

    public void setCreditAcctName(String creditAcctName) {
        this.creditAcctName = creditAcctName;
    }

    public String getCreditAcctNo() {
        return this.creditAcctNo;
    }

    public void setCreditAcctNo(String creditAcctNo) {
        this.creditAcctNo = creditAcctNo;
    }

    public String getCreditBankCode() {
        return this.creditBankCode;
    }

    public void setCreditBankCode(String creditBankCode) {
        this.creditBankCode = creditBankCode;
    }

    public String getCreditBankNo() {
        return this.creditBankNo;
    }

    public void setCreditBankNo(String creditBankNo) {
        this.creditBankNo = creditBankNo;
    }

    public String getCreditBranchNo() {
        return this.creditBranchNo;
    }

    public void setCreditBranchNo(String creditBranchNo) {
        this.creditBranchNo = creditBranchNo;
    }

    public String getEmailAddr() {
        return this.emailAddr;
    }

    public void setEmailAddr(String emailAddr) {
        this.emailAddr = emailAddr;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRetId() {
        return this.retId;
    }

    public void setRetId(String retId) {
        this.retId = retId;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

}