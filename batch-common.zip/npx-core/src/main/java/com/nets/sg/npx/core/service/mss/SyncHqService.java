package com.nets.sg.npx.core.service.mss;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.mss.SyncHqEntity;

public interface SyncHqService {

    SyncHqEntity save(SyncHqEntity record);
    
    SyncHqEntity update(SyncHqEntity record);
    
    List<SyncHqEntity> getRecordsByStatus(byte status);

}
