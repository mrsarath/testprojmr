package com.nets.sg.npx.core.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nets.sg.npx.core.dao.MerchantDao;
import com.nets.sg.npx.core.persistence.entity.MerchantEntity;
import com.nets.sg.npx.core.service.MerchantService;
import com.nets.sg.npx.core.util.CommonConsts;

@Service("merchantService")
public class MerchantServiceImpl implements MerchantService {

    private static final Logger logger = Logger.getLogger(MerchantServiceImpl.class);

    @Autowired
    private MerchantDao merchantDao;

    @Override
    public List<MerchantEntity> getValidMerchant() {
        return merchantDao.getValidMerchantList(CommonConsts.MERCHANT_STATUS_ACTIVE);
    }
    
    @Override
    public MerchantEntity getMerchantByName(String name) {
        return merchantDao.getMerchantByName(name);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public MerchantEntity saveMerchant(MerchantEntity merchant) {

        return merchantDao.save(merchant);
    }
    
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public MerchantEntity updateMerchant(MerchantEntity merchant) {

        return merchantDao.saveOrUpdate(merchant);
    }
    
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public boolean deleteMerchant(MerchantEntity merchant) {
        boolean status = true;
        try {
           merchantDao.delete(merchant);
        } catch (DataAccessException e) {
            status = false;
        }
        return status;
    }
    
    @Override
    public MerchantEntity get(Long oid) {
        return merchantDao.findByOid(oid);
    }

}
