package com.nets.sg.npx.core.dao.mss;

import java.util.List;

import com.nets.sg.npx.core.dao.GenericDao;
import com.nets.sg.npx.core.persistence.entity.mss.RetailerStageEntity;

public interface RetailerStageDao extends GenericDao<RetailerStageEntity, Long> {

    List<RetailerStageEntity> getRecordsByStatus(String batchNo, String groupId, byte status);

    List<RetailerStageEntity> getRecordsByStatus(String createDate, String batchNo, String status);

}
