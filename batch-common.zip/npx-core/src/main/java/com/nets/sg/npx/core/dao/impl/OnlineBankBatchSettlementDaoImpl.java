package com.nets.sg.npx.core.dao.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.OnlineBankBatchSettlementDao;
import com.nets.sg.npx.core.persistence.entity.OnlineBankBatchEntity;

@Repository
public class OnlineBankBatchSettlementDaoImpl extends GenericDaoImpl<OnlineBankBatchEntity, Long> implements OnlineBankBatchSettlementDao {

    @Override
    public List<OnlineBankBatchEntity> getSettlement(Date begin, Date end, String... status) {
        DetachedCriteria criteria = DetachedCriteria.forClass(OnlineBankBatchEntity.class);
        criteria.add(Restrictions.between("statusDate", begin, end));
        criteria.add(Restrictions.in("status", status));
        return this.findByCriteria(criteria);
    }

}
