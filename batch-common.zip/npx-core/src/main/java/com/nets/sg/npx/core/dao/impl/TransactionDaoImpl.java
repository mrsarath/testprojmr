package com.nets.sg.npx.core.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.nets.sg.npx.core.dao.TransactionDao;
import com.nets.sg.npx.core.persistence.entity.TransactionEntity;

@Repository
public class TransactionDaoImpl extends GenericDaoImpl<TransactionEntity, Long> implements TransactionDao {

    @Override
    public List<TransactionEntity> getTransactionForMerchantSettlement(Date from, Date to, List<Long> acquirers, String merchantType, String... state) {

        DetachedCriteria criteria = DetachedCriteria.forClass(TransactionEntity.class, "transaction");
        criteria.add(Restrictions.in("state", state));
        criteria.add(Restrictions.ge("settlementDate", from));
        criteria.add(Restrictions.lt("settlementDate", to));

        if (StringUtils.isNotBlank(merchantType)) {
            criteria.createAlias("transaction.merchant", "merchant");
            criteria.add(Restrictions.eq("merchant.type", merchantType));
        }

        if (!CollectionUtils.isEmpty(acquirers)) {
            criteria.createAlias("transaction.acquirerMerchantMapping", "mapping");
            criteria.createAlias("mapping.acquirer", "acquirer");
            criteria.add(Restrictions.in("acquirer.oid", acquirers));
        }

        criteria.add(Restrictions.isNull("paymentStatus"));

        return this.findByCriteria(criteria);
    }

    @Override
    public List<TransactionEntity> getByState(String... state) {
        DetachedCriteria criteria = DetachedCriteria.forClass(TransactionEntity.class, "transaction");
        criteria.add(Restrictions.in("state", state));
        return this.findByCriteria(criteria);
    }

    @Override
    public List<TransactionEntity> getBySettledDateAndStateAndMType(Date from, Date to, String merchantType, String... state) {

        DetachedCriteria criteria = DetachedCriteria.forClass(TransactionEntity.class, "transaction");
        criteria.add(Restrictions.in("state", state));
        criteria.add(Restrictions.ge("settlementDate", from));
        criteria.add(Restrictions.lt("settlementDate", to));

        if (StringUtils.isNotBlank(merchantType)) {
            criteria.createAlias("transaction.merchant", "merchant");
            criteria.add(Restrictions.eq("merchant.type", merchantType));
        }

        return this.findByCriteria(criteria);
    }

    @Override

    public List<TransactionEntity> getTransactionsForGLUpload(Date from, Date to, String merchantType, String... state) {

        DetachedCriteria criteria = DetachedCriteria.forClass(TransactionEntity.class, "transaction");
        criteria.add(Restrictions.in("state", state));

        criteria.add(Restrictions.ge("settlementDate", from));
        criteria.add(Restrictions.lt("settlementDate", to));

        if (StringUtils.isNotBlank(merchantType)) {
            criteria.createAlias("transaction.merchant", "merchant");
            criteria.add(Restrictions.eq("merchant.type", merchantType));
        }
                
        return this.findByCriteria(criteria);
    }
    
    @Override
    public List<TransactionEntity> getBySettledDateAndPayStatus(Date from, Date to, String payStatus, String merchantType) {

        DetachedCriteria criteria = DetachedCriteria.forClass(TransactionEntity.class, "transaction");
        criteria.add(Restrictions.eq("paymentStatus", payStatus));
        criteria.add(Restrictions.ge("settlementDate", from));
        criteria.add(Restrictions.lt("settlementDate", to));

        if (StringUtils.isNotBlank(merchantType)) {
            criteria.createAlias("transaction.merchant", "merchant");
            criteria.add(Restrictions.eq("merchant.type", merchantType));
        }        
        
        return this.findByCriteria(criteria);
    }

    @Override
    public List<TransactionEntity> getTransactionByCardTypeAndState(Date from, Date to, String cardType, String... state) {
        DetachedCriteria criteria = DetachedCriteria.forClass(TransactionEntity.class, "transaction");
        criteria.add(Restrictions.in("state", state));
        criteria.add(Restrictions.ge("settlementDate", from));
        criteria.add(Restrictions.lt("settlementDate", to));

        criteria.createAlias("transaction.cardType", "cardType");
        criteria.add(Restrictions.eq("cardType.name", cardType));
        return this.findByCriteria(criteria);
    }

}
