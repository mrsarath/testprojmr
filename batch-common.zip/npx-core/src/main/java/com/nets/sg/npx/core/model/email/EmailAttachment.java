package com.nets.sg.npx.core.model.email;

import java.io.File;

public class EmailAttachment {

    private String fileName;

    private File file;

    public EmailAttachment() {

    }

    public EmailAttachment(String fileName, File file) {
        super();
        this.fileName = fileName;
        this.file = file;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

}
