package com.nets.sg.npx.core.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.MerchantDao;
import com.nets.sg.npx.core.persistence.entity.MerchantEntity;

@Repository
public class MerchantDaoImpl extends GenericDaoImpl<MerchantEntity, Long> implements MerchantDao {

    @Override
    public List<MerchantEntity> getValidMerchantList(String status) {
        DetachedCriteria criteria = DetachedCriteria.forClass(MerchantEntity.class, "merchant");
        criteria.add(Restrictions.eq("status", status));
        return findByCriteria(criteria);
    }

    @Override
    public MerchantEntity getMerchantByName(String name) {
        DetachedCriteria criteria = DetachedCriteria.forClass(MerchantEntity.class, "merchant");
        criteria.add(Restrictions.eq("name", name));
        List<MerchantEntity> merchants = findByCriteria(criteria);
        MerchantEntity merchant = null;
        
        if (merchants.size() > 0) {
            merchant = merchants.get(0);
        }
        return merchant;

    }

}
