package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "tm01_merchant")
@org.hibernate.annotations.Entity(dynamicUpdate = true)
public class MerchantEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MERCHANT_ID")
    private Long oid;

    @Column(name = "NETS_MERCHANT_TYPE", nullable = true, length = 2)
    private String type;

    @Column(name = "NAME", nullable = false, length = 40)
    private String name;

    @Column(name = "EMAIL", nullable = true, length = 100)
    private String email;

    @Column(name = "NETS_CUST_CODE", nullable = true, length = 255)
    private String netsCustCode;

    @Column(name = "ADDRESS_LINE1", nullable = false, length = 120)
    private String addressLine1;

    @Column(name = "ADDRESS_LINE2", length = 120)
    private String addressLine2;

    @Column(name = "ADDRESS_LINE3", length = 120)
    private String addressLine3;

    @Column(name = "ADDRESS_LINE4", length = 120)
    private String addressLine4;

    @Column(name = "STATUS", nullable = false, length = 5)
    private String status;

    @Column(name = "BIZ_PHONE_NUM", nullable = false)
    private String businessPhoneNo;

    @Column(name = "ZIP", length = 15, nullable = false)
    private String postalCode;

    @Column(name = "MER_CAT_CODE", nullable = false)
    private Integer catCode;

    @Column(name = "MERCHANT_LEVEL", nullable = false)
    private String merchantLvl;

    @Column(name = "ALT_BIZ_PHONE_NUM", nullable = false)
    private String altBizPhone;

    @Column(name = "MOBILE_PHONE_NUM", nullable = true)
    private String mobilePhone;

    @Column(name = "FAX", nullable = true)
    private String fax;

    @Column(name = "DESCRIPTION", nullable = false)
    private String Description;

    @Column(name = "CREATED_BY", nullable = false)
    private Integer createdBy;

    @Column(name = "CREATION_DATE", nullable = false)
    private Date createdDate;

    @Column(name = "LAST_UPDATED_BY", nullable = true)
    private Integer updateBy;

    @Column(name = "LAST_UPDATE_DATE", nullable = true)
    private Date updatedDate;

    @Column(name = "MER_TIER_ID", nullable = true)
    private Integer merTierId;

    @Column(name = "COUNTRY", nullable = false)
    private String country;

    @Column(name = "CITY", nullable = true)
    private String city;

    @Column(name = "TYPE", nullable = false)
    private String industryType;

    @OneToOne(cascade = CascadeType.ALL)
    @PrimaryKeyJoinColumn(name = "MERCHANT_ID")
    private MerchantConfigEntity config;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="MERCHANT_ID")
    private Set<MerchantCurrencyEntity> currencies = new HashSet<>();

    
    @OneToMany(fetch=FetchType.LAZY)
    @JoinColumn(name="MERCHANT_ID")
    private Set<AcquirerMerchantMappingEntity> acquirerMerchantMapping;

    //@OneToMany(mappedBy = "merchant")
    //private Set<AcqMerAccountEntity> acquirerMerchantAccount;

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIndustryType() {
        return industryType;
    }

    public void setIndustryType(String type) {
        this.industryType = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MerchantConfigEntity getConfig() {
        return config;
    }

    public void setConfig(MerchantConfigEntity config) {
        if (config != null && oid != null) // TODO
            config.setOid(oid);
        this.config = config;
    }
    

    public Set<MerchantCurrencyEntity> getCurrencies() {
        return currencies;
    }

    public void setCurrencies(Set<MerchantCurrencyEntity> currencies) {
        this.currencies = currencies;
    }
    
    public void addCurrencies(MerchantCurrencyEntity currency) {
        this.getCurrencies().add(currency);
        
        if (currency != null && getOid() != null) {
            //currency.setMerchant(this);
            currency.setMerchantId(getOid().intValue());
        }
    }    

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNetsCustCode() {
        return netsCustCode;
    }

    public void setNetsCustCode(String netsCustCode) {
        this.netsCustCode = netsCustCode;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getAddressLine4() {
        return addressLine4;
    }

    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }

    public Set<AcquirerMerchantMappingEntity> getAcquirerMerchantMapping() {
        return acquirerMerchantMapping;
    }

    public void setAcquirerMerchantMapping(Set<AcquirerMerchantMappingEntity> acquirerMerchantMapping) {
        this.acquirerMerchantMapping = acquirerMerchantMapping;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getCatCode() {
        return catCode;
    }

    public void setCatCode(Integer catCode) {
        this.catCode = catCode;
    }

    public String getMerchantLvl() {
        return merchantLvl;
    }

    public void setMerchantLvl(String merchantLvl) {
        this.merchantLvl = merchantLvl;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Integer getMerTierId() {
        return merTierId;
    }

    public void setMerTierId(Integer tierId) {
        this.merTierId = tierId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAltBizPhone() {
        return altBizPhone;
    }

    public void setAltBizPhone(String altBizPhone) {
        this.altBizPhone = altBizPhone;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getBusinessPhoneNo() {
        return businessPhoneNo;
    }

    public void setBusinessPhoneNo(String businessPhoneNo) {
        this.businessPhoneNo = businessPhoneNo;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /*public Set<AcqMerAccountEntity> getAcquirerMerchantAccount() {
        return acquirerMerchantAccount;
    }

    public void setAcquirerMerchantAccount(Set<AcqMerAccountEntity> acquirerMerchantAccount) {
        this.acquirerMerchantAccount = acquirerMerchantAccount;
    }*/

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((oid == null) ? 0 : oid.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MerchantEntity other = (MerchantEntity) obj;
        if (oid == null) {
            if (other.oid != null)
                return false;
        } else if (!oid.equals(other.oid))
            return false;
        return true;
    }

}
