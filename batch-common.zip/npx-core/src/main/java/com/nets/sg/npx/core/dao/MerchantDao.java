package com.nets.sg.npx.core.dao;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.MerchantEntity;

public interface MerchantDao extends GenericDao<MerchantEntity, Long> {

    List<MerchantEntity> getValidMerchantList(String status);

    MerchantEntity getMerchantByName(String name);

}
