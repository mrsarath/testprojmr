package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "ttr01_transaction")
public class TransactionEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TRANSACTION_ID")
    private Long oid;

    @Column(name = "TARGET_AMOUNT", precision = 10, scale = 2, nullable = false)
    private BigDecimal amount;

    @Column(name = "TIP_AMOUNT", precision = 10, scale = 2, nullable = false)
    private BigDecimal tipAmount;

    @Column(name = "STATE", length = 5, nullable = false)
    private String state;

    @Column(name = "MDR_PERCENT", precision = 10, scale = 2, nullable = false)
    private BigDecimal mdrPercent;

    @Column(name = "BANK_SETTLE_DATE")
    private Timestamp settlementDate;

    @Column(name = "PAYMENT_STATUS", length = 2)
    private String paymentStatus;

    @Column(name = "TRAN_TYPE", length = 5)
    private String type;

    @Column(name = "AUTHORIZE_DATE")
    private Date authDate;

    @Column(name = "ACQ_TXN_RESPONSE_CODE", length = 10)
    private String responseCode;

    @Column(name = "CARD_NO", length = 255)
    private String cardNo;

    @Column(name = "CARD_NO_SUFFIX", length = 4, nullable = true)
    private String cardNoSuffix;

    @Column(name = "EC_MID", length = 20, nullable = false)
    private String mid;

    @Column(name = "TID", length = 20, nullable = false)
    private String tid;

    @Column(name = "USER_DATA", length = 255)
    private String userData;

    @Column(name = "ACQ_APPROVAL_CODE", length = 10)
    private String acquirerApprovalCode;

    @Column(name = "CAPTURE_TYPE")
    private Integer captureType;

    @Column(name = "CARD_EXPR_DATE")
    private String cardExpiryDate;

    @Column(name = "ACQ_AUTH_RESPONSE_ID", length = 20)
    private String retrivalReferenceNo;

    @Column(name = "EMV_DATA", length = 2000)
    private String emvRequestData;

    @Column(name = "ACQ_ORDER_ID")
    private String acqReferenceData;

    @OneToOne
    @JoinColumn(name = "ACQ_MER_MAPPING_ID")
    @NotFound(action = NotFoundAction.IGNORE)
    private AcquirerMerchantMappingEntity acquirerMerchantMapping;

    @ManyToOne
    @JoinColumn(name = "MERCHANT_ID")
    private MerchantEntity merchant;

    @ManyToOne
    @JoinColumn(name = "BANK_BATCH_ID")
    private OnlineBankBatchEntity settlement;

    @OneToOne
    @JoinColumn(name = "POS_ID")
    private PhysicalPosEntity physicalPos;

    @OneToOne
    @JoinColumn(name = "CARD_TYPE_ID")
    private CardTypeEntity cardType;

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public BigDecimal getMdrPercent() {
        return mdrPercent;
    }

    public void setMdrPercent(BigDecimal mdrPercent) {
        this.mdrPercent = mdrPercent;
    }

    public Timestamp getSettlementDate() {
        return settlementDate;
    }

    public void setSettlementDate(Timestamp settlementDate) {
        this.settlementDate = settlementDate;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getAuthDate() {
        return authDate;
    }

    public void setAuthDate(Date authDate) {
        this.authDate = authDate;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardNoSuffix() {
        return cardNoSuffix;
    }

    public void setCardNoSuffix(String cardNoSuffix) {
        this.cardNoSuffix = cardNoSuffix;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public AcquirerMerchantMappingEntity getAcquirerMerchantMapping() {
        return acquirerMerchantMapping;
    }

    public void setAcquirerMerchantMapping(AcquirerMerchantMappingEntity acquirerMerchantMapping) {
        this.acquirerMerchantMapping = acquirerMerchantMapping;
    }

    public MerchantEntity getMerchant() {
        return merchant;
    }

    public void setMerchant(MerchantEntity merchant) {
        this.merchant = merchant;
    }

    public OnlineBankBatchEntity getSettlement() {
        return settlement;
    }

    public void setSettlement(OnlineBankBatchEntity settlement) {
        this.settlement = settlement;
    }

    public PhysicalPosEntity getPhysicalPos() {
        return physicalPos;
    }

    public void setPhysicalPos(PhysicalPosEntity physicalPos) {
        this.physicalPos = physicalPos;
    }

    public CardTypeEntity getCardType() {
        return cardType;
    }

    public void setCardType(CardTypeEntity cardType) {
        this.cardType = cardType;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getUserData() {
        return userData;
    }

    public void setUserData(String userData) {
        this.userData = userData;
    }

    public String getAcquirerApprovalCode() {
        return acquirerApprovalCode;
    }

    public void setAcquirerApprovalCode(String acquirerApprovalCode) {
        this.acquirerApprovalCode = acquirerApprovalCode;
    }

    public Integer getCaptureType() {
        return captureType;
    }

    public void setCaptureType(Integer captureType) {
        this.captureType = captureType;
    }

    public String getCardExpiryDate() {
        return cardExpiryDate;
    }

    public void setCardExpiryDate(String cardExpiryDate) {
        this.cardExpiryDate = cardExpiryDate;
    }

    public String getRetrivalReferenceNo() {
        return retrivalReferenceNo;
    }

    public void setRetrivalReferenceNo(String retrivalReferenceNo) {
        this.retrivalReferenceNo = retrivalReferenceNo;
    }

    public BigDecimal getTipAmount() {
        return tipAmount;
    }

    public void setTipAmount(BigDecimal tipAmount) {
        this.tipAmount = tipAmount;
    }

    public String getEmvRequestData() {
        return emvRequestData;
    }

    public void setEmvRequestData(String emvRequestData) {
        this.emvRequestData = emvRequestData;
    }

    public String getAcqReferenceData() {
        return acqReferenceData;
    }

    public void setAcqReferenceData(String acqReferenceData) {
        this.acqReferenceData = acqReferenceData;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((oid == null) ? 0 : oid.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TransactionEntity other = (TransactionEntity) obj;
        if (oid == null) {
            if (other.oid != null)
                return false;
        } else if (!oid.equals(other.oid))
            return false;
        return true;
    }

}
