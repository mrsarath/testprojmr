package com.nets.sg.npx.core.dao;

import com.nets.sg.npx.core.persistence.entity.CountryEntity;

public interface CountryDao extends GenericDao<CountryEntity, Long> {

    CountryEntity getCountryByName(String name);

}
