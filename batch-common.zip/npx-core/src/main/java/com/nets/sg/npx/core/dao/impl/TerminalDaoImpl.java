package com.nets.sg.npx.core.dao.impl;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.TerminalDao;
import com.nets.sg.npx.core.persistence.entity.PhysicalPosEntity;

@Repository
public class TerminalDaoImpl extends GenericDaoImpl<PhysicalPosEntity, Long> implements TerminalDao {

    @Override
    public PhysicalPosEntity getTerminalByName(String name) {
        DetachedCriteria criteria = DetachedCriteria.forClass(PhysicalPosEntity.class, "terminal");
        criteria.add(Restrictions.eq("name", name));
        return DataAccessUtils.uniqueResult(findByCriteria(criteria));
    }

}
