package com.nets.sg.npx.core.service;

import java.util.Date;
import java.util.List;

import com.nets.sg.npx.core.persistence.entity.OnlineBankBatchEntity;

public interface OnlineBankBatchSettlementService {

    List<OnlineBankBatchEntity> getSettlement(Date begin, Date end, String... status);

    List<OnlineBankBatchEntity> saveAll(List<OnlineBankBatchEntity> settlements);
}
