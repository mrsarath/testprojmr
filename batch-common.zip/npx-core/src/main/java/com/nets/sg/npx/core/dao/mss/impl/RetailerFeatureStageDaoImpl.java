package com.nets.sg.npx.core.dao.mss.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.nets.sg.npx.core.dao.impl.GenericDaoImpl;
import com.nets.sg.npx.core.dao.mss.RetailerFeatureStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.RetailerFeatureStageEntity;

@Repository
public class RetailerFeatureStageDaoImpl extends GenericDaoImpl<RetailerFeatureStageEntity, Long> implements RetailerFeatureStageDao {

    @Override
    public List<RetailerFeatureStageEntity> getRecordsByStatus(String batchNo, String retId, String termId, byte recordStatus) {

        DetachedCriteria criteria = DetachedCriteria.forClass(RetailerFeatureStageEntity.class);
        criteria.add(Restrictions.eq("batchNo", batchNo));
        criteria.add(Restrictions.eq("retId", retId));
        criteria.add(Restrictions.eq("termId", termId));
        criteria.add(Restrictions.eq("recordStatus", recordStatus));

        List<RetailerFeatureStageEntity> records = findByCriteria(criteria);

        return records;

    }

    @Override
    public List<RetailerFeatureStageEntity> getRecordsByStatus(String createDate, String batchNo, String status) {
        DetachedCriteria criteria = DetachedCriteria.forClass(RetailerFeatureStageEntity.class);
        criteria.add(Restrictions.eq("recordCreateDate", createDate));        
        if (!StringUtils.isEmpty(batchNo))
            criteria.add(Restrictions.eq("batchNo", batchNo));
        
        criteria.add(Restrictions.eq("recordStatus", status));

        return findByCriteria(criteria);

    }

}
