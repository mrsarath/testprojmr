package com.nets.sg.npx.core.service.mss;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.mss.RetailerFeatureStageEntity;

public interface RetailerFeatureStageService {

    RetailerFeatureStageEntity save(RetailerFeatureStageEntity record);

    List<RetailerFeatureStageEntity> getRecords(String batchNo, String retId, String termId, byte status);
    
    List<RetailerFeatureStageEntity> getRecords(String createDate, String batchNo, String status);

    RetailerFeatureStageEntity update(RetailerFeatureStageEntity retailer);

}
