package com.nets.sg.npx.core.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.SapDataMappingConfigDao;
import com.nets.sg.npx.core.persistence.entity.SapDataMappingConfigEntity;
import com.nets.sg.npx.core.service.SapDataMappingConfigService;

@Service("sapDataMappingConfigService")
public class SapDataMappingConfigServiceImpl implements SapDataMappingConfigService {

    private static final Logger logger = Logger.getLogger(SapDataMappingConfigServiceImpl.class);

    @Autowired
    private SapDataMappingConfigDao sapDataMappingConfigDao;

    @Override
    public SapDataMappingConfigEntity getByDocTypeAndMapping(String docType, String mapping) {

        return sapDataMappingConfigDao.getByDocTypeAndMapping(docType, mapping);
    }

    @Override
    public SapDataMappingConfigEntity getByDocTypeMappingAndType(String docType, String mapping, String type) {
        return sapDataMappingConfigDao.getByDocTypeMappingAndType(docType, mapping, type);
    }

}
