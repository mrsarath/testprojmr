package com.nets.sg.npx.core.util;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class CommonConsts {

    public static final String TRAN_STATE_APPROVED = "01";

    public static final String TRAN_STATE_REJECTED = "03";

    public static final String TRAN_STATE_SETTLED = "04";

    public static final String TRAN_STATE_RECONCILLED = "05";

    public static final String ONLINE_BANK_BATCH_STATUS_APPROVED = "2";
    public static final String ONLINE_BANK_BATCH_STATUS_RECONCILED = "7";

    public static final String MERCHANT_STATUS_ACTIVE = "2";
    public static final String MERCHANT_STATUS_INACTIVE = "3";
    public static final String MERCHANT_STATUS_LOCKED = "4";
    
    public static final String TERMINAL_STATUS_ACTIVE = "2";
    public static final String TERMINAL_STATUS_INACTIVE = "3";
    public static final String TERMINAL_STATUS_LOCKED = "4";
    public static final String TERMINAL_STATUS_SUSPENDED = "5";
       
    
    public static final String TRAN_TYPE_CONVERT = "01";
    public static final String TRAN_TYPE_AUTHORIZE = "02";
    public static final String TRAN_TYPE_SALE = "03";
    public static final String TRAN_TYPE_SALE_COMPLETE = "04";
    public static final String TRAN_TYPE_REFUND = "05";
    public static final String TRAN_TYPE_VOID_SALE = "06";
    public static final String TRAN_TYPE_VOID_REFUND = "07";
    public static final String TRAN_TYPE_VOID_SALE_COMPLETE = "08";
    public static final String TRAN_TYPE_VOID_SALE_ADJUST = "09";
    public static final String TRAN_TYPE_SALE_ADJUST = "10";
    public static final String TRAN_TYPE_VOID_AUTHORIZE = "11";
    public static final String TRAN_TYPE_OFFLINE_SALE = "12";
    public static final String TRAN_TYPE_BALANCE_INQUIRY = "13";
    public static final String TRAN_TYPE_PURCHASE = "14";
    public static final String TRAN_TYPE_INSTALLMENT_SALE = "15";
    public static final String TRAN_TYPE_VOID_INSTALLMENT_SALE = "16";
    public static final String TRAN_TYPE_VOID_OFFLINE_SALE = "17";
    public static final String TRAN_TYPE_CASH = "18";
    public static final String TRAN_TYPE_VOID_CASH = "19";
    public static final String TRAN_TYPE_CHEQUE = "20";
    public static final String TRAN_TYPE_VOID_CHEQUE = "21";

    public static final String BATCH_TRAN_CODE_BILL_CREDIT = "25";

    public static final String PRINT_PAYMENT_ADVICE_INDICATOR_NO = "N";

    public static final String PRINT_PAYMENT_ADVICE_INDICATOR_YES = "Y";

    public static final String DELIVERY_MODE_FAX = "F";

    public static final String DELIVERY_MODE_EMAIL = "E";

    public static final String SEQUENCE_FIRST_FILE_OF_THE_DAY = "01";

    public static final DateTimeFormatter DATETIME_FORMAT_CCYYMMDDHHMMSS = DateTimeFormat.forPattern("yyyyMMddHHmmss");

    public static final DateTimeFormatter DATETIME_FORMAT_CCYYMMDD = DateTimeFormat.forPattern("yyyyMMdd");

    public static final DateTimeFormatter DATETIME_FORMAT_YYMMDD = DateTimeFormat.forPattern("yyMMdd");

    public static final DateTimeFormatter DATETIME_FORMAT_CCYY_MM_DD = DateTimeFormat.forPattern("yyyy-MM-dd");

    public static final DateTimeFormatter DATETIME_FORMAT_DD_MM_CCYY = DateTimeFormat.forPattern("dd-MM-yyyy");

    public static final DateTimeFormatter DATETIME_FORMAT_DDfsMMfsCCYY = DateTimeFormat.forPattern("dd/MM/yyyy");

    public static final DateTimeFormatter DATETIME_FORMAT_HHMMSS = DateTimeFormat.forPattern("HHmmss");

    public static final DateTimeFormatter DATETIME_FORMAT_CCYY = DateTimeFormat.forPattern("yyyy");

    public static final DateTimeFormatter DATETIME_FORMAT_DDMM = DateTimeFormat.forPattern("ddMM");

    public static final DateTimeFormatter DATETIME_FORMAT_YYMMDDHHMMSSSSS = DateTimeFormat.forPattern("yyMMddHHmmssSSS");

    public static final String BATCH_STATUS_SUBMITTED = "1";

    public static final String BATCH_STATUS_ACKNOWLEGED = "2";

    public static final String BATCH_STATUS_SUCCESS = "3";

    public static final String BATCH_STATUS_REJECTED = "4";

    public static final String BATCH_STATUS_SUCCESS_WITH_REJECTION = "5";

    public static final String RECORD_TYPE_CONTROL = "0";

    public static final String RECORD_TYPE_HEADER = "1";

    public static final String RECORD_TYPE_SUMMARY = "2";

    public static final String RECORD_TYPE_ADVICE_FIXED = "3";

    public static final String RECORD_TYPE_ADVICE_FREE = "4";

    public static final String RECORD_TYPE_TRAILER = "9";

    public static final String RESPONSE_FILE_STATUS_SUCCESSFUL = "O";

    public static final String RESPONSE_FILE_STATUS_ROS_NOT_VALID = "S";

    public static final String RESPONSE_FILE_STATUS_IBG_NOT_VALID = "F";

    public static final String RESPONSE_FILE_STATUS_INSUFFICIENT_FUNDS = "R";

    public static final String TRAN_PAYMENT_STATUS_SUBMITTED = "01";

    public static final String TRAN_PAYMENT_STATUS_REJECTED = "02";

    public static final String TRAN_PAYMENT_STATUS_APPROVED = "03";

    public static final String MERCHANT_FUNDING_CLEAR_FATE_OK = "0";

    public static final String MERCHANT_FUNDING_CLEAR_FATE_KO = "1";

    public static final String MERCHANT_FUNDING_RECORD_GLNOTPOSTED = "1";

    public static final String MERCHANT_FUNDING_RECORD_GLPOSTED = "2";

    public static final String BANK_CFG_ATTR_NAME_ORG_BANK_CODE = "ORG_BANK_CODE";

    public static final String BANK_CFG_ATTR_NAME_ORG_BRANCH_CODE = "ORG_BRANCH_CODE";

    public static final String BANK_CFG_ATTR_NAME_ORG_ACCOUNT_NO = "ORG_ACCOUNT_NO";

    public static final String BANK_CFG_ATTR_NAME_ORG_ACCOUNT_NAME = "ORG_ACCOUNT_NAME";

}
