package com.nets.sg.npx.core.service;

import java.util.List;

import com.nets.sg.npx.core.persistence.entity.MerchantEntity;

public interface MerchantService {

    List<MerchantEntity> getValidMerchant();
    
    MerchantEntity saveMerchant(MerchantEntity merchant);

    MerchantEntity getMerchantByName(String name);

    MerchantEntity updateMerchant(MerchantEntity merchant);

    boolean deleteMerchant(MerchantEntity merchant);
    
    MerchantEntity get(Long oid);

}
