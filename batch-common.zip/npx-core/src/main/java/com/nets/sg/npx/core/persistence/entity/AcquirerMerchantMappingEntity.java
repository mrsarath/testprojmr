package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
@Table(name = "ta03_acquirer_merchant_mapping")
public class AcquirerMerchantMappingEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MER_MAPPING_ID")
    private Long oid;

    @ManyToOne(optional = false)
    @JoinColumn(name = "ACQUIRER_ID", nullable=false)
    private AcquirerEntity acquirer;
    
    /*
    @ManyToOne(optional = false)
    @JoinColumn(name = "MERCHANT_ID", nullable=false)
    private MerchantEntity merchant;*/
    
    /*@Column(name="ACQUIRER_ID")
    private int acquirerId;*/
    
    @Column(name="MERCHANT_ID", nullable=false)
    private int merchantId;

    //
    
    @Column(name="CREATED_BY")
    private int createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="CREATION_DATE")
    private Date creationDate;
    
    @Column(name="LAST_UPDATED_BY")
    private Integer lastUpdatedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="LAST_UPDATED_DATE")
    private Date lastUpdatedDate;

    @Column(name="NAME")
    private String name;
    
    @Column(name="SPLIT_TYPE")
    private String splitType;

    @Column(name="STATUS")
    private String status;

    
    //@OneToMany(mappedBy="acquirerMerchantMapping", fetch=FetchType.LAZY, cascade={CascadeType.ALL})
    @OneToMany(fetch=FetchType.LAZY, cascade={CascadeType.ALL})
    @JoinColumn(name="MER_MAPPING_ID")
    private Set<AcqMerAccountEntity> acqMerAccounts = new HashSet<>();
    
    @OneToMany(fetch=FetchType.LAZY, cascade={CascadeType.ALL})
    @JoinColumn(name="DEFAULT_ACQ_MAPPING_ID")
    private Set<AcqMerAccountEntity> acqMerAccountsDef = new HashSet<>();

    
    @OneToMany(fetch=FetchType.LAZY, cascade={CascadeType.ALL})
    @JoinColumn(name="ACQ_MER_MAPPING_ID")
    private Set<AcqMerchantInstallmentEntity> acqMerInstallments = new HashSet<>();    
    
    
    //
    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public AcquirerEntity getAcquirer() {
        return acquirer;
    }

    public void setAcquirer(AcquirerEntity acquirer) {
        this.acquirer = acquirer;
    }
        
    // 
    
    public int getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }
    
    public Integer getLastUpdatedBy() {
        return this.lastUpdatedBy;
    }

    public void setLastUpdatedBy(Integer lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return this.lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSplitType() {
        return this.splitType;
    }

    public void setSplitType(String splitType) {
        this.splitType = splitType;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    
   /* public MerchantEntity getMerchant() {
        return merchant;
    }

    public void setMerchant(MerchantEntity merchant) {
        this.merchant = merchant;
    }*/
   

    /*public int getAcquirerId() {
        return acquirerId;
    }

    public void setAcquirerId(int acquirerId) {
        this.acquirerId = acquirerId;
    }*/

    public int getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(int merchantId) {
        this.merchantId = merchantId;
    }
    
    public Set<AcqMerAccountEntity> getAcqMerAccounts() {
        return this.acqMerAccounts;
    }

    public void setAcqMerAccounts(Set<AcqMerAccountEntity> acqMerAccounts) {
        this.acqMerAccounts = acqMerAccounts;
    }

    public AcqMerAccountEntity addAcqMerAccount(AcqMerAccountEntity acqMerAccount) {
        getAcqMerAccounts().add(acqMerAccount);
        //acqMerAccount.setAcquirerMerchantMapping(this);
        if (getOid() != null)
            acqMerAccount.setMerchantMappingId(getOid().intValue());

        return acqMerAccount;
    }

    public AcqMerAccountEntity removeAcqMerAccount(AcqMerAccountEntity acqMerAccount) {
        getAcqMerAccounts().remove(acqMerAccount);
        //acqMerAccount.setAcquirerMerchantMapping(null);
        acqMerAccount.setMerchantMappingId(0);

        return acqMerAccount;
    }
    
   
    public Set<AcqMerAccountEntity> getAcqMerAccountsDef() {
        return acqMerAccountsDef;
    }

    public void setAcqMerAccountsDef(Set<AcqMerAccountEntity> acqMerAccountsDef) {
        this.acqMerAccountsDef = acqMerAccountsDef;
    }
    
    public AcqMerAccountEntity addAcqMerAccountDef(AcqMerAccountEntity acqMerAccountDef) {
        getAcqMerAccountsDef().add(acqMerAccountDef);
        
        if (getOid() != null)
            acqMerAccountDef.setDefAcqMappingId(getOid().intValue()); 
        //acqMerAccountDef.setDefaultAcqMerchantMapping(this);
        
        return acqMerAccountDef;
    }

    public Set<AcqMerchantInstallmentEntity> getAcqMerInstallments() {
        return this.acqMerInstallments;
    }

    public void setAcqMerInstallments(Set<AcqMerchantInstallmentEntity> acqMerInstallments) {
        this.acqMerInstallments = acqMerInstallments;
    }

    public AcqMerchantInstallmentEntity addAcqMerInstallment(AcqMerchantInstallmentEntity acqMerInstallment) {
        getAcqMerInstallments().add(acqMerInstallment);
        
        if (getOid() != null) 
            acqMerInstallment.setAcqMerMappingId(getOid().intValue());

        return acqMerInstallment;
    }

    public AcqMerchantInstallmentEntity removeAcqMerInstallment(AcqMerchantInstallmentEntity acqMerInstallment) {
        getAcqMerInstallments().remove(acqMerInstallment);
        acqMerInstallment.setAcqMerMappingId(0);

        return acqMerInstallment;
    }
    
    

}
