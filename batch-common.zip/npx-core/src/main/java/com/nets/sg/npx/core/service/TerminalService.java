package com.nets.sg.npx.core.service;

import com.nets.sg.npx.core.persistence.entity.PhysicalPosEntity;

public interface TerminalService {

    // this name is NETS TID
    PhysicalPosEntity getTerminalByName(String name);

    PhysicalPosEntity save(PhysicalPosEntity terminal);
    
    PhysicalPosEntity update(PhysicalPosEntity terminal);

}
