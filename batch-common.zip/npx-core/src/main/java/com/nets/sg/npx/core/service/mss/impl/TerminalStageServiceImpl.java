package com.nets.sg.npx.core.service.mss.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.mss.TerminalStageDao;
import com.nets.sg.npx.core.persistence.entity.mss.TerminalStageEntity;
import com.nets.sg.npx.core.service.mss.TerminalStageService;

@Service
public class TerminalStageServiceImpl implements TerminalStageService {

    @Autowired
    private TerminalStageDao syncTerminalDao;

    @Override
    public TerminalStageEntity save(TerminalStageEntity record) {

        return syncTerminalDao.save(record);
    }

    @Override
    public TerminalStageEntity update(TerminalStageEntity record) {

        return syncTerminalDao.saveOrUpdate(record);
    }
    
    @Override
    public List<TerminalStageEntity> getRecords(String batchNo, String retailId, byte status) {
        return syncTerminalDao.getRecords(batchNo, retailId, status);
    }

    @Override
    public List<TerminalStageEntity> getRecords(String date, String batchNo, String status) {
        return syncTerminalDao.getRecords(date, batchNo, status);
    }

}
