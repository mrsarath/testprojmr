package com.nets.sg.npx.core.persistence.entity.mss;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * The persistent class for the ttr16_mss_stage_ret_feature database table.
 * 
 */
@Entity
@Table(name = "ttr16_mss_stage_ret_feature")
public class RetailerFeatureStageEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RETFEATURE_ID")
    private Long retfeatureId;

    @Column(name = "RECORD_STATUS")
    private String recordStatus;

    @Column(name = "RECORD_DATE", nullable = false)
    private Date recordDate;

    @Column(name = "RECORD_CREATED_DATE", nullable = false)
    private String recordCreateDate;

    @Column(name = "BATCH_NO", nullable = false)
    private String batchNo;

    @Column(name = "RET_ID")
    private String retId;

    @Column(name = "TERM_ID")
    private String termId;

    @Column(name = "FEATURE_ID")
    private String featureId;

    @Column(name = "SUB_FEATURE_ID")
    private String subFeatureId;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    private String createdDate;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_DATE")
    private String updatedDate;

    public RetailerFeatureStageEntity() {
    }

    public Long getRetfeatureId() {
        return this.retfeatureId;
    }

    public void setRetfeatureId(Long retfeatureId) {
        this.retfeatureId = retfeatureId;
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getFeatureId() {
        return this.featureId;
    }

    public void setFeatureId(String featureId) {
        this.featureId = featureId;
    }

    public String getRetId() {
        return this.retId;
    }

    public void setRetId(String retId) {
        this.retId = retId;
    }

    public String getSubFeatureId() {
        return this.subFeatureId;
    }

    public void setSubFeatureId(String subFeatureId) {
        this.subFeatureId = subFeatureId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTermId() {
        return this.termId;
    }

    public void setTermId(String termId) {
        this.termId = termId;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getRecordCreateDate() {
        return recordCreateDate;
    }

    public void setRecordCreateDate(String recordCreateDate) {
        this.recordCreateDate = recordCreateDate;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + retfeatureId.intValue();
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RetailerFeatureStageEntity other = (RetailerFeatureStageEntity) obj;
        if (retfeatureId != other.retfeatureId)
            return false;
        return true;
    }

}