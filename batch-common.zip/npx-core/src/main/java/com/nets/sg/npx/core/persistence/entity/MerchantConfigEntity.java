package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tm02_merchant_cfg")
public class MerchantConfigEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "MERCHANT_ID")
    private Long oid;

    @Column(name = "INVOICE_MER_BANK_CODE", nullable = true, length = 6)
    private String bankCode;

    @Column(name = "INVOICE_MER_BRANCH_CODE", nullable = true, length = 3)
    private String branchCode;

    @Basic
    @Column(name = "INVOICE_MER_SAVING_ACCT_NO", length = 30)
    private String accNo;

    @Column(name = "COMMERCIAL_ACCT_NAME", length = 30)
    private String accName;

    // MER_ETRANSFER_ACCT_NO

    @Column(name = "PAYMENT_METHOD", nullable = false)
    private String paymentMethod;

    @Column(name = "LAST_UPDATED_BY", nullable = true)
    private Integer updatedBy;

    @Column(name = "LAST_UPDATE_DATE", nullable = true)
    private Date updatedDate;

    @Column(name = "CREATION_DATE", nullable = false)
    private Date creationDate;

    @Column(name = "CREATED_BY", nullable = false)
    private Integer createdBy;

    @Column(name = "DEFAULT_ACQUIRER_ID", nullable = true)
    private Integer aquirerId;

    @Column(name = "DEFAULT_ISO_CURRENCY_NAME", nullable = false)
    private String currencyName;

    @OneToOne(mappedBy="config")
    @JoinColumn(name = "MERCHANT_ID", nullable=false)
    @MapsId
    private MerchantEntity merchant;

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public String getAccName() {
        return accName;
    }

    public void setAccName(String accName) {
        this.accName = accName;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Integer getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Integer updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getAquirerId() {
        return aquirerId;
    }

    public void setAquirerId(Integer aquirerId) {
        this.aquirerId = aquirerId;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

    public MerchantEntity getMerchant() {
        return merchant;
    }

    public void setMerchant(MerchantEntity merchant) {
        this.merchant = merchant; // TODO
        if (merchant != null)
            this.oid = merchant.getOid();
    }
}
