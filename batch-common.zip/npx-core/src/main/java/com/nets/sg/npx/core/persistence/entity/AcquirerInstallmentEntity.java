package com.nets.sg.npx.core.persistence.entity;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the ta16_acq_installment database table.
 * 
 */
@Entity
@Table(name = "ta16_acq_installment")
public class AcquirerInstallmentEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ACQ_INST_ID")
    private int acqInstId;

    @Column(name = "ACQ_ID")
    private int acqId;

    @Column(name = "BANK_INST_PLAN_ID")
    private String bankInstPlanId;

    @Column(name = "CREATED_BY")
    private int createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "HANDLING_FEE_AMOUNT")
    private BigDecimal handlingFeeAmount;

    @Column(name = "HANDLING_FEE_PERCENTAGE")
    private BigDecimal handlingFeePercentage;

    @Column(name = "HANDLING_FEE_TYPE")
    private String handlingFeeType;

    @Column(name = "INST_PLAN_NAME")
    private String instPlanName;

    @Column(name = "INT_FREE_MONTHS")
    private int intFreeMonths;

    @Column(name = "INT_RATES")
    private BigDecimal intRates;

    @Column(name = "LAST_UPDATED_BY")
    private int lastUpdatedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATED_DATE")
    private Date lastUpdatedDate;

    @Column(name = "MINIMUM_AMOUNT")
    private BigDecimal minimumAmount;

    @Column(name = "ORDER_POSITION")
    private String orderPosition;

    @Column(name = "PAYMENT_TERM")
    private int paymentTerm;

    @Column(name = "PRODUCT_CODE")
    private String productCode;

    @Column(name = "PROGRAM_CODE")
    private String programCode;

    @Column(name = "TERM_MODE_CODE")
    private String termModeCode;

    //@OneToMany(mappedBy = "acqInstallment")
    //private Set<AcqMerchantInstallmentEntity> acqMerInstallments = new HashSet<>();

    public AcquirerInstallmentEntity() {
    }

    public int getAcqInstId() {
        return this.acqInstId;
    }

    public void setAcqInstId(int acqInstId) {
        this.acqInstId = acqInstId;
    }

    public int getAcqId() {
        return this.acqId;
    }

    public void setAcqId(int acqId) {
        this.acqId = acqId;
    }

    public String getBankInstPlanId() {
        return this.bankInstPlanId;
    }

    public void setBankInstPlanId(String bankInstPlanId) {
        this.bankInstPlanId = bankInstPlanId;
    }

    public int getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public BigDecimal getHandlingFeeAmount() {
        return this.handlingFeeAmount;
    }

    public void setHandlingFeeAmount(BigDecimal handlingFeeAmount) {
        this.handlingFeeAmount = handlingFeeAmount;
    }

    public BigDecimal getHandlingFeePercentage() {
        return this.handlingFeePercentage;
    }

    public void setHandlingFeePercentage(BigDecimal handlingFeePercentage) {
        this.handlingFeePercentage = handlingFeePercentage;
    }

    public String getHandlingFeeType() {
        return this.handlingFeeType;
    }

    public void setHandlingFeeType(String handlingFeeType) {
        this.handlingFeeType = handlingFeeType;
    }

    public String getInstPlanName() {
        return this.instPlanName;
    }

    public void setInstPlanName(String instPlanName) {
        this.instPlanName = instPlanName;
    }

    public int getIntFreeMonths() {
        return this.intFreeMonths;
    }

    public void setIntFreeMonths(int intFreeMonths) {
        this.intFreeMonths = intFreeMonths;
    }

    public BigDecimal getIntRates() {
        return this.intRates;
    }

    public void setIntRates(BigDecimal intRates) {
        this.intRates = intRates;
    }

    public int getLastUpdatedBy() {
        return this.lastUpdatedBy;
    }

    public void setLastUpdatedBy(int lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Date getLastUpdatedDate() {
        return this.lastUpdatedDate;
    }

    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public BigDecimal getMinimumAmount() {
        return this.minimumAmount;
    }

    public void setMinimumAmount(BigDecimal minimumAmount) {
        this.minimumAmount = minimumAmount;
    }

    public String getOrderPosition() {
        return this.orderPosition;
    }

    public void setOrderPosition(String orderPosition) {
        this.orderPosition = orderPosition;
    }

    public int getPaymentTerm() {
        return this.paymentTerm;
    }

    public void setPaymentTerm(int paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    public String getProductCode() {
        return this.productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProgramCode() {
        return this.programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public String getTermModeCode() {
        return this.termModeCode;
    }

    public void setTermModeCode(String termModeCode) {
        this.termModeCode = termModeCode;
    }

   /* public Set<AcqMerchantInstallmentEntity> getAcqMerInstallments() {
        return acqMerInstallments;
    }

    public void setAcqMerInstallments(Set<AcqMerchantInstallmentEntity> acqMerInstallments) {
        this.acqMerInstallments = acqMerInstallments;
    }*/

    

}