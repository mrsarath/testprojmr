package com.nets.sg.npx.core.service.mss.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.core.dao.mss.SyncHqDao;
import com.nets.sg.npx.core.persistence.entity.mss.SyncHqEntity;
import com.nets.sg.npx.core.service.mss.SyncHqService;

@Service
public class SyncHqServiceImpl implements SyncHqService {

    @Autowired
    private SyncHqDao syncHqDao;

    @Override
    public SyncHqEntity save(SyncHqEntity record) {

        return syncHqDao.save(record);

    }

    @Override
    public List<SyncHqEntity> getRecordsByStatus(byte status) {        
        return syncHqDao.getRecordsByStatus(status);
    }

    @Override
    public SyncHqEntity update(SyncHqEntity record) {
        return syncHqDao.saveOrUpdate(record);
    }
}
