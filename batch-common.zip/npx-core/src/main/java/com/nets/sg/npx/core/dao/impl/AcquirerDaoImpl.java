package com.nets.sg.npx.core.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.nets.sg.npx.core.dao.AcquirerDao;
import com.nets.sg.npx.core.persistence.entity.AcquirerEntity;

@Repository
public class AcquirerDaoImpl extends GenericDaoImpl<AcquirerEntity, Long> implements AcquirerDao {

    
    @Override
    public AcquirerEntity getAcquirerByName(String name) {
        DetachedCriteria criteria = DetachedCriteria.forClass(AcquirerEntity.class, "acquirer");
        criteria.add(Restrictions.eq("name", name));
        List<AcquirerEntity> acquirers = findByCriteria(criteria);
        AcquirerEntity acquirer = null;
        
        if (acquirers.size() > 0) {
            acquirer = acquirers.get(0);
        }
        return acquirer;

    }

}
