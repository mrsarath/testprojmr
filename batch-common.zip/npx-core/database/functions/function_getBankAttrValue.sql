/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for pwap_core
USE `pwap_core`;


-- Dumping structure for function pwap_core.getBankAttrValue
DROP FUNCTION IF EXISTS `getBankAttrValue`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` FUNCTION `getBankAttrValue`(`config_attr_name` VARCHAR(50), `bankId` INT) RETURNS varchar(12) CHARSET utf8
    DETERMINISTIC
BEGIN
DECLARE configAttrVal VARCHAR(100) DEFAULT NULL;
select ta13.cfgAttrValue 
from ta13_bank_cfg_attr ta13   
where ta13.cfgAttrName = config_attr_name 
and ta13.BANK_ID = bankId 
order by ta13.cfgAttrId desc LIMIT 1
INTO configAttrVal;
RETURN (configAttrVal);
END//
DELIMITER ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
