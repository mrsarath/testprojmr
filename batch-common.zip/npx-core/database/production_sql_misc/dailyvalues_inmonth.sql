SELECT DISTINCT MERCHANT_TIER, DAY, SUM(DAYTXNVALUE)  AS 'DAYTXNVALUE' , SUM(DAYTXNCOUNT) AS 'DAYTXNCOUNT' 
FROM (
     SELECT case when m.NETS_MERCHANT_TYPE = '1' then 'Master Merchant' else 'Terminal Riding'  end AS 'MERCHANT_TIER',
             DATE(b.STATUS_DATE) AS DAY,
             SUM(IFNULL(b.TRAN_AMOUNT,0)) AS 'DAYTXNVALUE', 
             SUM(IFNULL(b.TRAN_COUNT,0)) AS 'DAYTXNCOUNT'
     FROM  tm01_merchant m left outer join ttr06_online_bank_batch b
                           on b.MERCHANT_ID = m.MERCHANT_ID
                           where ( b.STATUS IN ('2', '7') or b.STATUS IS NULL )
                           AND ( b.STATUS_DATE >= '2015-07-01 00:00:00' or b.STATUS_DATE IS NULL )
                           AND ( b.STATUS_DATE <= '2015-07-31 23:59:59' or b.STATUS_DATE IS NULL )
                           GROUP BY m.NETS_MERCHANT_TYPE, DAY ) a
GROUP BY a.MERCHANT_TIER, DAY
HAVING DAY IS NOT NULL
ORDER BY a.MERCHANT_TIER, DAY 
INTO OUTFILE '/opt/batch/daily_count_output.txt';