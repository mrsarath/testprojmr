-- UAT value : 7375
insert into ta13_bank_cfg_attr 
(cfgAttrName,cfgAttrType,cfgAttrValue,CREATED_BY,CREATION_TIME,BANK_ID)
values ('ORG_BANK_CODE',1,'7375',1,SYSDATE(),(select BANK_ID from ta06_bank where BANK_NAME = ?));
-- UAT value : 351
insert into ta13_bank_cfg_attr 
(cfgAttrName,cfgAttrType,cfgAttrValue,CREATED_BY,CREATION_TIME,BANK_ID)
values ('ORG_BRANCH_CODE',1,'351',1,SYSDATE(),(select BANK_ID from ta06_bank where BANK_NAME = ?));

-- UAT value : 03513022083
insert into ta13_bank_cfg_attr 
(cfgAttrName,cfgAttrType,cfgAttrValue,CREATED_BY,CREATION_TIME,BANK_ID)
values ('ORG_ACCOUNT_NO',1,?,1,SYSDATE(),(select BANK_ID from ta06_bank where BANK_NAME = ?));

-- UAT value : NETS
insert into ta13_bank_cfg_attr 
(cfgAttrName,cfgAttrType,cfgAttrValue,CREATED_BY,CREATION_TIME,BANK_ID)
values ('ORG_ACCOUNT_NAME',1,?,1,SYSDATE(),(select BANK_ID from ta06_bank where BANK_NAME = ?));

