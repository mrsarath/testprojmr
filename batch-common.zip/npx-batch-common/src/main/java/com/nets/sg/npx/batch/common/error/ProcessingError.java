package com.nets.sg.npx.batch.common.error;

import java.io.Serializable;

public class ProcessingError implements Serializable {

    public ProcessingError(String message) {
        this.message = message;
    }

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
