package com.nets.sg.npx.batch.common.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.batch.common.error.ProcessingError;
import com.nets.sg.npx.batch.common.service.BatchEmailService;
import com.nets.sg.npx.core.model.email.EmailAttachment;
import com.nets.sg.npx.core.service.EmailService;

@Service
public class BatchEmailServiceImpl implements BatchEmailService {

    private static final Logger logger = Logger.getLogger(BatchEmailServiceImpl.class);

    @Value("${batch.email.error.send.from}")
    private String errorEmailFrom;

    @Value("${batch.email.error.send.to}")
    private String errorEmailTo;

    @Value("${batch.email.error.subject}")
    private String errorEmailSubject;

    @Value("${batch.email.error.template}")
    private String errorEmailTemplate;

    @Autowired
    private EmailService emailService;

    @Override
    public boolean sendError(List<ProcessingError> errors) {
        String content = "";
        for (ProcessingError error : errors) {
            content = content + error.getMessage();
        }
        return sendError(content);
    }

    @Override
    public boolean sendError(String message) {
        boolean sent = true;
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("errors", message);
            emailService.sendMail(errorEmailFrom, errorEmailTo, errorEmailSubject, errorEmailTemplate, params);
        } catch (Exception e) {
            sent = false;
            logger.error(e.getMessage(), e);
        }
        return sent;
    }

    @Override
    public boolean send(String from, String subject, String to, String message, String template) {
        boolean sent = true;
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("message", message);
            emailService.sendMail(from, to, subject, template, params);
        } catch (Exception e) {
            sent = false;
            logger.error(e.getMessage(), e);
        }
        return sent;
    }

    @Override
    public boolean sendWithAttachment(String from, String subject, String to, String message, String template, List<EmailAttachment> attachments) {
        boolean sent = true;
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("message", message);
            emailService.sendMailWithAttachement(from, to, subject, template, params, attachments);
        } catch (Exception e) {
            sent = false;
            logger.error(e.getMessage(), e);
        }
        return sent;
    }

}
