package com.nets.sg.npx.batch.common.service;

import java.util.List;

import com.nets.sg.npx.batch.common.error.ProcessingError;
import com.nets.sg.npx.core.model.email.EmailAttachment;

public interface BatchEmailService {

    boolean sendError(List<ProcessingError> errors);

    boolean sendError(String message);

    boolean send(String from, String subject, String to, String message, String template);

    boolean sendWithAttachment(String from, String subject, String to, String message, String template, List<EmailAttachment> attachments);
}
