package com.nets.sg.npx.batch.common.exception;

import com.nets.sg.npx.core.exception.SystemException;

public class BatchException extends SystemException {

    public BatchException() {
        super();
    }

    public BatchException(String message) {
        super(message);
    }

    public BatchException(Throwable cause) {
        super(cause);
    }

    public BatchException(String message, Throwable cause) {
        super(message, cause);
    }
}
