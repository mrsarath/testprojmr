package com.nets.sg.npx.batch.common.util;

import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleWriterExporterOutput;

import org.springframework.stereotype.Component;

@Component
public class BatchJasperUtil {

    public void generateReportPDF(JasperReport report, Map<String, Object> param, JRBeanCollectionDataSource ds, String destFileName) throws JRException {
        JasperPrint print = JasperFillManager.fillReport(report, param, ds);
        JasperExportManager.exportReportToPdfFile(print, destFileName);
    }

    public void generateReportCSV(JasperReport report, Map<String, Object> param, JRBeanCollectionDataSource ds, String destFileName) throws JRException {
        JasperPrint print = JasperFillManager.fillReport(report, param, ds);
        JRCsvExporter csvExporter = new JRCsvExporter();
        csvExporter.setExporterInput(new SimpleExporterInput(print));
        csvExporter.setExporterOutput(new SimpleWriterExporterOutput(destFileName));
        csvExporter.exportReport();
    }

    public JasperReport getCompiledFile(String japerTemplate) throws JRException {
        return (JasperReport) JRLoader.loadObjectFromFile(japerTemplate);
    }

}
