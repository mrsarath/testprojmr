
1. HOW to ?

HOW to build the batch job ?
mvn clean install -DskipTests=true

HOW to launch the batch job ?
nohup java -jar npx-batch-uob-${version}.jar >/dev/null 2>&1 &

2. UAT checklist

2.1 tm02_merchant_cfg.INVOICE_MER_BANK_CODE
2.2 tm02_merchant_cfg.INVOICE_MER_BRANCH_CODE
2.3 tm02_merchant_cfg.INVOICE_MER_SAVING_ACCT_NO
2.4 ta13_bank_cfg_attr contains ORG_BANK_CODE,ORG_BRANCH_CODE,ORG_ACCOUNT_NO,ORG_ACCOUNT_NAME



