#!/bin/bash
#shell script to stop batch jobs for UOB
kill -9 $(cat run.pid)


