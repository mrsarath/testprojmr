#!/bin/bash
#shell script to launch batch jobs for UOB

${BATCH_ENCRYPTION_PASSWORD?"BATCH_ENCRYPTION_PASSWORD is not defined."}

nohup $JAVA_HOME/bin/java -jar npx-batch-uob.jar > /dev/null 2>&1 & echo $! > run.pid

echo "Please refer to npx-batch-uob.debug.log and npx-batch-uob.error.log for details."