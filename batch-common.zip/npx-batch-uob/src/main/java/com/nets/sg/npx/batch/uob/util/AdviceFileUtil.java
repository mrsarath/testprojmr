package com.nets.sg.npx.batch.uob.util;

import static com.nets.sg.npx.batch.uob.util.BatchConsts.UOB_SERVICE_TYPE_EXPRESS;
import static com.nets.sg.npx.batch.uob.util.BatchConsts.UOB_SERVICE_TYPE_NORMAL;
import static com.nets.sg.npx.core.util.CommonConsts.DATETIME_FORMAT_CCYYMMDD;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.nets.sg.npx.batch.common.exception.BatchException;
import com.nets.sg.npx.batch.uob.file.model.DataField;
import com.nets.sg.npx.batch.uob.file.model.PaymentAdviceRecord;
import com.nets.sg.npx.batch.uob.file.model.ResponseDetailRecord;
import com.nets.sg.npx.batch.uob.file.model.ResponseFile;
import com.nets.sg.npx.batch.uob.file.model.ResponseFileHeader;
import com.nets.sg.npx.batch.uob.file.model.ResponseFileTrailer;
import com.nets.sg.npx.batch.uob.file.model.SubmissionDetailRecord;
import com.nets.sg.npx.batch.uob.file.model.SubmissionFile;
import com.nets.sg.npx.batch.uob.file.model.SubmissionFileControlHeader;
import com.nets.sg.npx.batch.uob.file.model.SubmissionFileHeader;
import com.nets.sg.npx.batch.uob.file.model.SubmissionFileTrailer;
import com.nets.sg.npx.core.persistence.entity.BankCfgAttrEntity;
import com.nets.sg.npx.core.persistence.entity.BankEntity;
import com.nets.sg.npx.core.persistence.entity.MerchantEntity;
import com.nets.sg.npx.core.persistence.entity.TransactionEntity;
import com.nets.sg.npx.core.util.CommonConsts;
import com.nets.sg.npx.core.util.TransactionUtil;

@Component
public class AdviceFileUtil {

    private static final Logger logger = Logger.getLogger(AdviceFileUtil.class);

    @Value("${batch.ibg.advice.company.identity}")
    private String companyIdentity;

    @Value("${batch.ibg.advice.company.identity.bib}")
    private String bibCompanyIdentity;

    @Value("${batch.sftp.local.dir.generated}")
    private String plainFilePath;

    @Value("${batch.sg.public.holiday}")
    private String holiday;

    @Autowired
    private TransactionUtil tranUtil;

    private String getContent(DataField data) {
        String content = "";
        if (data.getType().equals(DataField.TYPE_ALPHABETIC)) {
            content = StringUtils.rightPad(data.getValue(), data.getLength(), ' ');
        } else if (data.getType().equals(DataField.TYPE_NUMERIC)) {
            content = StringUtils.leftPad(data.getValue(), data.getLength(), '0');
        }
        return content;
    }

    public SubmissionFileControlHeader getFileControlHeader(SubmissionFile file, DateTime now, String sequence) {

        SubmissionFileControlHeader control = new SubmissionFileControlHeader();
        control.getRecordType().setValue(CommonConsts.RECORD_TYPE_CONTROL);
        control.getFileName().setValue(
                "UIEI" + StringUtils.leftPad(String.valueOf(now.getDayOfMonth()), 2, '0') + StringUtils.leftPad(String.valueOf(now.getMonthOfYear()), 2, '0')
                        + sequence);
        control.getFileCreationDate().setValue(CommonConsts.DATETIME_FORMAT_CCYYMMDD.print(now));
        control.getFileCreationTime().setValue(CommonConsts.DATETIME_FORMAT_HHMMSS.print(now));
        control.getCompanyId().setValue(companyIdentity);
        control.getCheckSum().setValue(""); // TODO check sum for control
        control.getBibCompanyId().setValue(bibCompanyIdentity);
        logger.debug("file control generated : " + control);
        file.setControl(control);
        return control;

    }

    public SubmissionFileHeader getBatchFileHeader(SubmissionFile file, String serviceType, DateTime now, String batchNum, BankEntity bank)
            throws BatchException {

        SubmissionFileHeader header = new SubmissionFileHeader();
        header.getRecordType().setValue(CommonConsts.RECORD_TYPE_HEADER);
        header.getServiceType().setValue(serviceType);

        for (BankCfgAttrEntity attr : bank.getBankCfgAttr()) {
            if (CommonConsts.BANK_CFG_ATTR_NAME_ORG_BANK_CODE.equals(attr.getCfgAttrName())) {
                header.getOriginatingBankCode().setValue(attr.getCfgAttrValue());
                // 7375
            } else if (CommonConsts.BANK_CFG_ATTR_NAME_ORG_BRANCH_CODE.equals(attr.getCfgAttrName())) {
                header.getOriginatingBranchCode().setValue(attr.getCfgAttrValue());
                // 351
            } else if (CommonConsts.BANK_CFG_ATTR_NAME_ORG_ACCOUNT_NO.equals(attr.getCfgAttrName())) {
                header.getOriginatingAccountNo().setValue(attr.getCfgAttrValue());
                // 03513022083
            } else if (CommonConsts.BANK_CFG_ATTR_NAME_ORG_ACCOUNT_NAME.equals(attr.getCfgAttrName())) {
                header.getOriginatingAccountName().setValue(attr.getCfgAttrValue());
            }
        }

        header.getCreationDate().setValue(DATETIME_FORMAT_CCYYMMDD.print(now));

        header.getValueDate().setValue(getValueDate(DateTime.now(), serviceType, true));
        header.getReference().setValue("");
        header.getFilterOne().setValue("");
        header.getBatchNo().setValue(batchNum);
        header.getPaymentAdviceHeaderLineOne().setValue(""); // TODO
                                                             // "NPX merchant settlement"
        header.getPaymentAdviceHeaderLineTwo().setValue(""); // TODO
        header.getFilterTwo().setValue("");
        logger.debug("file header generated : " + header);

        if (!validate(header, bank)) {
            throw new BatchException("invalid detail record , please check batch error log for details.");
        }
        file.setHeader(header);
        return header;
    }

    private String getValueDate(DateTime now, String serviceType, boolean start) {
        logger.debug("now [" + now + "] , service type [" + serviceType + "] start[" + start + "]");
        String valueDate = "";

        DateTime tomorrow = null;
        if (start) {
            if (UOB_SERVICE_TYPE_EXPRESS.equals(serviceType)) {
                tomorrow = now.plusDays(1);
            } else {
                if (now.getDayOfWeek() == DateTimeConstants.SATURDAY) {
                    tomorrow = now.plusDays(3);
                } else {
                    tomorrow = now.plusDays(2);
                }
            }
        } else {
            tomorrow = now.plusDays(1);
        }
        logger.debug("tomorrow [" + tomorrow + "]");
        if (holiday.contains(DATETIME_FORMAT_CCYYMMDD.print(tomorrow))) {
            valueDate = getValueDate(tomorrow, serviceType, false);
        } else if (UOB_SERVICE_TYPE_NORMAL.equals(serviceType)
                && (tomorrow.getDayOfWeek() == DateTimeConstants.SATURDAY || tomorrow.getDayOfWeek() == DateTimeConstants.SUNDAY)) {
            valueDate = getValueDate(tomorrow, serviceType, false);
        } else if (UOB_SERVICE_TYPE_EXPRESS.equals(serviceType) && tomorrow.getDayOfWeek() == DateTimeConstants.SUNDAY) {
            valueDate = getValueDate(tomorrow, serviceType, false);
        } else {
            valueDate = DATETIME_FORMAT_CCYYMMDD.print(tomorrow);
        }
        logger.debug("valueDate [" + valueDate + "]");
        return valueDate;
    }

    public List<SubmissionDetailRecord> getBatchDetailRecords(SubmissionFile file, HashMap<MerchantEntity, List<TransactionEntity>> merchantTransactions,
            String start, String end) throws BatchException {
        DateTime now = null;
        List<SubmissionDetailRecord> records = new ArrayList<>();
        HashMap<String, PaymentAdviceRecord> advices = new HashMap<>();
        for (Map.Entry<MerchantEntity, List<TransactionEntity>> entry : merchantTransactions.entrySet()) {
            if (entry.getValue().size() != 0) {
                MerchantEntity merchant = entry.getKey();
                logger.info("merhcant with id [" + merchant.getOid() + "] has no. of [" + entry.getValue().size() + "] for funding.");
                SubmissionDetailRecord detail = new SubmissionDetailRecord();
                PaymentAdviceRecord advice = new PaymentAdviceRecord();
                records.add(detail);

                detail.getRecordType().setValue(CommonConsts.RECORD_TYPE_SUMMARY);
                detail.getReceivingBankCode().setValue(merchant.getConfig().getBankCode());
                detail.getReceivingBranchCode().setValue(merchant.getConfig().getBranchCode());
                detail.getReceivingAccountNo().setValue(StringUtils.substring(merchant.getConfig().getAccNo(), 0, 11));
                detail.getReceivingAccountName().setValue(StringUtils.substring(merchant.getConfig().getAccName(), 0, 20));
                detail.getTransactionCode().setValue(CommonConsts.BATCH_TRAN_CODE_BILL_CREDIT);

                BigDecimal total = new BigDecimal(0);
                BigDecimal refund = new BigDecimal(0);
                BigDecimal saleTotal = new BigDecimal(0);
                for (TransactionEntity tran : entry.getValue()) {
                    if (CommonConsts.TRAN_TYPE_REFUND.equals(tran.getType())) {
                        refund = refund.add(tran.getAmount().setScale(2));
                        logger.debug("transaction refund [" + refund + "].");
                    } else {
                        BigDecimal amount = tran.getAmount().setScale(2);
                        BigDecimal mdr = tranUtil.getMDR(tran);
                        BigDecimal gst = tranUtil.getGST(tran, mdr);
                        BigDecimal payable = amount.subtract(mdr).subtract(gst);

                        payable = payable.setScale(2, BigDecimal.ROUND_HALF_UP);
                        gst = gst.setScale(2, BigDecimal.ROUND_HALF_UP);
                        mdr = amount.subtract(payable).subtract(gst);
                        total = total.add(payable);
                        saleTotal = saleTotal.add(amount);
                        logger.debug("transaction amount [" + amount + "], mdr[" + mdr + "], gst[" + gst + "], due merchant[" + payable + "], total[" + total
                                + "].");
                    }

                }
                BigDecimal net = total.subtract(refund);
                detail.getAmount().setValue(net.multiply(new BigDecimal(100)).setScale(0).toPlainString());
                logger.debug("total sale amount in dollars [" + saleTotal + "], total payable amount [" + detail.getAmount().getValue()
                        + "] for merchant customer code [" + merchant.getNetsCustCode() + "] .");
                detail.getParticulars().setValue(""); // TODO
                now = new DateTime();
                String reference = CommonConsts.DATETIME_FORMAT_YYMMDDHHMMSSSSS.print(now);
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    logger.error(e.getMessage(), e);
                }
                detail.getReference().setValue(reference.substring(reference.length() - 12));
                detail.getPrintPaymentAdviceIndicator().setValue(CommonConsts.PRINT_PAYMENT_ADVICE_INDICATOR_YES);
                detail.getDeliveryMode().setValue(CommonConsts.DELIVERY_MODE_EMAIL);
                detail.getAdviceFormat().setValue("1");
                detail.getBeneficiaryId().setValue("");
                detail.getBeneficiaryNameLineOne().setValue("");
                detail.getBeneficiaryNameLineTwo().setValue("");
                detail.getBeneficiaryAddressLineOne().setValue("");
                detail.getBeneficiaryAddressLineTwo().setValue("");
                detail.getBeneficiaryAddressLineThree().setValue("");
                detail.getBeneficiaryAddressLineFour().setValue("");
                detail.getBeneficiaryCity().setValue("");
                detail.getBeneficiaryCountryCode().setValue("");
                detail.getBeneficiaryPostalCode().setValue("");
                detail.getEmailAddressOfBeneficiary().setValue(merchant.getEmail());
                // detail.getEmailAddressOfBeneficiary().setValue("Lee.YingChai@UOBgroup.com");
                detail.getFacsimileNumOfBeneficiary().setValue("");
                detail.getPaymentCurrency().setValue("SGD");
                detail.getPayerNameLineOne().setValue(""); // TODO
                detail.getPayerNameLineTwo().setValue(""); // TODO
                detail.getCustomerReference().setValue(""); // TODO
                detail.setMerchant(merchant);

                advice.getRecordType().setValue("4");
                advice.getSpacingLines().setValue("10");
                advice.getPaymentAdviceDetails().setValue(
                        "settlement from " + start + " to " + end + " for customer code "
                                + (StringUtils.isBlank(merchant.getNetsCustCode()) ? " " : merchant.getNetsCustCode()));
                advice.getFilter().setValue(" ");
                advices.put(detail.getReference().getValue(), advice);
                if (!validate(detail, merchant)) {
                    throw new BatchException("invalid detail record , please check batch error log for details.");
                }
            } else {
                logger.error("merhcant with id [" + entry.getKey().getOid() + "] has no. of [" + entry.getValue().size() + "] for funding.");
            }
        }
        file.setAdvices(advices);
        file.setDetails(records);
        return records;
    }

    private boolean validate(SubmissionFileHeader header, BankEntity bank) {
        boolean valid = false;
        if (StringUtils.isBlank(header.getOriginatingBankCode().getValue())) {
            logger.error("originating bank code is blank for bank [" + bank.getName() + "].");
        } else if (StringUtils.isBlank(header.getOriginatingBranchCode().getValue())) {
            logger.error("originating branch code is blank for bank [" + bank.getName() + "].");
        } else if (StringUtils.isBlank(header.getOriginatingAccountNo().getValue())) {
            logger.error("originating account no is blank for bank [" + bank.getName() + "].");
        } else if (StringUtils.isBlank(header.getOriginatingAccountName().getValue())) {
            logger.error("originating account name is blank for bank [" + bank.getName() + "].");
        } else {
            valid = true;
        }
        return valid;
    }

    private boolean validate(SubmissionDetailRecord detail, MerchantEntity merchant) {
        boolean valid = false;

        if (StringUtils.isBlank(detail.getReceivingBankCode().getValue())) {
            logger.error("receving bank code is blank for merchant [" + merchant.getOid() + "].");
        } else if (StringUtils.isBlank(detail.getReceivingBranchCode().getValue())) {
            logger.error("receving branch code is blank for merchant [" + merchant.getOid() + "].");
        } else if (StringUtils.isBlank(detail.getReceivingAccountNo().getValue())) {
            logger.error("receving account no is blank for merchant [" + merchant.getOid() + "].");
        } else if (StringUtils.isBlank(detail.getReceivingAccountName().getValue())) {
            logger.error("receving account name is blank for merchant [" + merchant.getOid() + "].");
        } else if (StringUtils.isBlank(detail.getTransactionCode().getValue())) {
            logger.error("transaction code is blank for reord [" + detail + "].");
        } else if (StringUtils.isBlank(detail.getAmount().getValue())) {
            logger.error("amount is blank for reord [" + detail + "].");
        } else if (StringUtils.isBlank(detail.getPrintPaymentAdviceIndicator().getValue())) {
            logger.error("print payment advice indicator is blank for reord [" + detail + "].");
        } else if (StringUtils.isBlank(detail.getDeliveryMode().getValue())) {
            logger.error("delivery mode is blank for reord [" + detail + "].");
        } else if (StringUtils.isBlank(detail.getAdviceFormat().getValue())) {
            logger.error("advice format is blank for reord [" + detail + "].");
        } else {
            valid = true;
        }

        return valid;
    }

    public SubmissionFileTrailer getBatchFileTrailer(SubmissionFile file) {
        SubmissionFileTrailer trailer = new SubmissionFileTrailer();
        trailer.getRecordType().setValue(CommonConsts.RECORD_TYPE_TRAILER);
        BigDecimal total = new BigDecimal(0);
        Long count = 0L;
        for (SubmissionDetailRecord record : file.getDetails()) {
            if (CommonConsts.RECORD_TYPE_SUMMARY.equals(record.getRecordType().getValue())) {
                total = total.add(new BigDecimal(record.getAmount().getValue()));
                count += 1;
            }
        }
        trailer.getTotalCreditAmount().setValue(total.toBigInteger().toString());
        trailer.getTotalCreditCount().setValue(String.valueOf(count));
        file.setTrailer(trailer);
        return trailer;
    }

    public void generateFileHash(SubmissionFile file) {

        SubmissionFileHeader header = file.getHeader();

        String bank = header.getOriginatingBankCode().getValue(); // B1B2B3B4
        String branch = header.getOriginatingBranchCode().getValue(); // R1R3R3
        String account = header.getOriginatingAccountNo().getValue(); // A1A2A3A4A5A6A7A8A9A10A11
        logger.debug("record type 2 bank [" + bank + "]branch [" + branch + "], account[" + account + "].");
        Integer sumOne = 0;
        Integer sumTwo = 0;
        Integer sumThree = 0;
        Integer sumFour = 0;
        String amount = "";
        if (StringUtils.isNotBlank(bank) && StringUtils.isNotBlank(branch) && StringUtils.isNotBlank(account)) {
            if (bank.length() < 4 || branch.length() < 3 || account.length() < 11) {
                logger.error("failed to generate checksum with bank code[" + bank + "], branch code[" + branch + "], account no[" + account + "].");
            } else {
                sumOne = calculate(bank, 0, 2, 2) + calculate(branch, 0, 2, 3) + calculate(account, 0, 2, 4) + calculate(account, 4, 6, 5)
                        + calculate(account, 8, 10, 6);
                sumTwo = calculate(bank, 2, 4, 9) + calculate(branch, 2, 3, 8) + calculate(account, 2, 4, 7) + calculate(account, 6, 8, 6)
                        + calculate(account, 10, 11, 5);
                sumThree = sumOne * sumTwo;
                sumFour = sumThree;
                logger.debug("record type 1 sumOne [" + sumOne + "]sumTwo [" + sumTwo + "], sumThree[" + sumThree + "], sumFour[" + sumFour + "].");
                String tranCode = "";
                for (SubmissionDetailRecord detail : file.getDetails()) {
                    bank = detail.getReceivingBankCode().getValue(); // B1B2B3B4
                    branch = detail.getReceivingBranchCode().getValue(); // R1R2R3
                    account = StringUtils.rightPad(detail.getReceivingAccountNo().getValue(), 11, '0'); // A1A2A3A4A5A6A7A8A9A10A11
                    tranCode = detail.getTransactionCode().getValue(); // T1T2
                    amount = StringUtils.leftPad(detail.getAmount().getValue(), 11, '0');// M1M2M3M4M5M6M7M8M9M10M11
                    logger.debug("record type 2 bank [" + bank + "]branch [" + branch + "], account[" + account + "] ,tranCode[" + tranCode + "] , amount["
                            + amount + "].");
                    sumOne = calculate(bank, 0, 2, 1) + calculate(branch, 0, 2, 2) + calculate(account, 0, 2, 3) + calculate(account, 4, 6, 4)
                            + calculate(account, 8, 10, 5) + calculate(tranCode, 0, 1, 6) + calculate(amount, 0, 3, 7) + calculate(amount, 4, 6, 8)
                            + calculate(amount, 8, 10, 9);
                    sumTwo = calculate(bank, 2, 4, 9) + calculate(branch, 2, 3, 8) + calculate(account, 2, 4, 7) + calculate(account, 6, 8, 6)
                            + calculate(account, 10, 11, 5) + calculate(tranCode, 1, 2, 4) + calculate(amount, 2, 4, 3) + calculate(amount, 6, 8, 2)
                            + calculate(amount, 10, 11, 1);
                    sumThree = sumOne * sumTwo;
                    sumFour = sumThree + sumFour;

                }

            }
        } else {
            logger.error("failed to generate checksum with bank code[" + bank + "], branch code[" + branch + "], account no[" + account + "].");
        }

        file.getControl().getCheckSum().setValue(String.valueOf(sumFour));

    }

    private Integer calculate(String value, Integer begin, Integer end, Integer check) {
        Integer sum = Integer.valueOf(StringUtils.isBlank(value) ? "0" : value.substring(begin, end)) * check;
        logger.debug("sum[" + sum + "] calculated with value[" + Integer.valueOf(StringUtils.isBlank(value) ? "0" : value.substring(begin, end)) + "],check["
                + check + "].");
        return sum;
    }

    public File writeContentToLocalFile(SubmissionFile file) throws BatchException {

        File plain = new File(plainFilePath + file.getControl().getFileName());

        try {

            plain.createNewFile();

            String record = "";

            BufferedWriter writer = new BufferedWriter(new FileWriter(plain));

            record += getContent(file.getControl().getRecordType());
            record += getContent(file.getControl().getFileName());
            record += getContent(file.getControl().getFileCreationDate());
            record += getContent(file.getControl().getFileCreationTime());
            record += getContent(file.getControl().getCompanyId());
            record += getContent(file.getControl().getCheckSum());
            record += getContent(file.getControl().getBibCompanyId());
            record += getContent(file.getControl().getFilter());
            writer.write(record);
            writer.newLine();

            record = "";
            record += getContent(file.getHeader().getRecordType());
            record += getContent(file.getHeader().getServiceType());
            record += getContent(file.getHeader().getOriginatingBankCode());
            record += getContent(file.getHeader().getOriginatingBranchCode());
            record += getContent(file.getHeader().getOriginatingAccountNo());
            record += getContent(file.getHeader().getOriginatingAccountName());
            record += getContent(file.getHeader().getCreationDate());
            record += getContent(file.getHeader().getValueDate());
            record += getContent(file.getHeader().getReference());
            record += getContent(file.getHeader().getFilterOne());
            record += getContent(file.getHeader().getBatchNo());
            record += getContent(file.getHeader().getPaymentAdviceHeaderLineOne());
            record += getContent(file.getHeader().getPaymentAdviceHeaderLineTwo());
            record += getContent(file.getHeader().getFilterTwo());
            writer.write(record);
            writer.newLine();

            for (SubmissionDetailRecord detail : file.getDetails()) {
                record = "";
                record += getContent(detail.getRecordType());
                record += getContent(detail.getReceivingBankCode());
                record += getContent(detail.getReceivingBranchCode());
                record += getContent(detail.getReceivingAccountNo());
                record += getContent(detail.getReceivingAccountName());
                record += getContent(detail.getTransactionCode());
                record += getContent(detail.getAmount());
                record += getContent(detail.getParticulars());
                record += getContent(detail.getReference());
                record += getContent(detail.getFilterOne());
                record += getContent(detail.getPrintPaymentAdviceIndicator());
                record += getContent(detail.getDeliveryMode());
                record += getContent(detail.getAdviceFormat());
                record += getContent(detail.getBeneficiaryId());
                record += getContent(detail.getBeneficiaryNameLineOne());
                record += getContent(detail.getBeneficiaryNameLineTwo());
                record += getContent(detail.getBeneficiaryAddressLineOne());
                record += getContent(detail.getBeneficiaryAddressLineTwo());
                record += getContent(detail.getBeneficiaryAddressLineThree());
                record += getContent(detail.getBeneficiaryAddressLineFour());
                record += getContent(detail.getBeneficiaryCity());
                record += getContent(detail.getBeneficiaryCountryCode());
                record += getContent(detail.getBeneficiaryPostalCode());
                record += getContent(detail.getEmailAddressOfBeneficiary());
                record += getContent(detail.getFacsimileNumOfBeneficiary());
                record += getContent(detail.getPaymentCurrency());
                record += getContent(detail.getPayerNameLineOne());
                record += getContent(detail.getPayerNameLineTwo());
                record += getContent(detail.getCustomerReference());
                record += getContent(detail.getFilterTwo());
                writer.write(record);
                writer.newLine();
                record = "";
                PaymentAdviceRecord advice = file.getAdvices().get(detail.getReference().getValue());

                record += getContent(advice.getRecordType());
                record += getContent(advice.getSpacingLines());
                record += getContent(advice.getPaymentAdviceDetails());
                record += getContent(advice.getFilter());
                writer.write(record);
                writer.newLine();
            }

            record = "";
            record += getContent(file.getTrailer().getRecordType());
            record += getContent(file.getTrailer().getTotalDebitAmount());
            record += getContent(file.getTrailer().getTotalCreditAmount());
            record += getContent(file.getTrailer().getTotalDebitCount());
            record += getContent(file.getTrailer().getTotalCreditCount());
            record += getContent(file.getTrailer().getFilter());
            writer.write(record);
            writer.newLine();

            writer.flush();
            writer.close();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new BatchException(e.getMessage());
        }

        return plain;
    }

    private String getValue(DataField field, String content) {
        return content.substring(field.getPosition() - 1, field.getPosition() - 1 + field.getLength());
    }

    private ResponseFileHeader getResponseHeader(String content) {
        ResponseFileHeader header = new ResponseFileHeader();
        header.getRecordType().setValue(CommonConsts.RECORD_TYPE_HEADER);
        header.getServiceType().setValue(getValue(header.getServiceType(), content));
        logger.debug("service type[" + header.getServiceType().getValue() + "].");
        header.getOriginatingBankCode().setValue(getValue(header.getOriginatingBankCode(), content));
        logger.debug("originating bank code[" + header.getOriginatingBankCode().getValue() + "].");
        header.getOriginatingBranchCode().setValue(getValue(header.getOriginatingBranchCode(), content));
        logger.debug("originating branch code[" + header.getOriginatingBranchCode().getValue() + "].");
        header.getOriginatingAccountNo().setValue(getValue(header.getOriginatingAccountNo(), content));
        logger.debug("originating account no[" + header.getOriginatingAccountNo().getValue() + "].");
        header.getOriginatingAccountName().setValue(getValue(header.getOriginatingAccountName(), content));
        logger.debug("originating account name[" + header.getOriginatingAccountName().getValue() + "].");
        header.getCreationDate().setValue(getValue(header.getCreationDate(), content));
        logger.debug("creation date[" + header.getCreationDate().getValue() + "].");
        header.getValueDate().setValue(getValue(header.getValueDate(), content));
        logger.debug("value date[" + header.getValueDate().getValue() + "].");
        header.getReference().setValue(getValue(header.getReference(), content));
        logger.debug("reference[" + header.getReference().getValue() + "].");
        header.getFilterOne().setValue(getValue(header.getFilterOne(), content));
        logger.debug("filter one[" + header.getFilterOne().getValue() + "].");
        header.getBatchNo().setValue(getValue(header.getBatchNo(), content));
        logger.debug("batch no [" + header.getBatchNo().getValue() + "].");
        header.getFilterTwo().setValue(getValue(header.getFilterTwo(), content));
        logger.debug("filter two [" + header.getFilterTwo().getValue() + "].");
        logger.debug("header added :" + content);
        return header;
    }

    private ResponseDetailRecord getResponseDetail(String content) {
        ResponseDetailRecord record = new ResponseDetailRecord();
        record.getRecordType().setValue(CommonConsts.RECORD_TYPE_SUMMARY);
        record.getReceivingBankCode().setValue(getValue(record.getReceivingBankCode(), content));
        logger.debug("receving bank code[" + record.getReceivingBankCode().getValue() + "]");
        record.getReceivingBranchCode().setValue(getValue(record.getReceivingBranchCode(), content));
        logger.debug("receving branch code[" + record.getReceivingBranchCode().getValue() + "]");
        record.getReceivingAccountNo().setValue(getValue(record.getReceivingAccountNo(), content));
        logger.debug("receving account no[" + record.getReceivingAccountNo().getValue() + "]");
        record.getReceivingAccountName().setValue(getValue(record.getReceivingAccountName(), content));
        logger.debug("receving account name[" + record.getReceivingAccountName().getValue() + "]");
        record.getTransactionCode().setValue(getValue(record.getTransactionCode(), content));
        logger.debug("transaction code[" + record.getTransactionCode().getValue() + "]");
        record.getAmount().setValue(getValue(record.getAmount(), content));
        logger.debug("amount[" + record.getAmount().getValue() + "]");
        record.getParticulars().setValue(getValue(record.getParticulars(), content));
        logger.debug("particulars[" + record.getParticulars().getValue() + "]");
        record.getReference().setValue(getValue(record.getReference(), content));
        logger.debug("reference[" + record.getReference().getValue() + "]");
        record.getClearFate().setValue(getValue(record.getClearFate(), content));
        logger.debug("clear fate[" + record.getClearFate() + "]");
        record.getRejectionCode().setValue(getValue(record.getRejectionCode(), content));
        logger.debug("rejection code[" + record.getRejectionCode().getValue() + "]");
        record.getFilterOne().setValue(getValue(record.getFilterOne(), content));
        logger.debug("filter one[" + record.getFilterOne().getValue() + "]");
        record.getBeneficiaryId().setValue(getValue(record.getBeneficiaryId(), content));
        logger.debug("beneficiary id[" + record.getBeneficiaryId().getValue() + "]");
        record.getBeneficiaryNameLineOne().setValue(getValue(record.getBeneficiaryNameLineOne(), content));
        logger.debug("beneficiary name line one[" + record.getBeneficiaryNameLineOne().getValue() + "]");
        record.getBeneficiaryNameLineTwo().setValue(getValue(record.getBeneficiaryNameLineTwo(), content));
        logger.debug("beneficiary name line tow[" + record.getBeneficiaryNameLineTwo().getValue() + "]");
        record.getCustomerReference().setValue(getValue(record.getCustomerReference(), content));
        logger.debug("customer reference[" + record.getCustomerReference().getValue() + "]");
        record.getPrintPaymentAdviceIndicator().setValue(getValue(record.getPrintPaymentAdviceIndicator(), content));
        logger.debug("print payment advice indicator[" + record.getPrintPaymentAdviceIndicator().getValue() + "]");
        record.getReasonOfNotPrinted().setValue(getValue(record.getReasonOfNotPrinted(), content));
        logger.debug("reason of not printed[" + record.getReasonOfNotPrinted().getValue() + "]");
        record.getFilterTwo().setValue(getValue(record.getFilterTwo(), content));
        logger.debug("filter two[" + record.getFilterTwo().getValue() + "]");
        logger.debug("detail added :" + content);
        return record;
    }

    private ResponseFileTrailer getResponseTrailer(String content) {
        ResponseFileTrailer trailer = new ResponseFileTrailer();
        trailer.getRecordType().setValue(CommonConsts.RECORD_TYPE_TRAILER);
        trailer.getTotalDebitAmount().setValue(getValue(trailer.getTotalDebitAmount(), content));
        logger.debug("get Total Debit Amount[" + trailer.getTotalDebitAmount().getValue() + "]");

        trailer.getTotalCreditAmount().setValue(getValue(trailer.getTotalCreditAmount(), content));
        logger.debug("get Total Credit Amount[" + trailer.getTotalCreditAmount().getValue() + "]");

        trailer.getTotalDebitCount().setValue(getValue(trailer.getTotalDebitCount(), content));
        logger.debug("get Total Debit Count[" + trailer.getTotalDebitCount().getValue() + "]");

        trailer.getTotalCreditCount().setValue(getValue(trailer.getTotalCreditCount(), content));
        logger.debug("get Total Credit Count[" + trailer.getTotalCreditCount().getValue() + "]");

        trailer.getRejectedDebitAmount().setValue(getValue(trailer.getRejectedDebitAmount(), content));
        logger.debug("get Rejected Debit Amount[" + trailer.getRejectedDebitAmount().getValue() + "]");

        trailer.getRejectedCreditAmount().setValue(getValue(trailer.getRejectedCreditAmount(), content));
        logger.debug("get Rejected Credit Amount[" + trailer.getRejectedCreditAmount().getValue() + "]");

        trailer.getRejectedDebitCount().setValue(getValue(trailer.getRejectedDebitCount(), content));
        logger.debug("get Rejected Debit Count[" + trailer.getRejectedDebitCount().getValue() + "]");

        trailer.getRejectedCreditCount().setValue(getValue(trailer.getRejectedCreditCount(), content));
        logger.debug("get Rejected Credit Count[" + trailer.getRejectedCreditCount().getValue() + "]");

        trailer.getFilter().setValue(getValue(trailer.getFilter(), content));
        logger.debug("ge tFilter[" + trailer.getFilter().getValue() + "]");

        logger.debug("trailer added :" + content);
        return trailer;
    }

    public ResponseFile getResponseFile(File file) {
        ResponseFile responseFile = new ResponseFile();
        responseFile.setFileName(file.getName());
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            String line = "";

            while ((line = br.readLine()) != null) {
                if (line.startsWith(CommonConsts.RECORD_TYPE_HEADER)) {
                    responseFile.setHeader(getResponseHeader(line));
                } else if (line.startsWith(CommonConsts.RECORD_TYPE_SUMMARY)) {
                    responseFile.getDetails().add(getResponseDetail(line));
                } else if (line.startsWith(CommonConsts.RECORD_TYPE_TRAILER)) {
                    responseFile.setTrailer(getResponseTrailer(line));
                }
            }
            br.close();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return responseFile;

    }
}
