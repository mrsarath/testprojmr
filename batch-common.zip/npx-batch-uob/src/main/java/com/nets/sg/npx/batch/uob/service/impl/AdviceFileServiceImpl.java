package com.nets.sg.npx.batch.uob.service.impl;

import static com.nets.sg.npx.core.util.CommonConsts.DATETIME_FORMAT_CCYY;
import static com.nets.sg.npx.core.util.CommonConsts.DATETIME_FORMAT_CCYYMMDD;
import static com.nets.sg.npx.core.util.CommonConsts.DATETIME_FORMAT_CCYYMMDDHHMMSS;
import static com.nets.sg.npx.core.util.CommonConsts.DATETIME_FORMAT_DD_MM_CCYY;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.keyvalue.DefaultKeyValue;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nets.sg.npx.batch.common.error.ProcessingError;
import com.nets.sg.npx.batch.common.exception.BatchException;
import com.nets.sg.npx.batch.common.service.BatchEmailService;
import com.nets.sg.npx.batch.uob.file.model.ResponseDetailRecord;
import com.nets.sg.npx.batch.uob.file.model.ResponseFile;
import com.nets.sg.npx.batch.uob.file.model.SubmissionDetailRecord;
import com.nets.sg.npx.batch.uob.file.model.SubmissionFile;
import com.nets.sg.npx.batch.uob.service.AdviceFileService;
import com.nets.sg.npx.batch.uob.service.FileTransferService;
import com.nets.sg.npx.batch.uob.util.AdviceFileUtil;
import com.nets.sg.npx.batch.uob.util.BatchConsts;
import com.nets.sg.npx.core.exception.SystemException;
import com.nets.sg.npx.core.persistence.entity.BankEntity;
import com.nets.sg.npx.core.persistence.entity.MerchantEntity;
import com.nets.sg.npx.core.persistence.entity.MerchantFundingEntity;
import com.nets.sg.npx.core.persistence.entity.MerchantFundingRecordEntity;
import com.nets.sg.npx.core.persistence.entity.MerchantFundingTransactionMappingEntity;
import com.nets.sg.npx.core.persistence.entity.TransactionEntity;
import com.nets.sg.npx.core.service.BankService;
import com.nets.sg.npx.core.service.MerchantFundingService;
import com.nets.sg.npx.core.service.TransactionService;
import com.nets.sg.npx.core.util.CommonConsts;
import com.nets.sg.npx.core.util.PropertyUtil;

@Service
public class AdviceFileServiceImpl implements AdviceFileService {

    private static final Logger logger = Logger.getLogger(AdviceFileServiceImpl.class);

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private BankService bankService;

    @Autowired
    private MerchantFundingService merchantFundingService;

    @Autowired
    private PropertyUtil propertyUtil;

    @Value("${batch.ibg.advice.acquirer.oid}")
    private String acquirer;

    @Value("${batch.ibg.advice.merchant.type}")
    private String merchantType;

    @Value("${batch.local.file.sequence}")
    private String sequence;

    @Value("${batch.uob.merchant.status.active}")
    private String activeMerchantStatus;

    @Value("${batch.sftp.local.dir.sent}")
    private String sentFilePath;

    @Value("${batch.sftp.local.dir.processed}")
    private String processedFilePath;

    @Value("${batch.sftp.local.dir.received}")
    private String receivedFilePath;

    @Value("${batch.sftp.local.dir.failed}")
    private String failedFilePath;

    @Value("${batch.config.bank.name}")
    private String bankName;

    @Value("${batch.email.general.template}")
    private String generalEmailTemplate;

    @Value("${batch.email.general.settlement.result.from}")
    private String emailFrom;

    @Value("${batch.email.general.settlement.result.send.to}")
    private String sentTo;

    @Value("${batch.email.general.subject}")
    private String emailSubject;

    private DateTime now;

    @Autowired
    private FileTransferService fileTransferService;

    @Autowired
    private BatchEmailService emailService;

    @Autowired
    private AdviceFileUtil fileUtil;

    private HashMap<MerchantEntity, List<TransactionEntity>> merchantTransactions = null;

    @Override
    public List<File> downloadResponseFiles(String serviceType) throws BatchException {
        DateTime now = new DateTime();
        String year = DATETIME_FORMAT_CCYY.print(now);
        File processedDir = new File(processedFilePath + "/" + year);
        if (!processedDir.exists()) {
            processedDir.mkdir();
        }
        File failedDir = new File(failedFilePath + "/" + year);
        if (!failedDir.exists()) {
            failedDir.mkdir();
        }
        return fileTransferService.download(receivedFilePath, serviceType);
    }

    private void processRejectionFile(File file) {
        String fileName = "UIEI" + file.getName().substring(4, 10);
        MerchantFundingEntity funding = merchantFundingService.getSubmittedByFileName(fileName);
        if (funding != null) {
            List<TransactionEntity> trans = new ArrayList<>();
            file.renameTo(new File(failedFilePath + "/" + DateTime.now().toString("yyyy") + "/" + file.getName()));
            funding.setStatus(CommonConsts.BATCH_STATUS_REJECTED);
            funding.setResponseDate(now.toString("yyyyMMdd"));
            for (MerchantFundingRecordEntity detail : funding.getRecords()) {
                detail.setStatus(CommonConsts.BATCH_STATUS_REJECTED);
                for (MerchantFundingTransactionMappingEntity mapping : detail.getMappings()) {
                    TransactionEntity tran = mapping.getTransaction();
                    tran.setPaymentStatus(CommonConsts.TRAN_PAYMENT_STATUS_REJECTED);
                    logger.info("transaction id [" + tran.getOid() + "]'s payment to merchant is rejected.");
                    trans.add(tran);
                }
            }
            merchantFundingService.save(funding);
            transactionService.saveAll(trans);
            logger.info("merchant funding id [" + funding.getOid() + "] rejected.");
        } else {
            logger.error("no funding found with file name [" + fileName + "].");
        }

    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = BatchException.class)
    public List<ProcessingError> processResponseFiles(List<File> files, String serviceType) throws BatchException {
        now = new DateTime();
        List<ProcessingError> errors = new ArrayList<>();
        List<TransactionEntity> trans = new ArrayList<>();
        if (org.springframework.util.CollectionUtils.isEmpty(files)) {
            String msg = "No response file is returned from UOB end for [" + serviceType + "].";
            errors.add(new ProcessingError(msg));
            logger.error(msg);
        } else {
            for (File file : files) {
                String status = "";
                String fileName = file.getName();
                MerchantFundingEntity merchantFunding = null;
                try {

                    if (file.getName().startsWith("UIBO")) {
                        logger.error("rejectioin file received [" + file.getName() + "]");
                        errors.add(new ProcessingError("rejectioin file received [" + file.getName() + "]"));
                        processRejectionFile(file);
                        emailService.send(emailFrom, emailSubject, sentTo, "Settlement rejected with file [" + fileName
                                + "], please contact production support", generalEmailTemplate);

                    } else if (file.getName().startsWith("UIEO")) {
                        ResponseFile responseFile = fileUtil.getResponseFile(file);

                        merchantFunding = merchantFundingService.getMerchantFundingByBatchNo(responseFile.getHeader().getBatchNo().getValue());
                        if (merchantFunding == null) {
                            errors.add(new ProcessingError("no batch found with [" + responseFile.getHeader().getBatchNo().getValue()
                                    + "], with reponse file [" + file.getName() + "]."));
                            logger.error(errors.get(errors.size() - 1));
                        } else {
                            status = fileName.length() > 10 ? fileName.substring(10, 11) : "";
                            logger.debug("status of reponse file is [" + status + "].");
                            if (CommonConsts.RESPONSE_FILE_STATUS_SUCCESSFUL.equals(status)) {

                                merchantFunding.setStatus(CommonConsts.BATCH_STATUS_SUCCESS);
                                merchantFunding.setSettledCreditAmount(merchantFunding.getTotalCreditAmount());
                                merchantFunding.setSettledCreditCount(merchantFunding.getTotalCreditCount());

                                for (ResponseDetailRecord record : responseFile.getDetails()) {

                                    for (MerchantFundingRecordEntity detail : merchantFunding.getRecords()) {

                                        if (detail.getTrace().endsWith(record.getReference().getValue())) {
                                            // detail match with response file
                                            if (CommonConsts.MERCHANT_FUNDING_CLEAR_FATE_OK.equals(record.getClearFate().getValue())) {
                                                detail.setStatus(CommonConsts.BATCH_STATUS_SUCCESS);
                                            } else {
                                                detail.setStatus(CommonConsts.BATCH_STATUS_REJECTED);
                                                detail.setRejectionCode(record.getRejectionCode().getValue());

                                                merchantFunding.setSettledCreditCount(String.valueOf(new Long(merchantFunding.getSettledCreditCount()) - 1));
                                                merchantFunding.setSettledCreditAmount(String.valueOf(new Long(merchantFunding.getSettledCreditAmount())
                                                        - new Long(record.getAmount().getValue())));
                                                merchantFunding.setStatus(CommonConsts.BATCH_STATUS_SUCCESS_WITH_REJECTION);

                                                logger.error("rejected amount in success file is [" + record.getAmount().getValue() + "].");
                                            }

                                            for (MerchantFundingTransactionMappingEntity mapping : detail.getMappings()) {
                                                if (CommonConsts.MERCHANT_FUNDING_CLEAR_FATE_OK.equals(record.getClearFate().getValue())) {
                                                    mapping.getTransaction().setPaymentStatus(CommonConsts.TRAN_PAYMENT_STATUS_APPROVED);
                                                } else {
                                                    mapping.getTransaction().setPaymentStatus(CommonConsts.TRAN_PAYMENT_STATUS_REJECTED);
                                                    logger.error("payment rejected for [" + record.getReference().getValue() + "] , with rejection code ["
                                                            + record.getRejectionCode() + "] for transaction [" + mapping.getTransaction().getOid() + "].");
                                                }
                                                trans.add(mapping.getTransaction());
                                            }
                                        }
                                    }

                                }
                            }

                            merchantFundingService.update(merchantFunding);
                            transactionService.saveAll(trans);
                            logger.info("system has processed file [" + file.getAbsolutePath() + "].");
                            file.renameTo(new File(processedFilePath + "/" + DateTime.now().toString("yyyy") + "/" + fileName));
                            logger.info("processed file has been moved to [" + file.getAbsolutePath() + "].");
                            if (CommonConsts.BATCH_STATUS_SUCCESS_WITH_REJECTION.equals(merchantFunding.getStatus())) {
                                emailService.send(emailFrom, emailSubject, sentTo, "Settlement accepted with error , please contact production support",
                                        generalEmailTemplate);
                            } else if (CommonConsts.BATCH_STATUS_SUCCESS.equals(merchantFunding.getStatus())) {
                                emailService.send(emailFrom, emailSubject, sentTo, "Settlement Accepted.", generalEmailTemplate);
                            }

                        }
                    } else {
                        errors.add(new ProcessingError("unexpected file name[" + file.getName() + "]."));
                        logger.error("unexpected file [" + file.getAbsolutePath() + "] received.");
                        file.renameTo(new File(failedFilePath + "/" + DateTime.now().toString("yyyy") + "/" + fileName));
                    }

                } catch (Exception e) {
                    logger.error("error happened [" + e.getMessage() + "].", e);
                    file.renameTo(new File(failedFilePath + "/" + DateTime.now().toString("yyyy") + "/" + file.getName()));
                    logger.info("processed failed file has been moved to [" + file.getAbsolutePath() + "].");
                    throw new BatchException(e.getMessage());
                }

            }
        }

        return errors;

    }

    private List<Long> getAcquirers() {
        List<Long> acquirers = new ArrayList<>();
        if (StringUtils.isNotBlank(acquirer)) {
            CollectionUtils.collect(Arrays.asList(acquirer.split(",")), new Transformer() {
                @Override
                public Object transform(Object input) {
                    return (input == null ? null : new Long((String) input));
                }
            }, acquirers);
        }
        return acquirers;
    }

    /**
     * from , to YYYYMMDD
     */
    @Override
    @Transactional
    public SubmissionFile generateSubmissionFiles(String from, String to, String serviceType) throws BatchException {
        now = new DateTime();
        SubmissionFile submissionFile = null;

        try {
            String batchNum = DATETIME_FORMAT_CCYYMMDDHHMMSS.print(now);
            logger.info("batch number generated [" + batchNum + "] for service type [" + serviceType + "].");

            DateTime start = DATETIME_FORMAT_CCYYMMDDHHMMSS.parseDateTime(from + "230000");
            DateTime end = DATETIME_FORMAT_CCYYMMDDHHMMSS.parseDateTime(to + "230000");

            logger.info("system is going to load transactionw with start date[" + start + "] , end date [" + end + "] , merchant type [" + merchantType
                    + "], acquirers[" + acquirer + "], serviceType [" + serviceType + "].");
            List<TransactionEntity> trans = transactionService.getTransactionForMerchantSettlement(start.toDate(), end.toDate(), getAcquirers(), merchantType);
            if (trans != null && trans.size() > 0) {
                BankEntity bank = bankService.getBankEntityByName(bankName);
                updateFileSequence(end);
                merchantTransactions = groupTransactionByMerchant(trans, serviceType);

                submissionFile = new SubmissionFile();
                fileUtil.getFileControlHeader(submissionFile, end, sequence);
                fileUtil.getBatchFileHeader(submissionFile, serviceType, end, batchNum, bank);
                fileUtil.getBatchDetailRecords(submissionFile, merchantTransactions, DATETIME_FORMAT_DD_MM_CCYY.print(start),
                        DATETIME_FORMAT_DD_MM_CCYY.print(end));
                fileUtil.getBatchFileTrailer(submissionFile);
                fileUtil.generateFileHash(submissionFile);
                if (submissionFile.getDetails().size() != 0) {
                    fileUtil.writeContentToLocalFile(submissionFile);
                } else {
                    logger.error("there are no records to write to the files.");
                }
            } else {
                String err = "no transaction found with from [" + start + "], to [" + end + "] , acquirers [" + StringUtils.join(getAcquirers(), ",")
                        + "], merchant type [" + merchantType + "], serviceType[" + serviceType + "].";
                logger.error(err);
                throw new BatchException(err);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new BatchException(e.getMessage());
        }
        return submissionFile;
    }

    private String updateFileSequence(DateTime end) throws SystemException {

        if ("99".equals(sequence)) {
            logger.error("reach max sequence number [" + sequence + "]already, process is shutdown.");
            throw new BatchException("reach max sequence number [" + sequence + "]already, process is shutdown.");
        }

        String ddmm = CommonConsts.DATETIME_FORMAT_DDMM.print(end);

        File dir = new File(sentFilePath + "" + DATETIME_FORMAT_CCYY.print(end));
        List<File> files = new ArrayList<>();
        if (dir.exists()) {
            files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.TRUE, TrueFileFilter.TRUE);
        } else {
            dir.mkdir();
            logger.debug("direcory in sent folder[" + sentFilePath + "] created [" + dir.getName() + "].");
        }
        List<String> names = new ArrayList<>();

        for (File file : files) {
            if (file.getName().length() == 10) {
                if (file.getName().length() > 7 && file.getName().substring(4, 8).equals(ddmm))
                    names.add(file.getName().substring(8));
            } else {
                logger.error("unexpected file in the directory [" + file.getAbsolutePath() + "].");
            }
        }

        logger.debug("no. of files in sent dir [" + dir + "] is [" + files.size() + "] with names [" + names.size() + "].");

        if (names.size() != 0) {
            Collections.sort(names);
            String max = names.get(names.size() - 1);
            sequence = StringUtils.leftPad(String.valueOf(new Integer(max) + 1), 2, '0');
        } else {
            sequence = CommonConsts.SEQUENCE_FIRST_FILE_OF_THE_DAY;
        }
        DefaultKeyValue newSequence = new DefaultKeyValue("batch.local.file.sequence", sequence);
        propertyUtil.updateProperties(newSequence);

        logger.info("file sequence updated to [" + sequence + "].");
        return sequence;
    }

    @Override
    public void uploadSubmissionFiles(List<File> files) throws BatchException {
        try {
            File dir = new File(sentFilePath + "/" + DATETIME_FORMAT_CCYY.print(now) + "/");
            if (!dir.exists()) {
                if (!dir.mkdir()) {
                    logger.error("system is not able to create sent folder [" + dir.getAbsolutePath() + "].");
                }
            }
            for (File file : files) {

                // Map<String, Object> model = new HashMap<>();
                // model.put("errors", "test");
                // List<EmailAttachment> attachements = new ArrayList<>();
                // attachements.add(new EmailAttachment(file.getName(), file));
                //
                // emailService.sendWithAttachment(emailSubject, sentTo, "test",
                // generalEmailTemplate, attachements);

                File sent = new File(dir.getAbsolutePath() + "/" + file.getName());
                if (sent.exists()) {
                    logger.error("system not going to send this file [" + sent.getAbsolutePath() + "] in generate folder as it already exists.");
                    throw new BatchException("error copying existing file to sent folder");
                } else {
                    fileTransferService.upload(file);
                    if (!file.renameTo(sent)) {
                        logger.error("system is not able to move file to sent folder [" + sent.getAbsolutePath() + "].");
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new BatchException(e.getMessage());
        }

    }

    private boolean ignoreTransactionType(String type) {
        boolean ignore = false;

        if (type.equals(CommonConsts.TRAN_TYPE_VOID_SALE) || type.equals(CommonConsts.TRAN_TYPE_VOID_REFUND)
                || type.equals(CommonConsts.TRAN_TYPE_VOID_SALE_COMPLETE) || type.equals(CommonConsts.TRAN_TYPE_VOID_SALE_ADJUST)
                || type.equals(CommonConsts.TRAN_TYPE_VOID_INSTALLMENT_SALE) || type.equals(CommonConsts.TRAN_TYPE_VOID_OFFLINE_SALE)) {
            logger.error("transaction with type [" + type + "] is excluded.");
            ignore = true;
        }
        return ignore;
    }

    private HashMap<MerchantEntity, List<TransactionEntity>> groupTransactionByMerchant(List<TransactionEntity> trans, String serviceType)
            throws BatchException {
        HashMap<MerchantEntity, List<TransactionEntity>> merchants = new HashMap<>();

        for (TransactionEntity tran : trans) {

            if (ignoreTransactionType(tran.getType())) {
                logger.error("transaction type [" + tran.getType() + "] is excluded for transaction [" + tran.getOid() + "].");
            } else if (tran.getMerchant() == null) {
                logger.error("no merchant found for the settled transaction [" + tran.getOid() + "].");
            } else if (tran.getMerchant().getConfig() == null) {
                logger.error("no merchant configuration found for the settled transaction [" + tran.getOid() + "].");
            } else if (tran.getSettlement() == null) {
                logger.error("no batch record found for the settled transaction [" + tran.getOid() + "].");
            } else if (tran.getAcquirerMerchantMapping() == null || tran.getAcquirerMerchantMapping().getAcquirer() == null) {
                logger.error("no acquirer info found for transaction [" + tran.getOid() + "].");
            } else if (!this.activeMerchantStatus.contains(tran.getMerchant().getStatus())) {
                logger.error("tran id [" + tran.getOid() + "] is excluded for merchant name [" + tran.getMerchant().getName() + "] , merchant status ["
                        + tran.getMerchant().getStatus() + "]");
            } else {
                if (merchants.get(tran.getMerchant()) == null) {
                    merchants.put(tran.getMerchant(), new ArrayList<TransactionEntity>());
                }
                String bank = tran.getMerchant().getConfig().getBankCode();

                if (BatchConsts.UOB_SERVICE_TYPE_EXPRESS.equals(serviceType)) {
                    if (Arrays.asList(BatchConsts.UOB_SG_BANK_CODE).contains(bank)) {
                        merchants.get(tran.getMerchant()).add(tran);
                    } else {
                        logger.error("transaction[" + tran.getOid() + "] is excluded with service type [" + serviceType + "], and bank code[" + bank + "].");
                    }
                } else if (BatchConsts.UOB_SERVICE_TYPE_NORMAL.equals(serviceType)) {
                    if (Arrays.asList(BatchConsts.UOB_SG_BANK_CODE).contains(bank)) {
                        logger.error("transaction[" + tran.getOid() + "] is excluded with service type [" + serviceType + "], and bank code[" + bank + "].");
                    } else {
                        merchants.get(tran.getMerchant()).add(tran);
                    }
                } else {
                    logger.error("requested service type[" + serviceType + "] is not expected.");
                }

            }

        }

        return merchants;
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public MerchantFundingEntity recordMerchantFunding(SubmissionFile submissionFile) {

        MerchantFundingEntity funding = new MerchantFundingEntity();
        funding.setBatchNum(submissionFile.getHeader().getBatchNo().getValue());
        funding.setFileName(submissionFile.getControl().getFileName().getValue());
        funding.setTotalCreditAmount(submissionFile.getTrailer().getTotalCreditAmount().getValue());
        funding.setTotalCreditCount(submissionFile.getTrailer().getTotalCreditCount().getValue());
        funding.setTotalDebitAmount(submissionFile.getTrailer().getTotalDebitAmount().getValue());
        funding.setTotalDebitCount(submissionFile.getTrailer().getTotalDebitCount().getValue());
        funding.setStatus(CommonConsts.BATCH_STATUS_SUBMITTED);
        funding.setSubmitDate(DATETIME_FORMAT_CCYYMMDD.print(now));
        funding.setValueDate(submissionFile.getHeader().getValueDate().getValue());
        funding.setServiceType(submissionFile.getHeader().getServiceType().getValue());
        MerchantFundingRecordEntity record = null;
        MerchantFundingTransactionMappingEntity mapping = null;
        List<TransactionEntity> trans = new ArrayList<>();
        for (SubmissionDetailRecord detail : submissionFile.getDetails()) {

            record = new MerchantFundingRecordEntity();
            record.setMerchant(detail.getMerchant());
            record.setAmount(detail.getAmount().getValue());
            record.setStatus(CommonConsts.BATCH_STATUS_SUBMITTED);
            record.setTrace(detail.getReference().getValue());

            for (Map.Entry<MerchantEntity, List<TransactionEntity>> entry : merchantTransactions.entrySet()) {
                MerchantEntity merchant = entry.getKey();
                if (merchant.equals(detail.getMerchant())) {
                    for (TransactionEntity tran : entry.getValue()) {
                        mapping = new MerchantFundingTransactionMappingEntity();
                        mapping.setTransaction(tran);
                        tran.setPaymentStatus(CommonConsts.TRAN_PAYMENT_STATUS_SUBMITTED);
                        trans.add(tran);
                        mapping.setRecord(record);
                        record.addTransactionMapping(mapping);
                    }
                }

                funding.addRecord(record);
            }
        }

        funding = merchantFundingService.save(funding);
        transactionService.saveAll(trans);
        return funding;
    }

}
