package com.nets.sg.npx.batch.uob.jobs;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.nets.sg.npx.batch.common.service.BatchEmailService;
import com.nets.sg.npx.batch.uob.service.BatchService;
import com.nets.sg.npx.batch.uob.util.BatchConsts;

@Component("normalResponseJob")
public class NormalResponseJob {

    private static final Logger logger = Logger.getLogger(NormalResponseJob.class);

    @Autowired
    private BatchService batchService;

    @Autowired
    private BatchEmailService emailService;

    @Scheduled(cron = "${batch.uob.scheduler.job.response.normal}")
    public void execute() {
        try {
            batchService.processInputFile(BatchConsts.UOB_SERVICE_TYPE_NORMAL);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            emailService.sendError(e.getMessage());
        }
    }

}
