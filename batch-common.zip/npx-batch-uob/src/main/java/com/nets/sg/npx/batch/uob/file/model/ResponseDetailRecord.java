package com.nets.sg.npx.batch.uob.file.model;

import static com.nets.sg.npx.batch.uob.file.model.DataField.MANDATORY_CONDITIONAL;
import static com.nets.sg.npx.batch.uob.file.model.DataField.MANDATORY_NO;
import static com.nets.sg.npx.batch.uob.file.model.DataField.TYPE_NUMERIC;

import java.io.Serializable;

public class ResponseDetailRecord implements Serializable {

    private DataField recordType = new DataField(1, 1);

    private DataField receivingBankCode = new DataField(TYPE_NUMERIC, 2, 4);
    private DataField receivingBranchCode = new DataField(TYPE_NUMERIC, 6, 3);
    private DataField receivingAccountNo = new DataField(TYPE_NUMERIC, 9, 11);
    private DataField receivingAccountName = new DataField(20, 20);
    private DataField transactionCode = new DataField(TYPE_NUMERIC, 40, 2);
    private DataField amount = new DataField(TYPE_NUMERIC, 42, 11);
    private DataField particulars = new DataField(53, 12, MANDATORY_NO);
    private DataField reference = new DataField(65, 12, MANDATORY_CONDITIONAL);
    private DataField clearFate = new DataField(77, 1, MANDATORY_NO);
    private DataField rejectionCode = new DataField(78, 2);
    private DataField filterOne = new DataField(80, 5);
    private DataField beneficiaryId = new DataField(85, 20, MANDATORY_NO);
    private DataField beneficiaryNameLineOne = new DataField(105, 35, MANDATORY_NO);
    private DataField beneficiaryNameLineTwo = new DataField(140, 35, MANDATORY_NO);
    private DataField customerReference = new DataField(175, 30, MANDATORY_NO);
    private DataField printPaymentAdviceIndicator = new DataField(205, 1);
    private DataField reasonOfNotPrinted = new DataField(206, 50, MANDATORY_NO);
    private DataField filterTwo = new DataField(256, 45, MANDATORY_NO);

    public DataField getRecordType() {
        return recordType;
    }

    public void setRecordType(DataField recordType) {
        this.recordType = recordType;
    }

    public DataField getReceivingBankCode() {
        return receivingBankCode;
    }

    public void setReceivingBankCode(DataField receivingBankCode) {
        this.receivingBankCode = receivingBankCode;
    }

    public DataField getReceivingBranchCode() {
        return receivingBranchCode;
    }

    public void setReceivingBranchCode(DataField receivingBranchCode) {
        this.receivingBranchCode = receivingBranchCode;
    }

    public DataField getReceivingAccountNo() {
        return receivingAccountNo;
    }

    public void setReceivingAccountNo(DataField receivingAccountNo) {
        this.receivingAccountNo = receivingAccountNo;
    }

    public DataField getReceivingAccountName() {
        return receivingAccountName;
    }

    public void setReceivingAccountName(DataField receivingAccountName) {
        this.receivingAccountName = receivingAccountName;
    }

    public DataField getTransactionCode() {
        return transactionCode;
    }

    public void setTransactionCode(DataField transactionCode) {
        this.transactionCode = transactionCode;
    }

    public DataField getAmount() {
        return amount;
    }

    public void setAmount(DataField amount) {
        this.amount = amount;
    }

    public DataField getParticulars() {
        return particulars;
    }

    public void setParticulars(DataField particulars) {
        this.particulars = particulars;
    }

    public DataField getReference() {
        return reference;
    }

    public void setReference(DataField reference) {
        this.reference = reference;
    }

    public DataField getClearFate() {
        return clearFate;
    }

    public void setClearFate(DataField clearFate) {
        this.clearFate = clearFate;
    }

    public DataField getRejectionCode() {
        return rejectionCode;
    }

    public void setRejectionCode(DataField rejectionCode) {
        this.rejectionCode = rejectionCode;
    }

    public DataField getFilterOne() {
        return filterOne;
    }

    public void setFilterOne(DataField filterOne) {
        this.filterOne = filterOne;
    }

    public DataField getBeneficiaryId() {
        return beneficiaryId;
    }

    public void setBeneficiaryId(DataField beneficiaryId) {
        this.beneficiaryId = beneficiaryId;
    }

    public DataField getBeneficiaryNameLineOne() {
        return beneficiaryNameLineOne;
    }

    public void setBeneficiaryNameLineOne(DataField beneficiaryNameLineOne) {
        this.beneficiaryNameLineOne = beneficiaryNameLineOne;
    }

    public DataField getBeneficiaryNameLineTwo() {
        return beneficiaryNameLineTwo;
    }

    public void setBeneficiaryNameLineTwo(DataField beneficiaryNameLineTwo) {
        this.beneficiaryNameLineTwo = beneficiaryNameLineTwo;
    }

    public DataField getCustomerReference() {
        return customerReference;
    }

    public void setCustomerReference(DataField customerReference) {
        this.customerReference = customerReference;
    }

    public DataField getPrintPaymentAdviceIndicator() {
        return printPaymentAdviceIndicator;
    }

    public void setPrintPaymentAdviceIndicator(DataField printPaymentAdviceIndicator) {
        this.printPaymentAdviceIndicator = printPaymentAdviceIndicator;
    }

    public DataField getReasonOfNotPrinted() {
        return reasonOfNotPrinted;
    }

    public void setReasonOfNotPrinted(DataField reasonOfNotPrinted) {
        this.reasonOfNotPrinted = reasonOfNotPrinted;
    }

    public DataField getFilterTwo() {
        return filterTwo;
    }

    public void setFilterTwo(DataField filterTwo) {
        this.filterTwo = filterTwo;
    }

    @Override
    public String toString() {
        return "ResponseDetailRecord [recordType=" + recordType + ", receivingBankCode=" + receivingBankCode + ", receivingBranchCode=" + receivingBranchCode
                + ", receivingAccountNo=" + receivingAccountNo + ", receivingAccountName=" + receivingAccountName + ", transactionCode=" + transactionCode + ", amount=" + amount
                + ", particulars=" + particulars + ", reference=" + reference + ", clearFate=" + clearFate + ", rejectionCode=" + rejectionCode + ", filterOne=" + filterOne
                + ", beneficiaryId=" + beneficiaryId + ", beneficiaryNameLineOne=" + beneficiaryNameLineOne + ", beneficiaryNameLineTwo=" + beneficiaryNameLineTwo
                + ", customerReference=" + customerReference + ", printPaymentAdviceIndicator=" + printPaymentAdviceIndicator + ", reasonOfNotPrinted=" + reasonOfNotPrinted
                + ", filterTwo=" + filterTwo + "]";
    }

}
