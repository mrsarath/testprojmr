package com.nets.sg.npx.batch.uob.service.impl;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.keyvalue.DefaultKeyValue;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.batch.common.error.ProcessingError;
import com.nets.sg.npx.batch.common.exception.BatchException;
import com.nets.sg.npx.batch.uob.file.model.SubmissionFile;
import com.nets.sg.npx.batch.uob.service.AdviceFileService;
import com.nets.sg.npx.batch.uob.service.BatchService;
import com.nets.sg.npx.core.exception.SystemException;
import com.nets.sg.npx.core.service.EmailService;
import com.nets.sg.npx.core.util.CommonConsts;
import com.nets.sg.npx.core.util.PropertyUtil;

@Service
public class BatchServiceImpl implements BatchService {

    private static final Logger logger = Logger.getLogger(BatchServiceImpl.class);

    @Value("${batch.sftp.local.dir.sent}")
    private String sentFilePath;

    @Value("${batch.sftp.local.dir.generated}")
    private String plainFilePath;

    @Autowired
    private AdviceFileService adviceFileService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private PropertyUtil propertyUtil;

    @Value("${batch.email.error.send.from}")
    private String errorEmailFrom;

    @Value("${batch.email.error.send.to}")
    private String errorEmailTo;

    @Value("${batch.email.error.subject}")
    private String errorEmailSubject;

    @Value("${batch.email.error.template}")
    private String errorEmailTemplate;

    @Value("${batch.sg.public.holiday}")
    private String holiday;

    private void updateLastDateFileGenerated(String date, String serviceType) throws SystemException {

        DefaultKeyValue newSequence = new DefaultKeyValue("batch.uob.last.date.file.generated." + serviceType, date);
        propertyUtil.updateProperties(newSequence);

        logger.info("update last date file generated [" + date + "].");

    }

    /**
     * 
     * @param today
     * @return
     */
    private boolean skip(String date) {
        boolean skip = false;
        if (holiday.contains(date)) {
            skip = true;
            logger.error("[" + date + "] is public holiday , so batch is aborted");
        }
        return skip;
    }

    @Override
    public boolean processOutputFile(String date, String serviceType) throws BatchException {
        boolean result = true;

        try {
            DateTime yesterday = DateTime.parse(date, CommonConsts.DATETIME_FORMAT_CCYYMMDD).minusDays(1);

            if (!skip(date)) {
                String begin = PropertyUtil.getProperty("batch.uob.last.date.file.generated." + serviceType);
                logger.info("batch.uob.last.date.file.generated." + serviceType + " is [" + begin + "].");
                begin = StringUtils.isBlank(begin) ? yesterday.toString("yyyyMMdd") : begin;

                SubmissionFile submissionFile = adviceFileService.generateSubmissionFiles(begin, date, serviceType);
                if (submissionFile != null && submissionFile.getDetails() != null && submissionFile.getDetails().size() > 0) {
                    File generated = new File(plainFilePath + submissionFile.getControl().getFileName());

                    adviceFileService.uploadSubmissionFiles(Arrays.asList(new File[] { generated }));
                    logger.info("file [" + generated.getAbsolutePath() + "] uploaded at [" + DateTime.now() + "].");
                    adviceFileService.recordMerchantFunding(submissionFile);
                    logger.info("merchant funding records generated");
                    updateLastDateFileGenerated(DateTime.now().toString("yyyyMMdd"), serviceType);
                    logger.info("last date file generated update to date[" + date + "] for service type[" + serviceType + "].");
                } else {
                    logger.info("no submission file to generate for given date [" + date + "] and service type[" + serviceType + "]");
                }
            }
        } catch (BatchException e) {
            logger.error("error happened [" + e.getMessage() + "].", e);
            throw new BatchException(e.getMessage());
        } catch (Exception ex) {
            logger.error("error happened [" + ex.getMessage() + "].", ex);
            result = false;
        }

        return result;
    }

    private void sendError(String content) {
        Map<String, Object> model = new HashMap<>();
        model.put("errors", content);
        emailService.sendMail(errorEmailFrom, errorEmailTo, errorEmailSubject, errorEmailTemplate, model);

    }

    private void sendProcessingError(List<ProcessingError> errs) {
        StringBuilder builder = new StringBuilder();
        for (ProcessingError err : errs) {
            builder.append(err.getMessage() + "<br/>");
        }

        if (StringUtils.isNotBlank(builder.toString())) {
            sendError(builder.toString());
        }
    }

    @Override
    public boolean processInputFile(String serviceType) throws BatchException {

        boolean result = true;

        try {
            List<File> files = adviceFileService.downloadResponseFiles(serviceType);
            logger.debug("system downloaded [" + (files == null ? 0 : files.size()) + "] files waiting to be processed.");
            List<ProcessingError> errors = adviceFileService.processResponseFiles(files, serviceType);
            sendProcessingError(errors);
        } catch (BatchException e) {
            logger.error("error happened [" + e.getMessage() + "].", e);
            throw new BatchException(e.getMessage());
        } catch (Exception ex) {
            logger.error("error happened [" + ex.getMessage() + "].", ex);
            result = false;
        }

        return result;
    }

}
