package com.nets.sg.npx.batch.uob.service;

import java.io.File;
import java.util.List;

import com.nets.sg.npx.batch.common.exception.BatchException;

public interface FileTransferService {

    boolean upload(File file) throws BatchException;

    List<File> download(String receivedPath, String serviceType) throws BatchException;

}
