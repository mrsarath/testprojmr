package com.nets.sg.npx.batch.uob.file.model;

import java.io.Serializable;

public class DataField implements Serializable {

    public static final String TYPE_NUMERIC = "N";

    public static final String TYPE_ALPHABETIC = "A";

    public static final String TYPE_NUMERIC_ALPHABETIC = "NA";

    public static final String MANDATORY_YES = "Y";

    public static final String MANDATORY_NO = "N";

    public static final String MANDATORY_CONDITIONAL = "C";

    private String type = TYPE_ALPHABETIC;

    private Integer position = 0;

    private Integer length = 0;

    private String value = "";

    private String mandatory = MANDATORY_YES;

    public DataField(Integer position, Integer length) {
        this.position = position;
        this.length = length;
    }

    public DataField(Integer position, Integer length, String mandatory) {
        this.position = position;
        this.length = length;
        this.mandatory = mandatory;
    }

    public DataField(String type, Integer position, Integer length) {
        this.type = type;
        this.position = position;
        this.length = length;
    }

    public DataField(String type, Integer position, Integer length, String mandatory) {
        this.type = type;
        this.position = position;
        this.length = length;
        this.mandatory = mandatory;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getMandatory() {
        return mandatory;
    }

    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

    @Override
    public String toString() {
        return getValue();
    }

}
