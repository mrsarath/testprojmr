package com.nets.sg.npx.batch.uob.file.model;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is an abstraction of incoming (response) file from UOB.
 *
 */
public class ResponseFile {

    private String fileName;

    private ResponseFileHeader header;

    private List<ResponseDetailRecord> details = new ArrayList<>();

    private ResponseFileTrailer trailer;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public ResponseFileHeader getHeader() {
        return header;
    }

    public void setHeader(ResponseFileHeader header) {
        this.header = header;
    }

    public List<ResponseDetailRecord> getDetails() {
        return details;
    }

    public void setDetails(List<ResponseDetailRecord> details) {
        this.details = details;
    }

    public boolean addResponseDetailRecord(ResponseDetailRecord record) {
        return this.details.add(record);
    }

    public ResponseFileTrailer getTrailer() {
        return trailer;
    }

    public void setTrailer(ResponseFileTrailer trailer) {
        this.trailer = trailer;
    }

    @Override
    public String toString() {
        return "ResponseFile [fileName=" + fileName + ", header=" + header + ", details=" + details + ", trailer=" + trailer + "]";
    }

}
