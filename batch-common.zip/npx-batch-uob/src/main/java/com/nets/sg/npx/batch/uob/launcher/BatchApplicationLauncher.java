package com.nets.sg.npx.batch.uob.launcher;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nets.sg.npx.batch.common.service.BatchEmailService;
import com.nets.sg.npx.batch.uob.service.BatchService;
import com.nets.sg.npx.batch.uob.util.BatchConsts;

public class BatchApplicationLauncher {

    private static final Logger logger = Logger.getLogger(BatchApplicationLauncher.class);

    public static void main(String[] args) {
        ApplicationContext ctx = null;
        DateTime now = new DateTime();
        try {

            if (args.length > 0 && args[0].equals("HELP")) {
                printHelp();
            } else {
                ctx = new ClassPathXmlApplicationContext("batch-root-ctx.xml");
                logger.info("Batch Application Started at [" + now + "].");
                BatchService batchService = ctx.getBean(BatchService.class);

                if (args.length > 0 && args[0].equals("SUB")) {
                    String date = (args.length > 1 ? args[1] : now.toString("yyyyMMdd"));
                    String serviceType = (args.length > 2 ? args[2] : BatchConsts.UOB_SERVICE_TYPE_EXPRESS);
                    batchService.processOutputFile(date, serviceType);
                } else if (args.length > 0 && args[0].equals("RES")) {
                    String serviceType = (args.length > 2 ? args[2] : BatchConsts.UOB_SERVICE_TYPE_EXPRESS);
                    batchService.processInputFile(serviceType);
                } else {
                    logger.info("no parameter provided system is going to run scheduled jobs.");
                }
            }

        } catch (Exception e) {
            logger.error("Batch Applicationi Ended at [" + now + "] with error [" + e.getMessage() + "].", e);

            if (ctx != null) {
                BatchEmailService batchEmailService = ctx.getBean(BatchEmailService.class);
                batchEmailService.sendError(e.getMessage());
            }

        } finally {
            if (args.length > 0 && ctx != null) {
                logger.info("Batch Application Ended at [" + now + "].");
                ((ConfigurableApplicationContext) ctx).close();
            }
        }
    }

    private static void printHelp() {
        System.out.println("-------------------------------------------------------------------");
        System.out.println("Usage : java -jar npx-batch-uob.jar <action> [date(yyyyMMdd)] [service type]");
        System.out.println("                                                                   ");
        System.out.println("<action> : SUB (generate submission file and upload to SFTP server.)");
        System.out.println("           RES (download response file from SFTP server and reflect the settlement result in npx.");
        System.out.println("                                                                   ");
        System.out.println("[date(yyyyMMdd)] : get settled transction by this date 11 p.m , if blank then system date");
        System.out.println("                                                                   ");
        System.out.println("[servie type] : IBGIEXP (for merchant with UOB account, this is default value.)");
        System.out.println("                IBGINORM (for merchant using NONE UOB account.)");
        System.out.println("-------------------------------------------------------------------");
        System.out.println("Sample : java -jar npx-batch-uob.jar SUB 20150506 IBGIEXP          ");
        System.out.println("Sample : java -jar npx-batch-uob.jar SUB 20150506 IBGINORM         ");
        System.out.println("Sample : java -jar npx-batch-uob.jar RES IBGIEXP                   ");
        System.out.println("Sample : java -jar npx-batch-uob.jar RES IBGINORM                  ");
        System.out.println("-------------------------------------------------------------------");
    }

}
