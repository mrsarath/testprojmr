package com.nets.sg.npx.batch.uob.file.model;

import static com.nets.sg.npx.batch.uob.file.model.DataField.MANDATORY_NO;
import static com.nets.sg.npx.batch.uob.file.model.DataField.TYPE_NUMERIC;

import java.io.Serializable;

public class SubmissionFileHeader implements Serializable {

    private DataField recordType = new DataField(1, 1);

    private DataField serviceType = new DataField(2, 10);

    private DataField originatingBankCode = new DataField(TYPE_NUMERIC, 12, 4);

    private DataField originatingBranchCode = new DataField(TYPE_NUMERIC, 16, 3);

    private DataField originatingAccountNo = new DataField(TYPE_NUMERIC, 19, 11);

    private DataField originatingAccountName = new DataField(30, 20);

    private DataField creationDate = new DataField(TYPE_NUMERIC, 50, 8);

    private DataField valueDate = new DataField(TYPE_NUMERIC, 58, 8);

    private DataField reference = new DataField(TYPE_NUMERIC, 66, 5);

    private DataField filterOne = new DataField(71, 10, MANDATORY_NO);

    private DataField batchNo = new DataField(81, 20);

    private DataField paymentAdviceHeaderLineOne = new DataField(101, 105);

    private DataField paymentAdviceHeaderLineTwo = new DataField(206, 105);

    private DataField filterTwo = new DataField(311, 290, MANDATORY_NO);

    public DataField getRecordType() {
        return recordType;
    }

    public void setRecordType(DataField recordType) {
        this.recordType = recordType;
    }

    public DataField getServiceType() {
        return serviceType;
    }

    public void setServiceType(DataField serviceType) {
        this.serviceType = serviceType;
    }

    public DataField getOriginatingBankCode() {
        return originatingBankCode;
    }

    public void setOriginatingBankCode(DataField originatingBankCode) {
        this.originatingBankCode = originatingBankCode;
    }

    public DataField getOriginatingBranchCode() {
        return originatingBranchCode;
    }

    public void setOriginatingBranchCode(DataField originatingBranchCode) {
        this.originatingBranchCode = originatingBranchCode;
    }

    public DataField getOriginatingAccountNo() {
        return originatingAccountNo;
    }

    public void setOriginatingAccountNo(DataField originatingAccountNo) {
        this.originatingAccountNo = originatingAccountNo;
    }

    public DataField getOriginatingAccountName() {
        return originatingAccountName;
    }

    public void setOriginatingAccountName(DataField originatingAccountName) {
        this.originatingAccountName = originatingAccountName;
    }

    public DataField getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(DataField creationDate) {
        this.creationDate = creationDate;
    }

    public DataField getValueDate() {
        return valueDate;
    }

    public void setValueDate(DataField valueDate) {
        this.valueDate = valueDate;
    }

    public DataField getReference() {
        return reference;
    }

    public void setReference(DataField reference) {
        this.reference = reference;
    }

    public DataField getFilterOne() {
        return filterOne;
    }

    public void setFilterOne(DataField filterOne) {
        this.filterOne = filterOne;
    }

    public DataField getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(DataField batchNo) {
        this.batchNo = batchNo;
    }

    public DataField getPaymentAdviceHeaderLineOne() {
        return paymentAdviceHeaderLineOne;
    }

    public void setPaymentAdviceHeaderLineOne(DataField paymentAdviceHeaderLineOne) {
        this.paymentAdviceHeaderLineOne = paymentAdviceHeaderLineOne;
    }

    public DataField getPaymentAdviceHeaderLineTwo() {
        return paymentAdviceHeaderLineTwo;
    }

    public void setPaymentAdviceHeaderLineTwo(DataField paymentAdviceHeaderLineTwo) {
        this.paymentAdviceHeaderLineTwo = paymentAdviceHeaderLineTwo;
    }

    public DataField getFilterTwo() {
        return filterTwo;
    }

    public void setFilterTwo(DataField filterTwo) {
        this.filterTwo = filterTwo;
    }

    @Override
    public String toString() {
        return "BatchFileHeader [recordType=" + recordType + ", serviceType=" + serviceType + ", originatingBankCode=" + originatingBankCode + ", originatingBranchCode="
                + originatingBranchCode + ", originatingAccountNo=" + originatingAccountNo + ", originatingAccountName=" + originatingAccountName + ", creationDate="
                + creationDate + ", valueDate=" + valueDate + ", reference=" + reference + ", filterOne=" + filterOne + ", batchNo=" + batchNo + ", paymentAdviceHeaderLineOne="
                + paymentAdviceHeaderLineOne + ", paymentAdviceHeaderLineTwo=" + paymentAdviceHeaderLineTwo + ", filterTwo=" + filterTwo + "]";
    }

}
