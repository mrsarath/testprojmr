package com.nets.sg.npx.batch.uob.file.model;

import static com.nets.sg.npx.batch.uob.file.model.DataField.MANDATORY_CONDITIONAL;
import static com.nets.sg.npx.batch.uob.file.model.DataField.MANDATORY_NO;
import static com.nets.sg.npx.batch.uob.file.model.DataField.TYPE_NUMERIC;

import java.io.Serializable;

import com.nets.sg.npx.core.persistence.entity.MerchantEntity;

public class SubmissionDetailRecord implements Serializable {

    private DataField recordType = new DataField(1, 1);

    private DataField receivingBankCode = new DataField(TYPE_NUMERIC, 2, 4);
    private DataField receivingBranchCode = new DataField(TYPE_NUMERIC, 6, 3);
    private DataField receivingAccountNo = new DataField(9, 11);
    private DataField receivingAccountName = new DataField(20, 20);
    private DataField transactionCode = new DataField(TYPE_NUMERIC, 40, 2);
    private DataField amount = new DataField(TYPE_NUMERIC, 42, 11);
    private DataField particulars = new DataField(53, 12, MANDATORY_NO);
    private DataField reference = new DataField(65, 12, MANDATORY_CONDITIONAL);
    private DataField filterOne = new DataField(77, 4, MANDATORY_NO);
    private DataField printPaymentAdviceIndicator = new DataField(81, 1);
    private DataField deliveryMode = new DataField(82, 1);
    private DataField adviceFormat = new DataField(83, 1);
    private DataField beneficiaryId = new DataField(84, 20, MANDATORY_NO);
    private DataField beneficiaryNameLineOne = new DataField(104, 35, MANDATORY_NO);
    private DataField beneficiaryNameLineTwo = new DataField(139, 35, MANDATORY_NO);
    private DataField beneficiaryAddressLineOne = new DataField(174, 35, MANDATORY_NO);
    private DataField beneficiaryAddressLineTwo = new DataField(209, 35, MANDATORY_NO);
    private DataField beneficiaryAddressLineThree = new DataField(244, 35, MANDATORY_NO);
    private DataField beneficiaryAddressLineFour = new DataField(279, 35, MANDATORY_NO);
    private DataField beneficiaryCity = new DataField(314, 17, MANDATORY_NO);
    private DataField beneficiaryCountryCode = new DataField(331, 3, MANDATORY_NO);
    private DataField beneficiaryPostalCode = new DataField(334, 15, MANDATORY_NO);
    private DataField emailAddressOfBeneficiary = new DataField(349, 50, MANDATORY_CONDITIONAL);
    private DataField facsimileNumOfBeneficiary = new DataField(399, 20, MANDATORY_CONDITIONAL);
    private DataField paymentCurrency = new DataField(419, 3);
    private DataField payerNameLineOne = new DataField(422, 35, MANDATORY_NO);
    private DataField payerNameLineTwo = new DataField(457, 35, MANDATORY_NO);
    private DataField customerReference = new DataField(492, 30, MANDATORY_NO);
    private DataField filterTwo = new DataField(522, 79, MANDATORY_NO);

    private MerchantEntity merchant;

    public DataField getRecordType() {
        return recordType;
    }

    public void setRecordType(DataField recordType) {
        this.recordType = recordType;
    }

    public DataField getReceivingBankCode() {
        return receivingBankCode;
    }

    public void setReceivingBankCode(DataField receivingBankCode) {
        this.receivingBankCode = receivingBankCode;
    }

    public DataField getReceivingBranchCode() {
        return receivingBranchCode;
    }

    public void setReceivingBranchCode(DataField receivingBranchCode) {
        this.receivingBranchCode = receivingBranchCode;
    }

    public DataField getReceivingAccountNo() {
        return receivingAccountNo;
    }

    public void setReceivingAccountNo(DataField receivingAccountNo) {
        this.receivingAccountNo = receivingAccountNo;
    }

    public DataField getReceivingAccountName() {
        return receivingAccountName;
    }

    public void setReceivingAccountName(DataField receivingAccountName) {
        this.receivingAccountName = receivingAccountName;
    }

    public DataField getTransactionCode() {
        return transactionCode;
    }

    public void setTransactionCode(DataField transactionCode) {
        this.transactionCode = transactionCode;
    }

    public DataField getAmount() {
        return amount;
    }

    public void setAmount(DataField amount) {
        this.amount = amount;
    }

    public DataField getParticulars() {
        return particulars;
    }

    public void setParticulars(DataField particulars) {
        this.particulars = particulars;
    }

    public DataField getReference() {
        return reference;
    }

    public void setReference(DataField reference) {
        this.reference = reference;
    }

    public DataField getFilterOne() {
        return filterOne;
    }

    public void setFilterOne(DataField filterOne) {
        this.filterOne = filterOne;
    }

    public DataField getPrintPaymentAdviceIndicator() {
        return printPaymentAdviceIndicator;
    }

    public void setPrintPaymentAdviceIndicator(DataField printPaymentAdviceIndicator) {
        this.printPaymentAdviceIndicator = printPaymentAdviceIndicator;
    }

    public DataField getDeliveryMode() {
        return deliveryMode;
    }

    public void setDeliveryMode(DataField deliveryMode) {
        this.deliveryMode = deliveryMode;
    }

    public DataField getAdviceFormat() {
        return adviceFormat;
    }

    public void setAdviceFormat(DataField adviceFormat) {
        this.adviceFormat = adviceFormat;
    }

    public DataField getBeneficiaryId() {
        return beneficiaryId;
    }

    public void setBeneficiaryId(DataField beneficiaryId) {
        this.beneficiaryId = beneficiaryId;
    }

    public DataField getBeneficiaryNameLineOne() {
        return beneficiaryNameLineOne;
    }

    public void setBeneficiaryNameLineOne(DataField beneficiaryNameLineOne) {
        this.beneficiaryNameLineOne = beneficiaryNameLineOne;
    }

    public DataField getBeneficiaryNameLineTwo() {
        return beneficiaryNameLineTwo;
    }

    public void setBeneficiaryNameLineTwo(DataField beneficiaryNameLineTwo) {
        this.beneficiaryNameLineTwo = beneficiaryNameLineTwo;
    }

    public DataField getBeneficiaryAddressLineOne() {
        return beneficiaryAddressLineOne;
    }

    public void setBeneficiaryAddressLineOne(DataField beneficiaryAddressLineOne) {
        this.beneficiaryAddressLineOne = beneficiaryAddressLineOne;
    }

    public DataField getBeneficiaryAddressLineTwo() {
        return beneficiaryAddressLineTwo;
    }

    public void setBeneficiaryAddressLineTwo(DataField beneficiaryAddressLineTwo) {
        this.beneficiaryAddressLineTwo = beneficiaryAddressLineTwo;
    }

    public DataField getBeneficiaryAddressLineThree() {
        return beneficiaryAddressLineThree;
    }

    public void setBeneficiaryAddressLineThree(DataField beneficiaryAddressLineThree) {
        this.beneficiaryAddressLineThree = beneficiaryAddressLineThree;
    }

    public DataField getBeneficiaryAddressLineFour() {
        return beneficiaryAddressLineFour;
    }

    public void setBeneficiaryAddressLineFour(DataField beneficiaryAddressLineFour) {
        this.beneficiaryAddressLineFour = beneficiaryAddressLineFour;
    }

    public DataField getBeneficiaryCity() {
        return beneficiaryCity;
    }

    public void setBeneficiaryCity(DataField beneficiaryCity) {
        this.beneficiaryCity = beneficiaryCity;
    }

    public DataField getBeneficiaryCountryCode() {
        return beneficiaryCountryCode;
    }

    public void setBeneficiaryCountryCode(DataField beneficiaryCountryCode) {
        this.beneficiaryCountryCode = beneficiaryCountryCode;
    }

    public DataField getBeneficiaryPostalCode() {
        return beneficiaryPostalCode;
    }

    public void setBeneficiaryPostalCode(DataField beneficiaryPostalCode) {
        this.beneficiaryPostalCode = beneficiaryPostalCode;
    }

    public DataField getEmailAddressOfBeneficiary() {
        return emailAddressOfBeneficiary;
    }

    public void setEmailAddressOfBeneficiary(DataField emailAddressOfBeneficiary) {
        this.emailAddressOfBeneficiary = emailAddressOfBeneficiary;
    }

    public DataField getFacsimileNumOfBeneficiary() {
        return facsimileNumOfBeneficiary;
    }

    public void setFacsimileNumOfBeneficiary(DataField facsimileNumOfBeneficiary) {
        this.facsimileNumOfBeneficiary = facsimileNumOfBeneficiary;
    }

    public DataField getPaymentCurrency() {
        return paymentCurrency;
    }

    public void setPaymentCurrency(DataField paymentCurrency) {
        this.paymentCurrency = paymentCurrency;
    }

    public DataField getPayerNameLineOne() {
        return payerNameLineOne;
    }

    public void setPayerNameLineOne(DataField payerNameLineOne) {
        this.payerNameLineOne = payerNameLineOne;
    }

    public DataField getPayerNameLineTwo() {
        return payerNameLineTwo;
    }

    public void setPayerNameLineTwo(DataField payerNameLineTwo) {
        this.payerNameLineTwo = payerNameLineTwo;
    }

    public DataField getCustomerReference() {
        return customerReference;
    }

    public void setCustomerReference(DataField customerReference) {
        this.customerReference = customerReference;
    }

    public DataField getFilterTwo() {
        return filterTwo;
    }

    public void setFilterTwo(DataField filterTwo) {
        this.filterTwo = filterTwo;
    }

    public MerchantEntity getMerchant() {
        return merchant;
    }

    public void setMerchant(MerchantEntity merchant) {
        this.merchant = merchant;
    }

    @Override
    public String toString() {
        return "SubmissionDetailRecord [recordType=" + recordType + ", receivingBankCode=" + receivingBankCode + ", receivingBranchCode=" + receivingBranchCode
                + ", receivingAccountNo=" + receivingAccountNo + ", receivingAccountName=" + receivingAccountName + ", transactionCode=" + transactionCode
                + ", amount=" + amount + ", particulars=" + particulars + ", reference=" + reference + ", filterOne=" + filterOne
                + ", printPaymentAdviceIndicator=" + printPaymentAdviceIndicator + ", deliveryMode=" + deliveryMode + ", adviceFormat=" + adviceFormat
                + ", beneficiaryId=" + beneficiaryId + ", beneficiaryNameLineOne=" + beneficiaryNameLineOne + ", beneficiaryNameLineTwo="
                + beneficiaryNameLineTwo + ", beneficiaryAddressLineOne=" + beneficiaryAddressLineOne + ", beneficiaryAddressLineTwo="
                + beneficiaryAddressLineTwo + ", beneficiaryAddressLineThree=" + beneficiaryAddressLineThree + ", beneficiaryAddressLineFour="
                + beneficiaryAddressLineFour + ", beneficiaryCity=" + beneficiaryCity + ", beneficiaryCountryCode=" + beneficiaryCountryCode
                + ", beneficiaryPostalCode=" + beneficiaryPostalCode + ", emailAddressOfBeneficiary=" + emailAddressOfBeneficiary
                + ", facsimileNumOfBeneficiary=" + facsimileNumOfBeneficiary + ", paymentCurrency=" + paymentCurrency + ", payerNameLineOne="
                + payerNameLineOne + ", payerNameLineTwo=" + payerNameLineTwo + ", customerReference=" + customerReference + ", filterTwo=" + filterTwo + "]";
    }

}
