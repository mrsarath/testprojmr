package com.nets.sg.npx.batch.uob.file.model;

import static com.nets.sg.npx.batch.uob.file.model.DataField.TYPE_NUMERIC;

import java.io.Serializable;

public class SubmissionFileTrailer implements Serializable {

    private DataField recordType = new DataField(1, 1);

    private DataField totalDebitAmount = new DataField(TYPE_NUMERIC, 2, 13);

    private DataField totalCreditAmount = new DataField(TYPE_NUMERIC, 15, 13);

    private DataField totalDebitCount = new DataField(TYPE_NUMERIC, 28, 7);

    private DataField totalCreditCount = new DataField(TYPE_NUMERIC, 35, 7);

    private DataField filter = new DataField(42, 559);

    public DataField getRecordType() {
        return recordType;
    }

    public DataField getTotalDebitAmount() {
        return totalDebitAmount;
    }

    public DataField getTotalCreditAmount() {
        return totalCreditAmount;
    }

    public DataField getTotalDebitCount() {
        return totalDebitCount;
    }

    public DataField getTotalCreditCount() {
        return totalCreditCount;
    }

    public DataField getFilter() {
        return filter;
    }

    @Override
    public String toString() {
        return "SubmissionFileTrailer [recordType=" + recordType + ", totalDebitAmount=" + totalDebitAmount + ", totalCreditAmount=" + totalCreditAmount + ", totalDebitCount="
                + totalDebitCount + ", totalCreditCount=" + totalCreditCount + ", filter=" + filter + "]";
    }

}
