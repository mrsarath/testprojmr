package com.nets.sg.npx.batch.uob.file.filter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.file.filters.AbstractFileListFilter;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.ChannelSftp;
import com.nets.sg.npx.core.util.CommonConsts;

@Component("normalResponseFileFilter")
public class NormalResponseFileFilter extends AbstractFileListFilter<ChannelSftp.LsEntry> {

    private static final Logger logger = Logger.getLogger(NormalResponseFileFilter.class);

    @Value("${batch.sftp.local.dir.processed}")
    private String processedFilePath;

    @Value("${batch.sftp.local.dir.failed}")
    private String failedFilePath;

    /**
     * Here is the logic to decide whether file should be fetched from remote
     * server. Rejected file names would be
     * UIBOddmmnnS_uuuuu,UIBOddmmnnF_uuuuu,UIBOddmmnnR_uuuuu. Approved file name
     * would be UIEOddmmnnO_uuuuu.
     */
    @Override
    protected boolean accept(ChannelSftp.LsEntry entity) {

        boolean accept = false;
        String fileName = entity.getFilename();
        logger.debug("express file fileter :" + fileName);
        if (fileName.startsWith("UIEO") || fileName.startsWith("UIBO")) {
            if (!getProcessedFileNames().contains(fileName)) {
                accept = true;
            }
        }
        return accept;
    }

    private List<String> getProcessedFileNames() {

        List<String> names = new ArrayList<>();

        File processedDir = new File(processedFilePath + "/" + DateTime.now().toString("yyyy"));
        File failedDir = new File(failedFilePath + "/" + DateTime.now().toString("yyyy"));
        List<File> files = new ArrayList<>();
        if (processedDir.exists()) {
            files.addAll((List<File>) FileUtils.listFiles(processedDir, TrueFileFilter.TRUE, TrueFileFilter.TRUE));
        } else {
            logger.error("processed dir [" + processedDir + "]not found");
        }
        if (failedDir.exists()) {
            files.addAll((List<File>) FileUtils.listFiles(failedDir, TrueFileFilter.TRUE, TrueFileFilter.TRUE));
        } else {
            logger.error("failed dir [" + failedDir + "]not found");
        }
        for (File file : files) {
            names.add(file.getName());
            logger.debug("processed file name [" + file.getName() + "]");
        }
        return names;
    }
}
