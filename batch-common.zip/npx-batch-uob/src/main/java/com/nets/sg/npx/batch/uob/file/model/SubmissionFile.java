package com.nets.sg.npx.batch.uob.file.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

/**
 * This class is an abstraction of outgoing file to UOB.
 *
 */
public class SubmissionFile implements Serializable {

    private SubmissionFileControlHeader control;

    private SubmissionFileHeader header;

    private List<SubmissionDetailRecord> details;

    private HashMap<String, PaymentAdviceRecord> advices;

    private SubmissionFileTrailer trailer;

    public SubmissionFileControlHeader getControl() {
        return control;
    }

    public void setControl(SubmissionFileControlHeader control) {
        this.control = control;
    }

    public SubmissionFileHeader getHeader() {
        return header;
    }

    public void setHeader(SubmissionFileHeader header) {
        this.header = header;
    }

    public List<SubmissionDetailRecord> getDetails() {
        return details;
    }

    public void setDetails(List<SubmissionDetailRecord> details) {
        this.details = details;
    }

    public HashMap<String, PaymentAdviceRecord> getAdvices() {
        return advices;
    }

    public void setAdvices(HashMap<String, PaymentAdviceRecord> advices) {
        this.advices = advices;
    }

    public SubmissionFileTrailer getTrailer() {
        return trailer;
    }

    public void setTrailer(SubmissionFileTrailer trailer) {
        this.trailer = trailer;
    }

}
