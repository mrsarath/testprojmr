package com.nets.sg.npx.batch.uob.file.model;

import static com.nets.sg.npx.batch.uob.file.model.DataField.TYPE_NUMERIC;

import java.io.Serializable;

/**
 * record type 4
 * 
 *
 */
public class PaymentAdviceRecord implements Serializable {

    private DataField recordType = new DataField(1, 1);

    private DataField spacingLines = new DataField(TYPE_NUMERIC, 2, 2);

    private DataField paymentAdviceDetails = new DataField(4, 105);

    private DataField filter = new DataField(109, 492);

    public DataField getRecordType() {
        return recordType;
    }

    public void setRecordType(DataField recordType) {
        this.recordType = recordType;
    }

    public DataField getSpacingLines() {
        return spacingLines;
    }

    public void setSpacingLines(DataField spacingLines) {
        this.spacingLines = spacingLines;
    }

    public DataField getPaymentAdviceDetails() {
        return paymentAdviceDetails;
    }

    public void setPaymentAdviceDetails(DataField paymentAdviceDetails) {
        this.paymentAdviceDetails = paymentAdviceDetails;
    }

    public DataField getFilter() {
        return filter;
    }

    public void setFilter(DataField filter) {
        this.filter = filter;
    }

}
