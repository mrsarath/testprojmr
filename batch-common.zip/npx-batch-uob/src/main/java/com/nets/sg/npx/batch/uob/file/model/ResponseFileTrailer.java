package com.nets.sg.npx.batch.uob.file.model;

import static com.nets.sg.npx.batch.uob.file.model.DataField.TYPE_NUMERIC;

import java.io.Serializable;

public class ResponseFileTrailer implements Serializable {

    private DataField recordType = new DataField(1, 1);

    private DataField totalDebitAmount = new DataField(TYPE_NUMERIC, 2, 13);

    private DataField totalCreditAmount = new DataField(TYPE_NUMERIC, 15, 13);

    private DataField totalDebitCount = new DataField(TYPE_NUMERIC, 28, 7);

    private DataField totalCreditCount = new DataField(TYPE_NUMERIC, 35, 7);

    private DataField rejectedDebitAmount = new DataField(TYPE_NUMERIC, 42, 13);

    private DataField rejectedCreditAmount = new DataField(TYPE_NUMERIC, 55, 13);

    private DataField rejectedDebitCount = new DataField(TYPE_NUMERIC, 68, 7);

    private DataField rejectedCreditCount = new DataField(TYPE_NUMERIC, 75, 7);

    private DataField filter = new DataField(82, 219);

    public DataField getRecordType() {
        return recordType;
    }

    public DataField getTotalDebitAmount() {
        return totalDebitAmount;
    }

    public DataField getTotalCreditAmount() {
        return totalCreditAmount;
    }

    public DataField getTotalDebitCount() {
        return totalDebitCount;
    }

    public DataField getTotalCreditCount() {
        return totalCreditCount;
    }

    public DataField getFilter() {
        return filter;
    }

    public DataField getRejectedDebitAmount() {
        return rejectedDebitAmount;
    }

    public void setRejectedDebitAmount(DataField rejectedDebitAmount) {
        this.rejectedDebitAmount = rejectedDebitAmount;
    }

    public DataField getRejectedCreditAmount() {
        return rejectedCreditAmount;
    }

    public void setRejectedCreditAmount(DataField rejectedCreditAmount) {
        this.rejectedCreditAmount = rejectedCreditAmount;
    }

    public DataField getRejectedDebitCount() {
        return rejectedDebitCount;
    }

    public void setRejectedDebitCount(DataField rejectedDebitCount) {
        this.rejectedDebitCount = rejectedDebitCount;
    }

    public DataField getRejectedCreditCount() {
        return rejectedCreditCount;
    }

    public void setRejectedCreditCount(DataField rejectedCreditCount) {
        this.rejectedCreditCount = rejectedCreditCount;
    }

    public void setRecordType(DataField recordType) {
        this.recordType = recordType;
    }

    public void setTotalDebitAmount(DataField totalDebitAmount) {
        this.totalDebitAmount = totalDebitAmount;
    }

    public void setTotalCreditAmount(DataField totalCreditAmount) {
        this.totalCreditAmount = totalCreditAmount;
    }

    public void setTotalDebitCount(DataField totalDebitCount) {
        this.totalDebitCount = totalDebitCount;
    }

    public void setTotalCreditCount(DataField totalCreditCount) {
        this.totalCreditCount = totalCreditCount;
    }

    public void setFilter(DataField filter) {
        this.filter = filter;
    }

    @Override
    public String toString() {
        return "ResponseFileTrailer [recordType=" + recordType + ", totalDebitAmount=" + totalDebitAmount + ", totalCreditAmount=" + totalCreditAmount + ", totalDebitCount="
                + totalDebitCount + ", totalCreditCount=" + totalCreditCount + ", rejectedDebitAmount=" + rejectedDebitAmount + ", rejectedCreditAmount=" + rejectedCreditAmount
                + ", rejectedDebitCount=" + rejectedDebitCount + ", rejectedCreditCount=" + rejectedCreditCount + ", filter=" + filter + "]";
    }

}
