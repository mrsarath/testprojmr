package com.nets.sg.npx.batch.uob.util;

public class BatchConsts {

    public static final String UOB_SERVICE_TYPE_EXPRESS = "IBGIEXP";

    public static final String UOB_SERVICE_TYPE_NORMAL = "IBGINORM";

    public static final String[] UOB_SG_BANK_CODE = new String[] { "7375", "7199" };

}
