package com.nets.sg.npx.batch.uob.jobs;

import static com.nets.sg.npx.batch.uob.util.BatchConsts.UOB_SERVICE_TYPE_NORMAL;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.nets.sg.npx.batch.common.service.BatchEmailService;
import com.nets.sg.npx.batch.uob.service.BatchService;

@Component("normalJob")
public class NormalSubmissionJob {

    private static final Logger logger = Logger.getLogger(NormalSubmissionJob.class);

    @Autowired
    private BatchService batchService;

    @Autowired
    private BatchEmailService emailService;

    @Value("${batch.uob.schedular.job.submission.normal.enabled}")
    private Boolean normal;

    @Scheduled(cron = "${batch.uob.scheduler.job.normal.weekday.submission}")
    public void executeForWeekday() {
        execute();
    }

    @Scheduled(cron = "${batch.uob.scheduler.job.normal.weekend.submission}")
    public void executeForWeekend() {
        execute();
    }

    private void execute() {
        String now = DateTime.now().toString("yyyyMMdd");
        try {
            if (normal) {
                batchService.processOutputFile(now, UOB_SERVICE_TYPE_NORMAL);
                logger.info("[" + UOB_SERVICE_TYPE_NORMAL + "] job launched [" + DateTime.now() + "].");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            emailService.sendError(e.getMessage());
        }
    }
}
