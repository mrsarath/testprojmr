package com.nets.sg.npx.batch.uob.file.model;

import static com.nets.sg.npx.batch.uob.file.model.DataField.MANDATORY_NO;
import static com.nets.sg.npx.batch.uob.file.model.DataField.TYPE_NUMERIC;

import java.io.Serializable;

public class SubmissionFileControlHeader implements Serializable {

    private DataField recordType = new DataField(1, 1);

    /**
     * UIEIddmmnn :
     * 
     * @UIEI : prefix .
     * @ddmm file creation date and month.
     * @nn file sequence 01 - 99
     */
    private DataField fileName = new DataField(2, 10);

    private DataField fileCreationDate = new DataField(TYPE_NUMERIC, 12, 8);

    private DataField FileCreationTime = new DataField(TYPE_NUMERIC, 20, 6);

    private DataField companyId = new DataField(26, 12);

    private DataField checkSum = new DataField(TYPE_NUMERIC, 38, 15);

    private DataField bibCompanyId = new DataField(53, 12);

    private DataField filter = new DataField(65, 536, MANDATORY_NO);

    public DataField getRecordType() {
        return recordType;
    }

    public void setRecordType(DataField recordType) {
        this.recordType = recordType;
    }

    public DataField getFileName() {
        return fileName;
    }

    public void setFileName(DataField fileName) {
        this.fileName = fileName;
    }

    public DataField getFileCreationDate() {
        return fileCreationDate;
    }

    public void setFileCreationDate(DataField fileCreationDate) {
        this.fileCreationDate = fileCreationDate;
    }

    public DataField getFileCreationTime() {
        return FileCreationTime;
    }

    public void setFileCreationTime(DataField fileCreationTime) {
        FileCreationTime = fileCreationTime;
    }

    public DataField getCompanyId() {
        return companyId;
    }

    public void setCompanyId(DataField companyId) {
        this.companyId = companyId;
    }

    public DataField getCheckSum() {
        return checkSum;
    }

    public void setCheckSum(DataField checkSum) {
        this.checkSum = checkSum;
    }

    public DataField getBibCompanyId() {
        return bibCompanyId;
    }

    public void setBibCompanyId(DataField bibCompanyId) {
        this.bibCompanyId = bibCompanyId;
    }

    public DataField getFilter() {
        return filter;
    }

    public void setFilter(DataField filter) {
        this.filter = filter;
    }

    @Override
    public String toString() {
        return "FileControlHeader [recordType=" + recordType + ", fileName=" + fileName + ", fileCreationDate=" + fileCreationDate + ", FileCreationTime=" + FileCreationTime
                + ", companyId=" + companyId + ", checkSum=" + checkSum + ", bibCompanyId=" + bibCompanyId + ", filter=" + filter + "]";
    }

}
