package com.nets.sg.npx.batch.uob.service;

import com.nets.sg.npx.batch.common.exception.BatchException;

public interface BatchService {

    public boolean processOutputFile(String date, String serviceType) throws BatchException;

    public boolean processInputFile(String serviceType) throws BatchException;

}
