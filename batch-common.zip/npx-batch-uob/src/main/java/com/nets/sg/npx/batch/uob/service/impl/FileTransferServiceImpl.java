package com.nets.sg.npx.batch.uob.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.Message;
import org.springframework.integration.MessageChannel;
import org.springframework.integration.core.PollableChannel;
import org.springframework.integration.endpoint.SourcePollingChannelAdapter;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Service;

import com.nets.sg.npx.batch.common.exception.BatchException;
import com.nets.sg.npx.batch.uob.service.FileTransferService;
import com.nets.sg.npx.batch.uob.util.BatchConsts;
import com.nets.sg.npx.core.util.CommonConsts;

@Service("fileTransferService")
public class FileTransferServiceImpl implements FileTransferService {

    private static final Logger logger = Logger.getLogger(FileTransferServiceImpl.class);

    @Autowired
    @Qualifier("outputChannel")
    private MessageChannel outputChannel;

    @Autowired
    @Qualifier("expressInputChannel")
    private PollableChannel expressInputChannel;

    @Autowired
    @Qualifier("normalInputChannel")
    private PollableChannel normalInputChannel;

    @Autowired
    @Qualifier("expressSftpInbondAdapter")
    private SourcePollingChannelAdapter expressSftpInbondAdapter;

    @Autowired
    @Qualifier("normalSftpInbondAdapter")
    private SourcePollingChannelAdapter normalSftpInbondAdapter;

    @Value("${batch.sftp.local.dir.failed}")
    private String failedFilePath;

    @Value("${batch.sftp.local.dir.received}")
    private String receivedFilePath;

    @Value("${batch.sftp.local.dir.processed}")
    private String processedFilePath;

    @Value("${batch.sftp.file.time.to.wait}")
    private String timeToWait;

    @Override
    public boolean upload(File file) throws BatchException {
        try {
            final Message<File> message = MessageBuilder.withPayload(file).build();
            outputChannel.send(message);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new BatchException(e.getMessage());
        }
        return true;
    }

    private List<File> getUnProcessedFile(String receivedPath) {
        List<File> files = new ArrayList<>();
        logger.info("system is loading unprocessed file from [" + receivedPath + "].");
        File root = new File(receivedPath);
        File[] list = root.listFiles();
        String year = CommonConsts.DATETIME_FORMAT_CCYY.print(new DateTime());
        if (list != null && list.length > 0) {
            for (File f : list) {
                if (f.isDirectory()) {
                    logger.info("directory is skipped");
                } else {
                    if (new File(processedFilePath + "/" + year, f.getName()).exists()) {
                        logger.error("file [" + f.getName() + "] not processed as same file name exists in [" + processedFilePath + "/" + year + "]");
                        f.renameTo(new File(failedFilePath, f.getName()));

                    } else {
                        files.add(f);
                    }
                }
            }

        }

        return files;
    }

    @Override
    public List<File> download(String receivedPath, String serviceType) throws BatchException {
        List<File> received = new ArrayList<>();
        logger.info("system start to download file");
        try {
            if (BatchConsts.UOB_SERVICE_TYPE_EXPRESS.equals(serviceType)) {
                expressSftpInbondAdapter.start();
                expressInputChannel.receive(new Integer(timeToWait));// milliseconds
                Thread.sleep(new Integer(timeToWait));
                expressSftpInbondAdapter.stop();
                received = getUnProcessedFile(receivedPath);
            } else if (BatchConsts.UOB_SERVICE_TYPE_NORMAL.equals(serviceType)) {
                normalSftpInbondAdapter.start();
                normalInputChannel.receive(new Integer(timeToWait));// milliseconds
                Thread.sleep(new Integer(timeToWait));
                normalSftpInbondAdapter.stop();
                received = getUnProcessedFile(receivedPath);
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new BatchException(e.getMessage());
        }
        return received;

    }

}
