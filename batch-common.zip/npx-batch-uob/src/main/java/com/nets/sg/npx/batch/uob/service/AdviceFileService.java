package com.nets.sg.npx.batch.uob.service;

import java.io.File;
import java.util.List;

import com.nets.sg.npx.batch.common.error.ProcessingError;
import com.nets.sg.npx.batch.common.exception.BatchException;
import com.nets.sg.npx.batch.uob.file.model.SubmissionFile;
import com.nets.sg.npx.core.persistence.entity.MerchantFundingEntity;

public interface AdviceFileService {

    public List<File> downloadResponseFiles(String serviceType) throws BatchException;

    public List<ProcessingError> processResponseFiles(List<File> files, String serviceType) throws BatchException;

    public SubmissionFile generateSubmissionFiles(String from, String to, String serviceType) throws BatchException;

    public void uploadSubmissionFiles(List<File> files) throws BatchException;

    public MerchantFundingEntity recordMerchantFunding(SubmissionFile submissionFile);

}
