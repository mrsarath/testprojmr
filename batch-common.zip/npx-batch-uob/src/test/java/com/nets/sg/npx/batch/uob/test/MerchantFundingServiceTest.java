package com.nets.sg.npx.batch.uob.test;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertThat;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.when;
import static org.hamcrest.core.Is.is;

import com.nets.sg.npx.core.dao.MerchantFundingDao;
import com.nets.sg.npx.core.persistence.entity.MerchantFundingEntity;
import com.nets.sg.npx.core.service.impl.MerchantFundingServiceImpl;


public class MerchantFundingServiceTest {
    
    public static final String fileName = "UIEO160101.TXT";
    
    @InjectMocks
    private MerchantFundingServiceImpl merchantFundingService;

    @Mock
    private MerchantFundingDao merchantFundingDao;

    //@Mock
    //private TaxCalculator taxCalculator;
    
    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);        
    }
    
    @Test
    public void getSubmittedByFileNameTest() {
        
        MerchantFundingEntity merchant = new MerchantFundingEntity();
        
        when (merchantFundingDao.getSubmittedByFileName(fileName)).thenReturn(merchant);
        
        MerchantFundingEntity actual = merchantFundingService.getSubmittedByFileName(fileName);
        
        assertThat(actual.equals(new MerchantFundingEntity()), is(true));
        
    }



}
