package com.nets.sg.npx.batch.uob.test;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.nets.sg.npx.batch.uob.file.model.SubmissionFile;
import com.nets.sg.npx.batch.uob.util.AdviceFileUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/batch-root-ctx.xml" })
public class AdviceFileUtilTest {
    
    private static final String submissionFilePath = "src/test/resources/submissionfile_20141015.ser";
    private static final String checkSum = "1654831"; // "547207";

    @Autowired
    AdviceFileUtil fileUtil;
    
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testGenerateFileHash() {
        System.out.println("Started testGenerateFileHash...");
        
        SubmissionFile file = deserializeFile();
        fileUtil.generateFileHash(file);
        System.out.println("generateFileHash completed.");
        assertEquals(file.getControl().getCheckSum().getValue(), AdviceFileUtilTest.checkSum);
        
        System.out.println("Ended testGenerateFileHash...");
    }

    public SubmissionFile deserializeFile() {
        SubmissionFile e = null;
        try {
            System.out.println("SubmissionFile (serialized File) full path: " + submissionFilePath);
            FileInputStream fileIn = new FileInputStream(submissionFilePath);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            e = (SubmissionFile) in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException i) {
            i.printStackTrace();
        } catch (ClassNotFoundException c) {
            System.out.println("SubmissionFile class not found");
            c.printStackTrace();
        }

        System.out.println("Deserialize completed ...");     

        return e;
    }

}
