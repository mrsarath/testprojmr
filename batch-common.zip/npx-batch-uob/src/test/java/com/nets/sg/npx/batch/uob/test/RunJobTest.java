package com.nets.sg.npx.batch.uob.test;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.nets.sg.npx.batch.common.exception.BatchException;
import com.nets.sg.npx.batch.uob.service.BatchService;
import com.nets.sg.npx.batch.uob.util.BatchConsts;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/batch-root-ctx.xml" })
public class RunJobTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    //private JdbcTemplate simpleJdbcTemplate;

    @Autowired
    BatchService batchService;

    /*@Autowired
    public void setDataSource(DriverManagerDataSource dataSource) {
        this.simpleJdbcTemplate = new JdbcTemplate(dataSource);
    }*/

    @Test
    public void testJob() throws Exception {
        // simpleJdbcTemplate.update("delete from ttr01_transaction");
        /*
         * for (int i = 1; i <= 10; i++) { simpleJdbcTemplate.update(
         * "insert into ttr01_transaction values (?, 0, ?, 100000)", i,
         * "customer" + i); }
         */

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

        try {
            String date = sdf.format(new Date());
            String serviceType = BatchConsts.UOB_SERVICE_TYPE_EXPRESS;
            boolean result = batchService.processOutputFile(date, serviceType);
            assertTrue ("failed with exception, see the logs.",  result);
        } catch (BatchException be) {
           // test success, but with BatchException
        } catch (Exception e) {        
            fail(e.getMessage());
        }        
    }
}
