package com.nets.sg.npx.batch.uob.test;

import static com.nets.sg.npx.core.util.CommonConsts.DATETIME_FORMAT_CCYY;
import static org.junit.Assert.*;

import java.io.File;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.joda.time.DateTime;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.nets.sg.npx.batch.common.exception.BatchException;
import com.nets.sg.npx.batch.uob.service.BatchService;
import com.nets.sg.npx.batch.uob.util.BatchConsts;
import com.nets.sg.npx.core.exception.SystemException;
import com.nets.sg.npx.core.util.CommonConsts;
import com.nets.sg.npx.core.util.PropertyUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
@ContextConfiguration(locations = { "/batch-root-ctx.xml", "/test-ctx.xml"}) 
public class RunJobDataTest {

    private JdbcTemplate jdbcTemplate;

    @Autowired
    BatchService batchService;

    @Autowired
    PropertyUtil propertyUtil;
    
    @Value("${batch.sftp.local.dir.sent}")
    private String sentFilePath;
    
    @Value("${batch.local.file.sequence}")
    private String fileSequenceNo;

    String tableName = "ttr01_transaction";
    
    DateTime now = new DateTime();

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
    String bankSettleDate = sdf.format(new Date());
    String authorizeDate = bankSettleDate;
    String bankAuthorizeDate = sdf2.format(new Date()) + " 00:00:00";
    String creationDate = new DateTime().minusMinutes(30).toString("yyyy-MM-dd HH:mm:ss");
    String updationDate = bankSettleDate;

    String[] fieldValArr = {            
            "c714d457-995e-4e6a-b83e-113657d7a717",
            "4",
            "3",
            "20150507144332720",
            null,
            "",
            authorizeDate,
            bankAuthorizeDate,
            null,
            null,
            "82025800950502000880009A031505079C01009F02060000000010009F03060000000000009F090200029F10120210A4000E140000DAC000000000000000FF9F1A0207029F1E0837303535303131389F2608565DD0913AB2FB359F2701809F330360B0C89F34031E03009F3501219F360200029F3704DF9063A89F4104000001159F5301525F2A0207028408A0000000041010025F3401035F24032512319F0608A0000000041010029F0D05FC50A000009F0E0500000000009F0F05F870A49800",
            "82025800950502000880009A031505079C01009F02060000000010009F03060000000000009F090200029F10120210A4000E140000DAC000000000000000FF9F1A0207029F1E0837303535303131389F2608ADB17DA5828B38889F2701809F330360B0C89F34031E03009F3501219F360200029F3704DF9063A89F4104000001159F5301525F2A0207028408A0000000041010025F3401035F24032512319F0608A0000000041010029F0D05FC50A000009F0E0500000000009F0F05F870A49800",
            null, "04", null, "2", "03", "ADB17DA5828B3888", "OK", null, "000011001766", "00", "005449", null, null, bankSettleDate, "N", "SGD", "10.0000",
            "0.000", "SGD", "10.0000", "0.0000", "2", "9d8dfca4feb48c9662bbf06330c8c6953ecefe5d326ba031b585931942878db2", "4fbe623ffd0bcc3d9219b349090d49f0",
            null, null, null, null, null, null, null, "2", "NA", null, "N", null, null, null, null, "01", "3.000000", "000001010000107", "88888005", "23", "4",
            null, "NA", null, null, null, null, null, null, "2", creationDate, "2", updationDate, "12345", "461", null, "000005", null, null, null, null, null,
            null, null, "1", null, "0045", null, null, null, null, null };

    @Autowired @Qualifier("testDataSource")
    public void setDataSource(DriverManagerDataSource dataSource) throws SQLException {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        /*try {
            this.simpleJdbcTemplate.getDataSource().getConnection().setAutoCommit(true);
        } catch (SQLException e) {            
            e.printStackTrace();
            throw e;
        }*/        
    }

    private static void updateLastDateFileGenerated(String date, String serviceType) throws SystemException,  ConfigurationException{

        //DefaultKeyValue newSequence = new DefaultKeyValue("batch.uob.last.date.file.generated." + serviceType, date);
        //propertyUtil.updateProperties(newSequence);
                
        try {
            PropertiesConfiguration config = new PropertiesConfiguration("batch.properties");
            
            System.out.println(config.getProperty("batch.uob.last.date.file.generated." + serviceType));
            config.setProperty("batch.uob.last.date.file.generated." + serviceType, date);
            config.save();
        } catch (ConfigurationException e) {    
            e.printStackTrace();
            throw e;
        }


        System.out.println("update last date file generated [" + date + "].");

    }

    @BeforeClass
    public static void setUp() throws Exception {

        // setup property file values
        try {
            updateLastDateFileGenerated(CommonConsts.DATETIME_FORMAT_CCYYMMDD.print(new DateTime().minusDays(1)), BatchConsts.UOB_SERVICE_TYPE_EXPRESS);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw e;
        }
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testDummy() throws Exception {
           
    }
    
    //@Test
    public void testJob() throws Exception {
        // TODO
        // do clean up of old test data first

        int newTxnId = createTransaction();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

        try {
            String date = sdf.format(new Date());
            String serviceType = BatchConsts.UOB_SERVICE_TYPE_EXPRESS;
            boolean result = batchService.processOutputFile(date, serviceType);
            assertTrue("failed with exception, see the logs.", result);
            
            chekFileInSentFolder();
            
            clearTestDataFromDb(newTxnId);
            
        } catch (BatchException be) {
            // test success, but with BatchException
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
    
    private int createTransaction() throws Exception {
        
        int newTxnId = -1;
        
        try {
            StringBuffer valStr = new StringBuffer();
            for (int j = 0; j < fieldValArr.length; j++) {
                if (j != 0)
                    valStr.append(",");
                valStr.append("?");
            }
           /*
            ArrayList<String> fieldValList = new ArrayList<String>(Arrays.asList(fieldValArr));
            fieldValList.remove(0);
            
            int rowsInserted = simpleJdbcTemplate.update(getInsertSql() + valStr + ")", fieldValList.toArray()); */

            int rowsInserted = jdbcTemplate.update(getInsertSql() + valStr + ")", (Object[]) fieldValArr);
            
            newTxnId = jdbcTemplate.queryForObject("select last_insert_id()", Integer.class);
            
            System.out.println("Numbers of transaction records insert successfully: " + rowsInserted);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw e;
        }        

        return newTxnId;
        
        /*KeyHolder holder = new GeneratedKeyHolder();

        simpleJdbcTemplate.update(new PreparedStatementCreator() {           

                        @Override
                        public PreparedStatement createPreparedStatement(Connection connection)
                                throws SQLException {
                            PreparedStatement ps = connection.prepareStatement("", Statement.RETURN_GENERATED_KEYS);
                            ps.s
                            ps.setString(1, "");
                            ps.setString(2, "");
                            ps.setString(3, "");
                            ps.setLong(4, 1L);
                            return ps;
                        }
                    }, holder);

        Long newTxnId = holder.getKey().longValue();
        */
    }
    
    private void clearTestDataFromDb(int txnId) {
        
        int rowsDeleted = jdbcTemplate.update("DELETE FROM " + tableName + " WHERE TRANSACTION_ID = ? ", txnId);
        System.out.println("Numbers of transaction records deleted successfully: " + rowsDeleted);        
    }

    public String getInsertSql() {

        String insertSql = "INSERT INTO " + tableName + "(`WORKFLOW_BIZ_KEY`," + "`POS_ID`," + "`MERCHANT_ID`," + "`CONVERSION_KEY`,"
                + "`RELATED_REF_ID`," + "`DESCRIPTION`," + "`AUTHORIZE_DATE`," + "`BANK_AUTHORIZE_DATE`," + "`AUTH_CLUSTER_ID`," + "`DECRYPT_SERVICE_TXN_ID`,"
                + "`EMV_DATA`," + "`EMV_TC_DATA`," + "`INITIAL_BANK_BATCH_ID`," + "`STATE`," + "`TRAN_STATUS_DATE`," + "`CAPTURE_TYPE`," + "`TRAN_TYPE`,"
                + "`TXN_CERT`," + "`TC_UPLOAD_STATUS`," + "`ACQ_ORDER_NO`," + "`ACQ_AUTH_RESPONSE_ID`," + "`ACQ_TXN_RESPONSE_CODE`," + "`ACQ_APPROVAL_CODE`,"
                + "`TRANSMIT_STATUS`," + "`TRANSMIT_DATE`," + "`BANK_SETTLE_DATE`," + "`IS_REFUND`," + "`SOURCE_CURRENCY`," + "`SOURCE_AMOUNT`,"
                + "`TIP_AMOUNT`," + "`TARGET_CURRENCY`," + "`TARGET_AMOUNT`," + "`ORIG_TARGET_AMOUNT`," + "`TARGET_CURR_MINOR_UNIT`," + "`CARD_NO`,"
                + "`CARD_EXPR_DATE`," + "`CUSTOMER_IP_ADDRESS`," + "`CUSTOMER_IP_PORT`," + "`GEO_LATITUDE`," + "`GEO_LONGITUDE`," + "`CARD_HOLDER_NAME`,"
                + "`BITMAP`," + "`PAYMENT_METHOD`," + "`CARD_TYPE_ID`," + "`TRANSACTION_SOURCE`," + "`CONVERSION_OFF`," + "`IS_DCC_TRANSACTION`,"
                + "`SETTLEMENT_TYPE`," + "`ECI`," + "`CAVV`," + "`XID`," + "`3D_TXN_STATUS`," + "`MDR_PERCENT`," + "`EC_MID`," + "`TID`,"
                + "`ACQ_MER_MAPPING_ID`," + "`ACQUIRER_ID`," + "`BATCH_SOC_ID`," + "`USER_DATA`," + "`MERCHANT_PROFILE_ID`," + "`MERCHANT_ACCESS_CODE`,"
                + "`MERCHANT_LOGIN_ID`," + "`MERCHANT_PASSWORD`," + "`ON_US`," + "`VAT_PERCENT`," + "`CREATED_BY`," + "`CREATION_DATE`," + "`LAST_UPDATED_BY`,"
                + "`LAST_UPDATED_DATE`," + "`CURR_ECE_REQUEST_ID`," + "`BANK_BATCH_ID`," + "`SETTLEMENT_BLOCK_ID`," + "`CLUSTER_ID`," + "`LOCALE_ID`,"
                + "`INVOICE_CASH_NO`," + "`CHEQUE_NO`," + "`ACCOUNT_NO`," + "`BANK_BRANCH`," + "`BANK_NO`," + "`BANK_NAME`," + "`CHARGEBACK_STATUS`,"
                + "`ACQ_MER_ACCT_ID`," + "`CARD_NO_SUFFIX`," + "`PAYMENT_STATUS`," + "`REF_PAY_DTL_ID`," + "`TRAN_INST_ID`," + "`RECEIPT_AVAILABLE`,"
                + "`MS_INFO`)" + " VALUES(";

        return insertSql;
    }
    
    private void chekFileInSentFolder() {        
                
        if ("99".equals(fileSequenceNo)) {
            fail("reach max sequence number [" + fileSequenceNo + "] already, cannot run the test.");            
        }

        fileSequenceNo = String.valueOf(new Integer(fileSequenceNo) + 1);
        
        String ddmm = CommonConsts.DATETIME_FORMAT_DDMM.print(now);

        File dir = new File(sentFilePath + "" + DATETIME_FORMAT_CCYY.print(now));
        List<File> files = new ArrayList<>();
        if (dir.exists()) {
            files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.TRUE, TrueFileFilter.TRUE);
        } else {            
            fail("sent folder [" + sentFilePath + "] not found, cannot run the test.");
        }
        
        List<String> names = new ArrayList<>();
        for (File file : files) {
            if (file.getName().length() == 10) {
                names.add(file.getName().substring(4));
            }
        }
        
        if (names.size() != 0) {
            Collections.sort(names);
            String max = names.get(names.size() - 1);
            System.out.println("last file name is [" + max + "] , today is [" + ddmm + "].");
            
            max = max.substring(max.length() - 2, max.length());
            max = String.valueOf(Integer.valueOf(max));
            
            if (!fileSequenceNo.equals(max))
                fail ("new submission file not created in the folder" + dir.getName() + ",test failed.");
            else
                System.out.println("new submission file created correctly in the folder" + dir.getName() + ".");            
        } else {
            fail ("no file found in the folder " + dir.getName() +", test failed.");
        }        
        
    }

}
